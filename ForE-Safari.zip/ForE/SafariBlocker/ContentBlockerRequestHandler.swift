import Foundation
import ForECore

/// Safari evaluates this compiled URL rule list before resolving destinations,
/// including when iCloud Private Relay is enabled. No page contents are read.
final class ContentBlockerRequestHandler: NSObject, NSExtensionRequestHandling {
    func beginRequest(with context: NSExtensionContext) {
        let now = Date()
        var snapshot = SafariRuleSet()
        var sharedContainer: URL?
        var readError: String?

        do {
            guard let group = Bundle.main.object(forInfoDictionaryKey: "ForEAppGroupIdentifier") as? String,
                  !group.hasPrefix("."), !group.contains("$("),
                  let container = FileManager.default.containerURL(forSecurityApplicationGroupIdentifier: group) else {
                throw NSError(domain: "ForE.Safari", code: 1, userInfo: [NSLocalizedDescriptionKey:
                    "Die Safari-Erweiterung hat keinen Zugriff auf die gemeinsame App Group. Bitte Signierung und App-Groups-Capability prüfen."])
            }
            sharedContainer = container
            let data = try Data(contentsOf: container.appendingPathComponent("safari-rules.json"))
            snapshot = try JSONDecoder().decode(SafariRuleSet.self, from: data)
        } catch {
            // A corrupt/missing configuration must never create an indefinite
            // block. Report it through the receipt instead of claiming readiness.
            readError = error.localizedDescription
            snapshot = SafariRuleSet()
        }

        let ruleData: Data
        do {
            ruleData = try snapshot.jsonData(now: now)
        } catch {
            readError = error.localizedDescription
            snapshot = SafariRuleSet()
            do { ruleData = try snapshot.jsonData(now: now) }
            catch { context.cancelRequest(withError: error); return }
        }

        do {
            if let container = sharedContainer {
                let receipt = SafariRuleReceipt(snapshot: snapshot, generatedAt: now, readError: readError)
                try JSONEncoder().encode(receipt).write(
                    to: container.appendingPathComponent("safari-extension-receipt.json"), options: .atomic)
            }
            // Keep the attachment on disk while Safari consumes the provider.
            // The extension's temporary directory is managed by the system.
            let file = FileManager.default.temporaryDirectory.appendingPathComponent("ForE-\(UUID().uuidString).json")
            try ruleData.write(to: file, options: .atomic)
            guard let provider = NSItemProvider(contentsOf: file) else {
                throw NSError(domain: "ForE.Safari", code: 2, userInfo: [NSLocalizedDescriptionKey: "Safari-Regeln konnten nicht bereitgestellt werden."])
            }
            let item = NSExtensionItem()
            item.attachments = [provider]
            context.completeRequest(returningItems: [item])
        } catch {
            context.cancelRequest(withError: error)
        }
    }
}
