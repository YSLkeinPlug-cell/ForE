import XCTest
@testable import ForECore

final class DomainNormalizerTests: XCTestCase {
    func testPastedWebURLIsReducedToDomain() throws {
        XCTAssertEqual(try DomainNormalizer.normalize(input: "  https://WWW.YouTube.com/watch?v=test  "), "youtube.com")
        XCTAssertEqual(try DomainNormalizer.normalize(input: "reddit.com/r/swift"), "reddit.com")
        XCTAssertEqual(try DomainNormalizer.normalize(input: "http://news.example.com./path"), "news.example.com")
        XCTAssertEqual(try DomainNormalizer.normalize(input: "xn--bcher-kva.de"), "xn--bcher-kva.de")
    }

    func testHostsAndShellInjectionIsRejected() {
        for input in ["example.com\n127.0.0.1 apple.com", "foo.com\tbar.com", "*.youtube.com",
                      "example.com;rm", "a.com$(whoami)", "example.com\\x", "foo.com\u{0}bar"] {
            XCTAssertThrowsError(try DomainNormalizer.normalize(input: input), input)
        }
    }

    func testCredentialsAndPortsAreRejected() {
        for input in ["https://user:password@example.com", "https://user@example.com", "example.com:443",
                      "https://example.com:", "https://%65xample.com", "https://example.com:foo"] {
            XCTAssertThrowsError(try DomainNormalizer.normalize(input: input), input)
        }
    }

    func testLocalAndMalformedHostsAreRejected() {
        for input in ["localhost", "localhost.localdomain", "127.0.0.1", "10.0.0.1", "[::1]",
                      "printer.local", "host.internal", "foo..com", "-foo.com", "foo-.com", "foo.123",
                      "", "example", "foo_bar.com", "bücher.de", "ftp://example.com"] {
            XCTAssertThrowsError(try DomainNormalizer.normalize(input: input), input)
        }
    }

    func testDNSLengthLimits() {
        XCTAssertThrowsError(try DomainNormalizer.normalize(input: String(repeating: "x", count: 64) + ".com"))
        XCTAssertThrowsError(try DomainNormalizer.normalize(input: Array(repeating: String(repeating: "x", count: 63), count: 5).joined(separator: ".")))
        XCTAssertNoThrow(try DomainNormalizer.normalize(input: String(repeating: "x", count: 63) + ".com"))
    }
}
