import Foundation
import XCTest
@testable import ForECore
#if canImport(WebKit)
import WebKit
import Network
#endif

final class SafariRulesTests: XCTestCase {
    private let now = Date(timeIntervalSince1970: 1_800_000_000)

    private func rules(_ domains: [String], activeUntil: Date? = nil) throws -> [[String: Any]] {
        let data = try SafariRules.jsonData(domains: domains, activeUntil: activeUntil ?? now.addingTimeInterval(600), now: now)
        return try XCTUnwrap(JSONSerialization.jsonObject(with: data) as? [[String: Any]])
    }

    private func isBlocked(_ url: String, in rules: [[String: Any]]) throws -> Bool {
        var blocked = false
        for rule in rules {
            let trigger = try XCTUnwrap(rule["trigger"] as? [String: Any])
            let filter = try XCTUnwrap(trigger["url-filter"] as? String)
            let sensitive = trigger["url-filter-is-case-sensitive"] as? Bool ?? false
            let regex = try NSRegularExpression(pattern: filter, options: sensitive ? [] : [.caseInsensitive])
            guard regex.firstMatch(in: url, range: NSRange(url.startIndex..., in: url)) != nil else { continue }
            let action = try XCTUnwrap(rule["action"] as? [String: Any])
            switch try XCTUnwrap(action["type"] as? String) {
            case "block": blocked = true
            case "ignore-previous-rules": blocked = false
            default: XCTFail("Unexpected content-blocker action")
            }
        }
        return blocked
    }

    func testActiveRulesBlockExactDomainAndWWWOverHTTPAndHTTPS() throws {
        let generated = try rules(["youtube.com"])
        for url in ["https://youtube.com", "http://youtube.com/", "https://www.youtube.com/watch?v=123",
                    "https://YOUTUBE.COM/", "https://youtube.com?search=hi", "https://youtube.com#section",
                    "https://youtube.com:8443/watch", "http://www.youtube.com:80", "https://youtube.com./",
                    "https://user:password@youtube.com/", "https://user%40name@www.youtube.com:8443/path",
                    "https://@youtube.com/"] {
            XCTAssertTrue(try isBlocked(url, in: generated), url)
        }
    }

    func testRulesDoNotBlockLookalikeHostsOrUnselectedSubdomains() throws {
        let generated = try rules(["youtube.com"])
        for url in ["https://notyoutube.com/", "https://youtubeXcom/", "https://youtube.com.evil.org/",
                    "https://youtube.com@evil.org/", "https://www.youtube.com.evil.org/", "https://m.youtube.com/",
                    "https://www.www.youtube.com/", "https://other.org/?url=https://youtube.com/",
                    "ftp://youtube.com/", "https://youtube.com:abc/", "https://youtube.com:80.evil.org/",
                    "https://youtube.comevil/", "https://youtube.com../"] {
            XCTAssertFalse(try isBlocked(url, in: generated), url)
        }
    }

    func testExplicitSubdomainDoesNotBlockParentOrSiblings() throws {
        let generated = try rules(["m.youtube.com"])
        XCTAssertTrue(try isBlocked("https://m.youtube.com/", in: generated))
        XCTAssertTrue(try isBlocked("https://www.m.youtube.com/", in: generated))
        XCTAssertFalse(try isBlocked("https://youtube.com/", in: generated))
        XCTAssertFalse(try isBlocked("https://other.youtube.com/", in: generated))
    }

    func testEmptyMissingAndExpiredConfigurationsRemainNonblocking() throws {
        let inputs: [([String], Date?)] = [([], now.addingTimeInterval(600)), (["youtube.com"], nil),
                                         (["youtube.com"], now), (["youtube.com"], now.addingTimeInterval(-1)),
                                         (["bad\ninput"], now.addingTimeInterval(-1)),
                                         (Array(repeating: "youtube.com", count: 201), nil),
                                         (Array(repeating: "bad\ninput", count: 201), now)]
        for (domains, deadline) in inputs {
            let data = try SafariRules.jsonData(domains: domains, activeUntil: deadline, now: now)
            let generated = try XCTUnwrap(JSONSerialization.jsonObject(with: data) as? [[String: Any]])
            XCTAssertEqual(generated.count, 1, "WebKit rejects an empty rule list")
            for rule in generated {
                let action = try XCTUnwrap(rule["action"] as? [String: Any])
                let trigger = try XCTUnwrap(rule["trigger"] as? [String: Any])
                XCTAssertEqual(action["type"] as? String, "ignore-previous-rules",
                               "An inactive configuration must contain no blocking action")
                XCTAssertEqual(trigger["url-filter"] as? String, ".*")
            }
            for url in ["https://youtube.com/", "http://www.youtube.com/", "https://other.org/",
                        "https://gesetze.jurafuchs.de/gesetz/zpo/281-verweisung-bei-unzustaendigkeit",
                        "about:blank", "file:///tmp/file"] {
                XCTAssertFalse(try isBlocked(url, in: generated), url)
            }
        }
    }

    func testMaliciousActiveDomainsAreRejected() {
        for domain in ["youtube.com\n0.0.0.0 apple.com", "foo.com\"}", "foo.com|.*", "*.youtube.com",
                       "foo.com$", "foo.com[", "https://user:pass@foo.com", "https://foo.com:443", "bücher.de"] {
            XCTAssertThrowsError(try SafariRules.jsonData(domains: [domain], activeUntil: now.addingTimeInterval(10), now: now), domain)
        }
    }

    func testPastedURLsNormalizeAndDuplicatesHaveDeterministicRules() throws {
        let a = try SafariRules.jsonData(domains: ["reddit.com", "https://WWW.YouTube.com/watch", "youtube.com"],
                                        activeUntil: now.addingTimeInterval(60), now: now)
        let b = try SafariRules.jsonData(domains: ["youtube.com", "reddit.com"],
                                        activeUntil: now.addingTimeInterval(60), now: now)
        XCTAssertEqual(a, b)
        XCTAssertEqual(try XCTUnwrap(JSONSerialization.jsonObject(with: a) as? [Any]).count, 4)
    }

    func testPunycodeAndLiteralDots() throws {
        let generated = try rules(["xn--bcher-kva.de"])
        XCTAssertTrue(try isBlocked("https://xn--bcher-kva.de/books", in: generated))
        XCTAssertFalse(try isBlocked("https://xn--bcher-kvaXde/books", in: generated))
        XCTAssertFalse(try isBlocked("https://xn--bcher-kva.de.example.org/", in: generated))
    }

    func testOutputUsesWebKitSupportedRegexSubsetAndBlocksAllResourceTypes() throws {
        for rule in try rules(["youtube.com", "reddit.com"]) {
            let trigger = try XCTUnwrap(rule["trigger"] as? [String: Any])
            let action = try XCTUnwrap(rule["action"] as? [String: Any])
            let filter = try XCTUnwrap(trigger["url-filter"] as? String)
            XCTAssertTrue(filter.hasPrefix("^https?://"))
            XCTAssertFalse(filter.contains("|"), "WebKit rejects disjunction")
            XCTAssertFalse(filter.contains("(?"), "No lookaround or noncapturing groups")
            XCTAssertFalse(filter.contains("{"), "Only ?, * and + quantifiers are supported")
            XCTAssertNil(trigger["if-domain"], "if-domain checks document context, not the resource host")
            XCTAssertNil(trigger["resource-type"], "Also block embedded requests to selected domains")
            XCTAssertEqual(action["type"] as? String, "block")
        }
    }

    func testRuleSetConfigurationRoundTripsAndDelegates() throws {
        let configuration = SafariRuleSet(domains: ["youtube.com"], activeUntil: now.addingTimeInterval(60), sessionID: UUID())
        let saved = try JSONEncoder().encode(configuration)
        XCTAssertEqual(try JSONDecoder().decode(SafariRuleSet.self, from: saved), configuration)
        XCTAssertEqual(try configuration.jsonData(now: now),
                       try SafariRules.jsonData(domains: configuration.domains, activeUntil: configuration.activeUntil, now: now))
    }

    func testExcessiveActiveDomainListIsRejected() {
        XCTAssertThrowsError(try SafariRules.jsonData(domains: Array(repeating: "youtube.com", count: 201),
                                                     activeUntil: now.addingTimeInterval(60), now: now))
    }

    func testSlowInitialReloadCanCompleteAfterTheFormerFifteenSecondDeadline() throws {
        var state = SafariReloadState()
        let inactive = SafariRuleSet()
        let attempt = try XCTUnwrap(state.begin(inactive, now: now, uptime: 100))

        XCTAssertFalse(state.expire(uptime: 120))
        XCTAssertLessThan(20, SafariReloadTiming.setupTimeout)
        XCTAssertTrue(state.complete(id: attempt.id, succeeded: true))
        XCTAssertEqual(state.applied, inactive)
        XCTAssertNil(state.failed)
        XCTAssertNil(state.pending)
        XCTAssertFalse(state.shouldReload(inactive), "A confirmed snapshot needs no second compilation")
    }

    func testMissingCallbackFailsBeforeSetupDeadlineAndWaitsForRetryAuthorization() throws {
        var state = SafariReloadState()
        let active = SafariRuleSet(domains: ["youtube.com"], activeUntil: now.addingTimeInterval(600), sessionID: UUID())
        _ = try XCTUnwrap(state.begin(active, now: now, uptime: 100))

        XCTAssertFalse(state.expire(uptime: 129.999))
        XCTAssertTrue(state.expire(uptime: 130))
        XCTAssertGreaterThan(SafariReloadTiming.setupTimeout,
                             SafariReloadTiming.callbackTimeout + SafariReloadTiming.pollInterval,
                             "The UI must allow the next agent tick to publish the timeout")
        XCTAssertEqual(state.failed, active)
        XCTAssertNil(state.pending)
        XCTAssertNil(state.applied)
        XCTAssertFalse(state.expire(uptime: 160))
        XCTAssertNil(state.begin(active, now: now.addingTimeInterval(60), uptime: 160),
                     "Elapsed time alone must not bypass the worker's retry backoff")
    }

    func testLateActiveCallbackCannotCompleteANewerReleaseRequest() throws {
        var state = SafariReloadState()
        let active = SafariRuleSet(domains: ["youtube.com"], activeUntil: now.addingTimeInterval(600), sessionID: UUID())
        let expired = try XCTUnwrap(state.begin(active, now: now, uptime: 100))
        XCTAssertTrue(state.expire(uptime: 130))

        let inactive = SafariRuleSet()
        let release = try XCTUnwrap(state.begin(inactive, now: now.addingTimeInterval(31), uptime: 131))
        XCTAssertNotEqual(expired.id, release.id)
        XCTAssertFalse(state.complete(id: expired.id, succeeded: true))
        XCTAssertFalse(state.complete(id: expired.id, succeeded: false))
        XCTAssertEqual(state.pending?.id, release.id)
        XCTAssertNil(state.applied)
        XCTAssertNil(state.failed)

        XCTAssertTrue(state.complete(id: release.id, succeeded: true))
        XCTAssertEqual(state.applied, inactive, "Only the current callback may confirm that Safari released the sites")
        XCTAssertFalse(state.complete(id: expired.id, succeeded: true))
        XCTAssertEqual(state.applied, inactive)
    }

    func testLateCallbackInvalidatesAConfirmedReleaseAndSchedulesFreshInactiveRules() throws {
        var state = SafariReloadState()
        let active = SafariRuleSet(domains: ["youtube.com"], activeUntil: now.addingTimeInterval(600), sessionID: UUID())
        let old = try XCTUnwrap(state.begin(active, now: now, uptime: 100))
        XCTAssertTrue(state.expire(uptime: 130))
        let inactive = SafariRuleSet()
        let release = try XCTUnwrap(state.begin(inactive, now: now.addingTimeInterval(31), uptime: 131))
        XCTAssertTrue(state.complete(id: release.id, succeeded: true))
        XCTAssertFalse(state.shouldReload(inactive))

        XCTAssertFalse(state.complete(id: old.id, succeeded: true))
        // The framework request cannot be cancelled. A late callback may mean
        // Safari changed compiled rules after the release was acknowledged.
        state.invalidateApplied()
        XCTAssertNil(state.applied)
        XCTAssertTrue(state.shouldReload(inactive))
        let freshRelease = try XCTUnwrap(state.begin(inactive, now: now.addingTimeInterval(40), uptime: 140))
        XCTAssertTrue(state.complete(id: freshRelease.id, succeeded: true))
        XCTAssertEqual(state.applied, inactive)
    }

    func testLateCallbackInvalidationPreservesAnAlreadyPendingRelease() throws {
        var state = SafariReloadState()
        let active = SafariRuleSet(domains: ["youtube.com"], activeUntil: now.addingTimeInterval(600), sessionID: UUID())
        let old = try XCTUnwrap(state.begin(active, now: now, uptime: 100))
        XCTAssertTrue(state.expire(uptime: 130))
        let inactive = SafariRuleSet()
        let release = try XCTUnwrap(state.begin(inactive, now: now.addingTimeInterval(31), uptime: 131))

        XCTAssertFalse(state.complete(id: old.id, succeeded: true))
        state.invalidateApplied()
        XCTAssertEqual(state.pending?.id, release.id)
        XCTAssertFalse(state.shouldReload(inactive), "Do not overlap a second release with the pending one")
        XCTAssertNil(state.applied)
        XCTAssertTrue(state.complete(id: release.id, succeeded: true))
        XCTAssertEqual(state.applied, inactive)
    }

    func testFailedActiveReloadStillAllowsTheSessionToBeReleased() throws {
        var state = SafariReloadState()
        let active = SafariRuleSet(domains: ["youtube.com"], activeUntil: now.addingTimeInterval(600), sessionID: UUID())
        let attempt = try XCTUnwrap(state.begin(active, now: now, uptime: 100))
        XCTAssertTrue(state.complete(id: attempt.id, succeeded: false))
        XCTAssertFalse(state.shouldReload(active))

        let inactive = SafariRuleSet()
        XCTAssertTrue(state.shouldReload(inactive))
        let release = try XCTUnwrap(state.begin(inactive, now: now.addingTimeInterval(1), uptime: 101))
        XCTAssertTrue(state.complete(id: release.id, succeeded: true))
        XCTAssertEqual(state.applied, inactive)
        XCTAssertNil(state.failed)
    }

    func testExplicitSetupResetAllowsRetryingAFailedSnapshot() throws {
        var state = SafariReloadState()
        let inactive = SafariRuleSet()
        let first = try XCTUnwrap(state.begin(inactive, now: now, uptime: 100))
        XCTAssertTrue(state.complete(id: first.id, succeeded: false))
        XCTAssertNil(state.begin(inactive, now: now.addingTimeInterval(10), uptime: 110))

        // Setup can start a new state without accepting the old callback.
        state = SafariReloadState()
        let retry = try XCTUnwrap(state.begin(inactive, now: now.addingTimeInterval(11), uptime: 111))
        XCTAssertNotEqual(first.id, retry.id)
        XCTAssertFalse(state.complete(id: first.id, succeeded: true))
        XCTAssertEqual(state.pending?.id, retry.id)
        XCTAssertTrue(state.complete(id: retry.id, succeeded: true))
        XCTAssertEqual(state.applied, inactive)
    }

    func testBackoffRetryCanReleaseInactiveRulesWithoutAcceptingTheExpiredCallback() throws {
        var state = SafariReloadState()
        let inactive = SafariRuleSet()
        let expired = try XCTUnwrap(state.begin(inactive, now: now, uptime: 100))
        XCTAssertTrue(state.expire(uptime: 130))
        XCTAssertNil(state.begin(inactive, now: now.addingTimeInterval(59), uptime: 159))

        // The worker authorizes another attempt after its backoff, even when
        // the UI is closed. A transient failure must not strand compiled blocks.
        state.retryFailed()
        let retry = try XCTUnwrap(state.begin(inactive, now: now.addingTimeInterval(60), uptime: 160))
        XCTAssertNotEqual(expired.id, retry.id)
        XCTAssertFalse(state.complete(id: expired.id, succeeded: true))
        XCTAssertEqual(state.pending?.id, retry.id)
        XCTAssertNil(state.applied)
        XCTAssertTrue(state.complete(id: retry.id, succeeded: true))
        XCTAssertEqual(state.applied, inactive)
        XCTAssertNil(state.failed)
    }

    func testNoOverlappingReloadIsStartedEvenWhenTheDesiredSessionChanges() throws {
        var state = SafariReloadState()
        let active = SafariRuleSet(domains: ["youtube.com"], activeUntil: now.addingTimeInterval(600), sessionID: UUID())
        let attempt = try XCTUnwrap(state.begin(active, now: now, uptime: 100))

        XCTAssertNil(state.begin(active, now: now.addingTimeInterval(1), uptime: 101))
        XCTAssertNil(state.begin(SafariRuleSet(), now: now.addingTimeInterval(2), uptime: 102))
        XCTAssertEqual(state.pending?.id, attempt.id)
        XCTAssertTrue(state.complete(id: attempt.id, succeeded: true))
        XCTAssertNotNil(state.begin(SafariRuleSet(), now: now.addingTimeInterval(3), uptime: 103))
        XCTAssertNil(state.applied, "Starting a new compilation invalidates the previous acknowledgment")
    }

    func testReceiptRequiresTheExactFreshSnapshotWithoutAReadError() throws {
        var state = SafariReloadState()
        let active = SafariRuleSet(domains: ["youtube.com"], activeUntil: now.addingTimeInterval(600), sessionID: UUID())
        let attempt = try XCTUnwrap(state.begin(active, now: now, uptime: 100))
        let receipt = SafariRuleReceipt(snapshot: active, generatedAt: now.addingTimeInterval(20))
        let decoded = try JSONDecoder().decode(SafariRuleReceipt.self, from: JSONEncoder().encode(receipt))
        XCTAssertTrue(decoded.confirms(attempt))
        XCTAssertTrue(SafariRuleReceipt(snapshot: active, generatedAt: now.addingTimeInterval(-1)).confirms(attempt))
        XCTAssertFalse(SafariRuleReceipt(snapshot: active, generatedAt: now.addingTimeInterval(-2)).confirms(attempt),
                       "A previous extension request cannot confirm the current reload")
        XCTAssertFalse(SafariRuleReceipt(snapshot: active, generatedAt: now, readError: "App Group unreadable").confirms(attempt))
        XCTAssertFalse(SafariRuleReceipt(snapshot: SafariRuleSet(), generatedAt: now).confirms(attempt))

        var changed = active
        changed.domains = ["reddit.com"]
        XCTAssertFalse(SafariRuleReceipt(snapshot: changed, generatedAt: now).confirms(attempt))
        changed = active
        changed.activeUntil = now.addingTimeInterval(601)
        XCTAssertFalse(SafariRuleReceipt(snapshot: changed, generatedAt: now).confirms(attempt))
        changed = active
        changed.sessionID = UUID()
        XCTAssertFalse(SafariRuleReceipt(snapshot: changed, generatedAt: now).confirms(attempt))
    }

    #if canImport(WebKit)
    @MainActor
    func testWebKitCompilesActiveRuleList() throws {
        let configuration = SafariRuleSet(domains: ["youtube.com", "m.reddit.com", "xn--bcher-kva.de"],
                                          activeUntil: now.addingTimeInterval(60))
        try compileWithWebKit(configuration, name: "active")
    }

    @MainActor
    func testWebKitCompilesInactiveNoOpRuleList() throws {
        try compileWithWebKit(SafariRuleSet(), name: "inactive")
    }

    @MainActor
    func testWebKitAllowsNavigationBeforeAndAfterAnActiveBlock() throws {
        // A loopback-only HTTP server makes the test independent of internet,
        // DNS and external websites. DomainNormalizer intentionally rejects
        // loopback hosts, so a small explicit block is the positive control.
        let server = try SafariLoopbackHTTPServer()
        defer { server.stop() }
        let ready = expectation(description: "Loopback HTTP server is listening")
        var address: Result<URL, Error>?
        server.start { result in
            DispatchQueue.main.async {
                address = result
                ready.fulfill()
            }
        }
        wait(for: [ready], timeout: 5)
        let baseURL = try XCTUnwrap(address).get()

        let inactiveJSON = try XCTUnwrap(String(data: SafariRuleSet().jsonData(now: now), encoding: .utf8))
        let inactive = try compiledWebKitList(json: inactiveJSON, name: "navigation-inactive")
        defer { removeWebKitList(inactive) }
        let active = try compiledWebKitList(
            json: #"[{"trigger":{"url-filter":"^http://127[.]0[.]0[.]1:"},"action":{"type":"block"}}]"#,
            name: "navigation-active-control")
        defer { removeWebKitList(active) }

        let configuration = WKWebViewConfiguration()
        configuration.websiteDataStore = .nonPersistent()
        let webView = WKWebView(frame: .zero, configuration: configuration)
        let contentController = webView.configuration.userContentController
        let probe = SafariNavigationProbe()
        webView.navigationDelegate = probe
        defer {
            webView.stopLoading()
            webView.navigationDelegate = nil
            contentController.removeAllContentRuleLists()
        }

        contentController.add(inactive)
        try navigate(webView, probe: probe, to: baseURL.appendingPathComponent("initial-inactive")).get()
        XCTAssertEqual(webView.title, SafariLoopbackHTTPServer.pageTitle)

        contentController.removeAllContentRuleLists()
        contentController.add(active)
        switch try navigate(webView, probe: probe, to: baseURL.appendingPathComponent("active")) {
        case .success:
            XCTFail("The positive control must block the actual HTTP navigation")
        case .failure(let error):
            let failure = error as NSError
            XCTAssertEqual(failure.domain, "WebKitErrorDomain")
            XCTAssertEqual(failure.code, 104, "WebKit's content-blocker error must cause the failure")
        }

        contentController.removeAllContentRuleLists()
        contentController.add(inactive)
        try navigate(webView, probe: probe, to: baseURL.appendingPathComponent("released")).get()
        XCTAssertEqual(webView.title, SafariLoopbackHTTPServer.pageTitle)
    }

    @MainActor
    private func navigate(_ webView: WKWebView, probe: SafariNavigationProbe, to url: URL) throws -> Result<Void, Error> {
        let finished = expectation(description: "Navigate to \(url.lastPathComponent)")
        var result: Result<Void, Error>?
        probe.completion = {
            result = $0
            finished.fulfill()
        }
        defer { probe.completion = nil }
        webView.load(URLRequest(url: url, cachePolicy: .reloadIgnoringLocalCacheData, timeoutInterval: 10))
        wait(for: [finished], timeout: 15)
        return try XCTUnwrap(result)
    }

    /// Foundation's regular expression engine accepts constructs that WebKit's
    /// content-blocker compiler rejects. Exercise the real compiler on macOS.
    @MainActor
    private func compileWithWebKit(_ configuration: SafariRuleSet, name: String) throws {
        let data = try configuration.jsonData(now: now)
        let json = try XCTUnwrap(String(data: data, encoding: .utf8))
        let list = try compiledWebKitList(json: json, name: name)
        removeWebKitList(list)
    }

    @MainActor
    private func compiledWebKitList(json: String, name: String) throws -> WKContentRuleList {
        let identifier = "ForE-SafariRulesTests-\(name)-\(UUID().uuidString)"
        let finished = expectation(description: "Compile \(name) WebKit content rule list")
        let store = try XCTUnwrap(WKContentRuleListStore.default())
        var compiled: WKContentRuleList?
        store.compileContentRuleList(forIdentifier: identifier, encodedContentRuleList: json) { list, error in
            XCTAssertNil(error, "WebKit rejected the generated \(name) rules: \(String(describing: error))")
            compiled = list
            finished.fulfill()
        }
        wait(for: [finished], timeout: 20)
        return try XCTUnwrap(compiled)
    }

    @MainActor
    private func removeWebKitList(_ list: WKContentRuleList) {
        let removed = expectation(description: "Remove temporary WebKit content rule list")
        WKContentRuleListStore.default()?.removeContentRuleList(forIdentifier: list.identifier) { error in
            XCTAssertNil(error, "The temporary compiled rule list should be removed")
            removed.fulfill()
        }
        wait(for: [removed], timeout: 5)
    }
    #endif
}

#if canImport(WebKit)
@MainActor
private final class SafariNavigationProbe: NSObject, WKNavigationDelegate {
    var completion: ((Result<Void, Error>) -> Void)?

    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        finish(.success(()))
    }

    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
        finish(.failure(error))
    }

    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
        finish(.failure(error))
    }

    private func finish(_ result: Result<Void, Error>) {
        let callback = completion
        completion = nil
        callback?(result)
    }
}

/// A minimal HTTP fixture restricted to 127.0.0.1 and an ephemeral port.
/// All listener/connection state is confined to its serial queue.
private final class SafariLoopbackHTTPServer {
    static let pageTitle = "ForE loopback test"
    private let listener: NWListener
    private let queue = DispatchQueue(label: "ForE.SafariRulesTests.HTTP")
    private var connections: [NWConnection] = []

    init() throws {
        let parameters = NWParameters.tcp
        parameters.requiredLocalEndpoint = .hostPort(host: "127.0.0.1", port: .any)
        listener = try NWListener(using: parameters)
    }

    func start(ready: @escaping (Result<URL, Error>) -> Void) {
        var reported = false
        listener.stateUpdateHandler = { [weak self] state in
            guard let self, !reported else { return }
            switch state {
            case .ready:
                guard let port = self.listener.port,
                      let url = URL(string: "http://127.0.0.1:\(port.rawValue)/") else { return }
                reported = true
                ready(.success(url))
            case .failed(let error):
                reported = true
                ready(.failure(error))
            default: break
            }
        }
        listener.newConnectionHandler = { [weak self] connection in
            guard let self else { connection.cancel(); return }
            self.connections.append(connection)
            connection.start(queue: self.queue)
            self.receiveRequest(on: connection, buffered: Data())
        }
        listener.start(queue: queue)
    }

    func stop() {
        queue.sync {
            listener.cancel()
            connections.forEach { $0.cancel() }
            connections.removeAll()
        }
    }

    private func receiveRequest(on connection: NWConnection, buffered: Data) {
        connection.receive(minimumIncompleteLength: 1, maximumLength: 16_384) { [weak self] data, _, complete, error in
            guard let self else { connection.cancel(); return }
            var request = buffered
            if let data { request.append(data) }
            if request.range(of: Data("\r\n\r\n".utf8)) != nil {
                let body = "<!doctype html><title>\(Self.pageTitle)</title><p>Local response</p>"
                let response = "HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\n"
                    + "Content-Length: \(body.utf8.count)\r\nCache-Control: no-store\r\nConnection: close\r\n\r\n" + body
                connection.send(content: Data(response.utf8), completion: .contentProcessed { _ in connection.cancel() })
            } else if complete || error != nil || request.count > 65_536 {
                connection.cancel()
            } else {
                self.receiveRequest(on: connection, buffered: request)
            }
        }
    }
}
#endif

final class SafariAgentSchedulerTests: XCTestCase {
    func testInitializationPrecedesTheFirstSystemRequestAndRunsOffMainThread() {
        let scheduler = SafariAgentScheduler()
        let events = SchedulerTestEvents()
        let requested = expectation(description: "The first system request sees the initializing heartbeat")
        defer { scheduler.stop() }

        scheduler.start(interval: 60, initialize: {
            XCTAssertFalse(Thread.isMainThread)
            events.append("initializing")
        }, tick: {
            XCTAssertFalse(Thread.isMainThread)
            events.append("tick")
            scheduler.performRequest {
                XCTAssertFalse(Thread.isMainThread)
                events.append("request")
                XCTAssertEqual(events.snapshot(), ["initializing", "tick", "request"])
                requested.fulfill()
            }
        })

        wait(for: [requested], timeout: 2)
    }

    func testBlockedSystemRequestDoesNotPreventHeartbeatsOrStateResults() {
        let scheduler = SafariAgentScheduler()
        let gate = DispatchSemaphore(value: 0)
        let events = SchedulerTestEvents()
        let requestEntered = expectation(description: "A synchronous system API entry is blocked")
        let heartbeats = expectation(description: "Heartbeats continue while the request is blocked")
        heartbeats.expectedFulfillmentCount = 3
        let stateResult = expectation(description: "State results still run during the blocked request")
        let requestExited = expectation(description: "The deliberately blocked test request is released")
        defer {
            gate.signal()
            wait(for: [requestExited], timeout: 2)
            scheduler.stop()
        }

        scheduler.start(interval: 0.01, initialize: {}, tick: {
            if events.markFirstTick() {
                scheduler.performRequest {
                    events.setRequestBlocked(true)
                    requestEntered.fulfill()
                    gate.wait()
                    events.setRequestBlocked(false)
                    requestExited.fulfill()
                }
            } else if events.recordHeartbeatWhileBlocked() {
                XCTAssertFalse(Thread.isMainThread)
                heartbeats.fulfill()
            }
        })

        wait(for: [requestEntered], timeout: 2)
        scheduler.receiveResult {
            XCTAssertFalse(Thread.isMainThread)
            XCTAssertTrue(events.isRequestBlocked())
            stateResult.fulfill()
        }
        wait(for: [heartbeats, stateResult], timeout: 2)
    }

    func testResultCallbacksShareOrderedStateWithInitializationAndTicks() {
        let scheduler = SafariAgentScheduler()
        let finished = expectation(description: "Every result updates the serial agent state in order")
        var nextResult = -1
        defer { scheduler.stop() }

        scheduler.start(interval: 60, initialize: {
            nextResult = 0
        }, tick: {
            XCTAssertEqual(nextResult, 0)
        })
        for index in 0..<100 {
            scheduler.receiveResult {
                XCTAssertFalse(Thread.isMainThread)
                XCTAssertEqual(nextResult, index)
                nextResult += 1
                if index == 99 { finished.fulfill() }
            }
        }
        wait(for: [finished], timeout: 2)
    }
}

private final class SchedulerTestEvents: @unchecked Sendable {
    private let lock = NSLock()
    private var values: [String] = []
    private var firstTick = true
    private var blocked = false
    private var heartbeatCount = 0

    func append(_ value: String) {
        lock.lock()
        defer { lock.unlock() }
        values.append(value)
    }

    func snapshot() -> [String] {
        lock.lock()
        defer { lock.unlock() }
        return values
    }

    func markFirstTick() -> Bool {
        lock.lock()
        defer { lock.unlock() }
        guard firstTick else { return false }
        firstTick = false
        return true
    }

    func setRequestBlocked(_ value: Bool) {
        lock.lock()
        defer { lock.unlock() }
        blocked = value
    }

    func isRequestBlocked() -> Bool {
        lock.lock()
        defer { lock.unlock() }
        return blocked
    }

    func recordHeartbeatWhileBlocked() -> Bool {
        lock.lock()
        defer { lock.unlock() }
        guard blocked, heartbeatCount < 3 else { return false }
        heartbeatCount += 1
        return true
    }
}
