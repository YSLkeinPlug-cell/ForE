import Foundation
import XCTest
@testable import ForECore
#if canImport(WebKit)
import WebKit
#endif

final class SafariRulesTests: XCTestCase {
    private let now = Date(timeIntervalSince1970: 1_800_000_000)

    private func rules(_ domains: [String], activeUntil: Date? = nil) throws -> [[String: Any]] {
        let data = try SafariRules.jsonData(domains: domains, activeUntil: activeUntil ?? now.addingTimeInterval(600), now: now)
        return try XCTUnwrap(JSONSerialization.jsonObject(with: data) as? [[String: Any]])
    }

    private func matches(_ url: String, in rules: [[String: Any]]) throws -> Bool {
        try rules.contains { rule in
            let trigger = try XCTUnwrap(rule["trigger"] as? [String: Any])
            let filter = try XCTUnwrap(trigger["url-filter"] as? String)
            let sensitive = trigger["url-filter-is-case-sensitive"] as? Bool ?? false
            let regex = try NSRegularExpression(pattern: filter, options: sensitive ? [] : [.caseInsensitive])
            return regex.firstMatch(in: url, range: NSRange(url.startIndex..., in: url)) != nil
        }
    }

    func testActiveRulesBlockExactDomainAndWWWOverHTTPAndHTTPS() throws {
        let generated = try rules(["youtube.com"])
        for url in ["https://youtube.com", "http://youtube.com/", "https://www.youtube.com/watch?v=123",
                    "https://YOUTUBE.COM/", "https://youtube.com?search=hi", "https://youtube.com#section",
                    "https://youtube.com:8443/watch", "http://www.youtube.com:80", "https://youtube.com./",
                    "https://user:password@youtube.com/", "https://user%40name@www.youtube.com:8443/path",
                    "https://@youtube.com/"] {
            XCTAssertTrue(try matches(url, in: generated), url)
        }
    }

    func testRulesDoNotBlockLookalikeHostsOrUnselectedSubdomains() throws {
        let generated = try rules(["youtube.com"])
        for url in ["https://notyoutube.com/", "https://youtubeXcom/", "https://youtube.com.evil.org/",
                    "https://youtube.com@evil.org/", "https://www.youtube.com.evil.org/", "https://m.youtube.com/",
                    "https://www.www.youtube.com/", "https://other.org/?url=https://youtube.com/",
                    "ftp://youtube.com/", "https://youtube.com:abc/", "https://youtube.com:80.evil.org/",
                    "https://youtube.comevil/", "https://youtube.com../"] {
            XCTAssertFalse(try matches(url, in: generated), url)
        }
    }

    func testExplicitSubdomainDoesNotBlockParentOrSiblings() throws {
        let generated = try rules(["m.youtube.com"])
        XCTAssertTrue(try matches("https://m.youtube.com/", in: generated))
        XCTAssertTrue(try matches("https://www.m.youtube.com/", in: generated))
        XCTAssertFalse(try matches("https://youtube.com/", in: generated))
        XCTAssertFalse(try matches("https://other.youtube.com/", in: generated))
    }

    func testEmptyMissingAndExpiredConfigurationsRemainNonblocking() throws {
        let inputs: [([String], Date?)] = [([], now.addingTimeInterval(600)), (["youtube.com"], nil),
                                         (["youtube.com"], now), (["youtube.com"], now.addingTimeInterval(-1)),
                                         (["bad\ninput"], now.addingTimeInterval(-1))]
        for (domains, deadline) in inputs {
            let data = try SafariRules.jsonData(domains: domains, activeUntil: deadline, now: now)
            let generated = try XCTUnwrap(JSONSerialization.jsonObject(with: data) as? [[String: Any]])
            XCTAssertEqual(generated.count, 1, "WebKit rejects an empty rule list")
            for url in ["https://youtube.com/", "http://www.youtube.com/", "https://other.org/", "about:blank", "file:///tmp/file"] {
                XCTAssertFalse(try matches(url, in: generated), url)
            }
        }
    }

    func testMaliciousActiveDomainsAreRejected() {
        for domain in ["youtube.com\n0.0.0.0 apple.com", "foo.com\"}", "foo.com|.*", "*.youtube.com",
                       "foo.com$", "foo.com[", "https://user:pass@foo.com", "https://foo.com:443", "bücher.de"] {
            XCTAssertThrowsError(try SafariRules.jsonData(domains: [domain], activeUntil: now.addingTimeInterval(10), now: now), domain)
        }
    }

    func testPastedURLsNormalizeAndDuplicatesHaveDeterministicRules() throws {
        let a = try SafariRules.jsonData(domains: ["reddit.com", "https://WWW.YouTube.com/watch", "youtube.com"],
                                        activeUntil: now.addingTimeInterval(60), now: now)
        let b = try SafariRules.jsonData(domains: ["youtube.com", "reddit.com"],
                                        activeUntil: now.addingTimeInterval(60), now: now)
        XCTAssertEqual(a, b)
        XCTAssertEqual(try XCTUnwrap(JSONSerialization.jsonObject(with: a) as? [Any]).count, 4)
    }

    func testPunycodeAndLiteralDots() throws {
        let generated = try rules(["xn--bcher-kva.de"])
        XCTAssertTrue(try matches("https://xn--bcher-kva.de/books", in: generated))
        XCTAssertFalse(try matches("https://xn--bcher-kvaXde/books", in: generated))
        XCTAssertFalse(try matches("https://xn--bcher-kva.de.example.org/", in: generated))
    }

    func testOutputUsesWebKitSupportedRegexSubsetAndBlocksAllResourceTypes() throws {
        for rule in try rules(["youtube.com", "reddit.com"]) {
            let trigger = try XCTUnwrap(rule["trigger"] as? [String: Any])
            let action = try XCTUnwrap(rule["action"] as? [String: Any])
            let filter = try XCTUnwrap(trigger["url-filter"] as? String)
            XCTAssertTrue(filter.hasPrefix("^https?://"))
            XCTAssertFalse(filter.contains("|"), "WebKit rejects disjunction")
            XCTAssertFalse(filter.contains("(?"), "No lookaround or noncapturing groups")
            XCTAssertFalse(filter.contains("{"), "Only ?, * and + quantifiers are supported")
            XCTAssertNil(trigger["if-domain"], "if-domain checks document context, not the resource host")
            XCTAssertNil(trigger["resource-type"], "Also block embedded requests to selected domains")
            XCTAssertEqual(action["type"] as? String, "block")
        }
    }

    func testRuleSetConfigurationRoundTripsAndDelegates() throws {
        let configuration = SafariRuleSet(domains: ["youtube.com"], activeUntil: now.addingTimeInterval(60), sessionID: UUID())
        let saved = try JSONEncoder().encode(configuration)
        XCTAssertEqual(try JSONDecoder().decode(SafariRuleSet.self, from: saved), configuration)
        XCTAssertEqual(try configuration.jsonData(now: now),
                       try SafariRules.jsonData(domains: configuration.domains, activeUntil: configuration.activeUntil, now: now))
    }

    func testExcessiveActiveDomainListIsRejected() {
        XCTAssertThrowsError(try SafariRules.jsonData(domains: Array(repeating: "youtube.com", count: 201),
                                                     activeUntil: now.addingTimeInterval(60), now: now))
    }

    #if canImport(WebKit)
    @MainActor
    func testWebKitCompilesActiveRuleList() throws {
        let configuration = SafariRuleSet(domains: ["youtube.com", "m.reddit.com", "xn--bcher-kva.de"],
                                          activeUntil: now.addingTimeInterval(60))
        try compileWithWebKit(configuration, name: "active")
    }

    @MainActor
    func testWebKitCompilesInactiveNoOpRuleList() throws {
        try compileWithWebKit(SafariRuleSet(), name: "inactive")
    }

    /// Foundation's regular expression engine accepts constructs that WebKit's
    /// content-blocker compiler rejects. Exercise the real compiler on macOS.
    @MainActor
    private func compileWithWebKit(_ configuration: SafariRuleSet, name: String) throws {
        let data = try configuration.jsonData(now: now)
        let json = try XCTUnwrap(String(data: data, encoding: .utf8))
        let identifier = "ForE-SafariRulesTests-\(name)-\(UUID().uuidString)"
        let finished = expectation(description: "Compile and remove \(name) WebKit content rule list")
        let store = try XCTUnwrap(WKContentRuleListStore.default())
        store.compileContentRuleList(forIdentifier: identifier, encodedContentRuleList: json) { list, error in
            XCTAssertNil(error, "WebKit rejected the generated \(name) rules: \(String(describing: error))")
            XCTAssertNotNil(list)
            guard list != nil else { finished.fulfill(); return }
            store.removeContentRuleList(forIdentifier: identifier) { removalError in
                XCTAssertNil(removalError, "The temporary compiled rule list should be removed")
                finished.fulfill()
            }
        }
        wait(for: [finished], timeout: 20)
    }
    #endif
}
