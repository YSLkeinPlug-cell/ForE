import XCTest
@testable import ForEBlocking

final class HostsDocumentTests: XCTestCase {
    private let begin = "# BEGIN FORE BLOCK"
    private let end = "# END FORE BLOCK"

    func testRemovalPreservesUnrelatedEntriesCommentsAndUnicodeExactly() throws {
        let prefix = "# Persönliche Zuordnung 🌱\n127.0.0.1 localhost\n::1 localhost\n\n"
        let suffix = "# VPN entries must survive\n10.0.1.20 intranet.example.org\n"
        let managed = "\(begin)\n0.0.0.0 youtube.com\n:: youtube.com\n\(end)\n"
        XCTAssertEqual(try HostsDocument.removingBlock(from: prefix + managed + suffix), prefix + suffix)
        XCTAssertEqual(try HostsDocument.removingBlock(from: prefix + suffix), prefix + suffix)
    }

    func testApplicationWritesIPv4IPv6AndWwwAliasesWithoutDuplicates() throws {
        let result = try HostsDocument.applying(domains: ["youtube.com", "youtube.com", "www.youtube.com"], to: "")
        let lines = result.split(separator: "\n").map(String.init)
        for entry in ["0.0.0.0 youtube.com", ":: youtube.com", "0.0.0.0 www.youtube.com", ":: www.youtube.com"] {
            XCTAssertEqual(lines.filter { $0 == entry }.count, 1)
        }
        XCTAssertFalse(result.contains("www.www."))
    }

    func testApplicationIsIdempotentAndReplacesOnlyItsOwnDomains() throws {
        let original = "127.0.0.1 localhost\n# unrelated\n"
        let first = try HostsDocument.applying(domains: ["reddit.com", "youtube.com"], to: original)
        XCTAssertEqual(try HostsDocument.applying(domains: ["youtube.com", "reddit.com"], to: first), first)
        let replacement = try HostsDocument.applying(domains: ["example.org"], to: first)
        XCTAssertFalse(replacement.contains("reddit.com"))
        XCTAssertFalse(replacement.contains("youtube.com"))
        XCTAssertEqual(try HostsDocument.removingBlock(from: replacement), original)
    }

    func testMalformedDuplicateReversedAndInlineMarkersAreRejected() {
        let valid = "\(begin)\n0.0.0.0 example.org\n\(end)\n"
        let malformed = [
            "\(begin)\n", "\(end)\n", "\(end)\n\(begin)\n", valid + valid,
            "\(begin)\n\(begin)\n\(end)\n\(end)\n",
            "prefix \(begin)\n\(end)\n", "\(begin) suffix\n\(end)\n",
            "\(begin)\ninline \(end)\n", "\(begin)\n\(end) suffix\n"
        ]
        for text in malformed {
            XCTAssertThrowsError(try HostsDocument.removingBlock(from: text), text)
            XCTAssertThrowsError(try HostsDocument.applying(domains: ["example.org"], to: text), text)
        }
    }

    func testLineBoundariesHandleEmptyNoFinalNewlineAndCRLFDocuments() throws {
        let empty = try HostsDocument.applying(domains: ["example.org"], to: "")
        XCTAssertTrue(empty.hasPrefix(begin + "\n"))
        XCTAssertEqual(try HostsDocument.removingBlock(from: empty), "")
        let missingNewline = try HostsDocument.applying(domains: ["example.org"], to: "127.0.0.1 localhost")
        XCTAssertTrue(missingNewline.hasPrefix("127.0.0.1 localhost\n" + begin))
        // The separator is intentionally retained; unrelated content is never
        // trimmed or guessed away when removing the managed section.
        XCTAssertEqual(try HostsDocument.removingBlock(from: missingNewline), "127.0.0.1 localhost\n")
        let crlfPrefix = "# local\r\n127.0.0.1 localhost\r\n"
        XCTAssertTrue(try HostsDocument.applying(domains: ["example.org"], to: crlfPrefix).hasPrefix(crlfPrefix + begin))
        let crlfSection = "\(begin)\r\n0.0.0.0 example.org\r\n\(end)\r\n"
        XCTAssertEqual(try HostsDocument.removingBlock(from: crlfPrefix + crlfSection + "# tail\r\n"), crlfPrefix + "# tail\r\n")
        XCTAssertEqual(try HostsDocument.removingBlock(from: "\(begin)\n\(end)"), "")
    }

    func testSubdomainBlockingIsBoundedAndDoesNotInventWildcardRules() throws {
        let result = try HostsDocument.applying(domains: ["news.example.org", "www.example.net"], to: "")
        XCTAssertTrue(result.contains("0.0.0.0 news.example.org\n"))
        XCTAssertTrue(result.contains(":: www.news.example.org\n"))
        XCTAssertFalse(result.contains("0.0.0.0 example.org\n"))
        XCTAssertFalse(result.contains("api.example.org"))
        XCTAssertFalse(result.contains("*."))
        XCTAssertFalse(result.contains("www.www.example.net"))
        // A www alias may not exceed the DNS hostname limit of 253 bytes.
        let longDomain = Array(repeating: String(repeating: "a", count: 62), count: 4).joined(separator: ".")
        let longResult = try HostsDocument.applying(domains: [longDomain], to: "")
        XCTAssertFalse(longResult.contains("www." + longDomain))
    }

    func testCallerCannotInjectHostsLinesOrMarkersThroughDomainInput() {
        for domain in ["example.org\n127.0.0.1 injected", "example.org \(end)", "https://example.org", ""] {
            XCTAssertThrowsError(try HostsDocument.applying(domains: [domain], to: ""))
        }
    }
}
