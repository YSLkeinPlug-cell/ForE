import Foundation
import SwiftUI

/// launchd executes the containing app binary in a separate, non-UI process.
/// Using this bundle also gives SafariServices the containing extension identity.
@main
enum ForEMain {
    @MainActor
    static func main() {
        if CommandLine.arguments.contains("--safari-agent") {
            SafariAgent.run()
        } else {
            ForEApp.main()
        }
    }
}
