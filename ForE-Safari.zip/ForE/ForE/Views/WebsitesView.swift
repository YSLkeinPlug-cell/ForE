import SwiftUI

struct WebsitesView: View {
    @EnvironmentObject private var model: AppModel
    @State private var input = ""
    @State private var feedback: String?
    @State private var isError = false

    var body: some View {
        VStack(alignment: .leading, spacing: 26) {
            PageHeading(eyebrow: "Weniger Tabs. Mehr Klarheit.", title: "Ablenkungen haben Pause.",
                subtitle: "Du entscheidest, welche Websites während deiner Fokuszeit warten dürfen.")
            VStack(alignment: .leading, spacing: 18) {
                HStack {
                    Label("Deine Website-Liste", systemImage: "globe.europe.africa")
                        .font(.system(size: 17, weight: .semibold, design: .rounded))
                    Spacer()
                    Text("\(model.data.domains.count) / 100").font(.system(size: 11)).foregroundStyle(ForestStyle.muted)
                }
                HStack(spacing: 12) {
                    HStack {
                        Image(systemName: "link").foregroundStyle(ForestStyle.muted)
                        TextField("Website oder URL, z. B. youtube.com", text: $input)
                            .textFieldStyle(.plain).onSubmit(add)
                            .accessibilityLabel("Website zur Sperrliste hinzufügen")
                    }.padding(13).background(ForestStyle.background, in: RoundedRectangle(cornerRadius: 11))
                    Button(action: add) { Label("Hinzufügen", systemImage: "plus") }
                        .buttonStyle(ForestButtonStyle()).frame(width: 150)
                        .disabled(!model.canEdit || input.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                }.disabled(!model.canEdit)
                if let feedback {
                    Label(feedback, systemImage: isError ? "exclamationmark.circle" : "checkmark.circle")
                        .font(.system(size: 12)).foregroundStyle(isError ? Color.red : ForestStyle.green)
                        .accessibilityLabel(feedback)
                }
                if !model.canEdit {
                    Label("Während einer Sitzung bleibt die Liste unverändert.", systemImage: "lock")
                        .font(.system(size: 12)).foregroundStyle(ForestStyle.muted)
                }
                if model.data.domains.isEmpty {
                    VStack(spacing: 12) {
                        Image(systemName: "globe").font(.system(size: 32)).foregroundStyle(ForestStyle.green)
                        Text("Was lenkt dich ab?").font(.system(size: 16, weight: .semibold))
                        Text("Füge deine erste Website hinzu, um loszulegen.").foregroundStyle(ForestStyle.muted)
                    }.frame(maxWidth: .infinity).padding(35)
                } else {
                    VStack(spacing: 0) {
                        ForEach(model.data.domains, id: \.self) { domain in
                            HStack(spacing: 14) {
                                Text(String(domain.prefix(1)).uppercased())
                                    .font(.system(size: 13, weight: .semibold, design: .rounded))
                                    .frame(width: 36, height: 36).background(ForestStyle.pale, in: RoundedRectangle(cornerRadius: 10))
                                    .foregroundStyle(ForestStyle.green)
                                VStack(alignment: .leading, spacing: 4) {
                                    Text(domain).font(.system(size: 13, weight: .medium))
                                    Text("Domain + www · während deiner Fokuszeit")
                                        .font(.system(size: 10)).foregroundStyle(ForestStyle.muted)
                                }
                                Spacer()
                                Button { model.removeDomain(domain) } label: {
                                    Image(systemName: "minus.circle").font(.system(size: 16)).padding(8)
                                }.buttonStyle(.plain).foregroundStyle(ForestStyle.muted)
                                    .disabled(!model.canEdit).help("\(domain) entfernen")
                                    .accessibilityLabel("\(domain) entfernen")
                            }.padding(.vertical, 12)
                            if domain != model.data.domains.last { Divider().overlay(ForestStyle.border) }
                        }
                    }
                }
            }.foregroundStyle(ForestStyle.ink).forestCard()

            VStack(alignment: .leading, spacing: 14) {
                Eyebrow(text: "Häufige Ablenkungen")
                HStack(spacing: 8) {
                    ForEach(["youtube.com", "instagram.com", "reddit.com", "tiktok.com"], id: \.self) { domain in
                        Button {
                            input = domain
                            add()
                        } label: {
                            Label(domain, systemImage: model.data.domains.contains(domain) ? "checkmark" : "plus")
                                .font(.system(size: 11)).padding(10)
                                .background(.white, in: Capsule())
                        }.buttonStyle(.plain).disabled(!model.canEdit || model.data.domains.contains(domain))
                    }
                }
            }
            VStack(alignment: .leading, spacing: 9) {
                Label("Eine bewusste Hürde, kein unüberwindbares Schloss", systemImage: "info.circle")
                    .font(.system(size: 13, weight: .semibold))
                Text("ForE ergänzt zeitweise die systemweite Hosts-Datei und kann zusätzlich direkt in Safari sperren – auch mit Privat-Relay. Richte dafür den Safari-Schutz in den Einstellungen ein. Weitere Unterdomains wie m.youtube.com musst du separat hinzufügen. Bei der Hosts-Sperre können eigenes DNS, VPNs und bestehende Verbindungen die Wirkung einschränken. Schließe offene Tabs vor dem Start. Andere Websites bleiben erreichbar.")
                    .font(.system(size: 12)).lineSpacing(5).foregroundStyle(ForestStyle.muted)
            }.foregroundStyle(ForestStyle.ink).padding(22)
                .background(ForestStyle.pale.opacity(0.6), in: RoundedRectangle(cornerRadius: 16))
        }
    }

    private func add() {
        guard model.canEdit else { return }
        do {
            try model.addDomain(input)
            input = ""
            isError = false
            feedback = "Deine Website-Liste ist gespeichert."
        } catch {
            isError = true
            feedback = error.localizedDescription
        }
    }
}
