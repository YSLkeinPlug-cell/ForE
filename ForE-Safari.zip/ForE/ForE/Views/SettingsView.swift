import SwiftUI

struct SettingsView: View {
    @EnvironmentObject private var model: AppModel
    @EnvironmentObject private var safari: SafariProtection

    var body: some View {
        VStack(alignment: .leading, spacing: 26) {
            PageHeading(eyebrow: "Fokus nach deinen Regeln.", title: "Ein guter Rahmen für dich.",
                subtitle: "Kleine Einstellungen. Ein bisschen mehr Ruhe im Alltag.")
            safariSettings
            VStack(alignment: .leading, spacing: 22) {
                Text("Deine Routine").font(.system(size: 17, weight: .semibold, design: .rounded))
                HStack {
                    VStack(alignment: .leading, spacing: 5) {
                        Text("Tägliches Fokusziel").font(.system(size: 13, weight: .medium))
                        Text("Eine Orientierung für dich – ohne Druck.").font(.system(size: 11)).foregroundStyle(ForestStyle.muted)
                    }
                    Spacer()
                    Text("\(model.data.dailyGoalMinutes) Min.").font(.system(size: 13, weight: .medium)).monospacedDigit()
                    Stepper("Tagesziel", value: Binding(get: { model.data.dailyGoalMinutes }, set: model.setGoal),
                        in: 15...480, step: 15).labelsHidden().accessibilityLabel("Tagesziel in Minuten")
                }
                Divider()
                Toggle(isOn: $model.soundEnabled) {
                    VStack(alignment: .leading, spacing: 5) {
                        Text("Ein leiser Abschluss").font(.system(size: 13, weight: .medium))
                        Text("Spiele einen Ton, wenn die Sitzung bei geöffneter App endet.")
                            .font(.system(size: 11)).foregroundStyle(ForestStyle.muted)
                    }
                }.toggleStyle(.switch)
            }.forestCard()

            VStack(alignment: .leading, spacing: 18) {
                Label("So funktioniert die Systemsperre", systemImage: "lock.shield")
                    .font(.system(size: 17, weight: .semibold, design: .rounded))
                detail("Mit deiner Erlaubnis", "Beim Start und beim vorzeitigen Beenden fragt macOS nach einem Administratorzugang. Es wird nur der markierte ForE-Abschnitt in /etc/hosts geändert.")
                detail("Die App darf geschlossen werden", "Ein Systemhelfer hebt die Hosts-Sperre nach Ablauf auf. Für Safari aktualisiert ein eigener Hintergrundagent die Regeln, auch nach dem Schließen der App. Der Agent muss in den macOS-Anmeldeobjekten erlaubt bleiben. Im Ruhezustand läuft die Zeit weiter; nach dem Aufwachen wird die Freigabe nachgeholt.")
                detail("Für diesen Mac", "Die Sperre gilt systemweit und damit auch für andere angemeldete Benutzer. Die Website-Liste gilt jeweils für die nächste Sitzung. ForE ist kein manipulationssicherer Filter und sperrt nicht den gesamten Internetzugang.")
            }.forestCard()

            VStack(alignment: .leading, spacing: 18) {
                Label("Deine Daten bleiben bei dir", systemImage: "externaldrive")
                    .font(.system(size: 17, weight: .semibold, design: .rounded))
                Text("Kein Konto. Keine Cloud. Keine Analyse-Tracker. Website-Liste und Fokusverlauf liegen lokal unter ~/Library/Application Support/ForE. Der Systemhelfer speichert den aktuellen Status und den letzten Sitzungsnachweis unter /Library/Application Support/ForE; die Domainnamen darin sind für lokale Benutzer lesbar.")
                    .font(.system(size: 12)).foregroundStyle(ForestStyle.muted).lineSpacing(5)
                Button { model.revealHistory() } label: { Label("Lokale Verlaufsdatei im Finder zeigen", systemImage: "folder") }
                    .buttonStyle(.bordered)
                Text("ForE 1.0 · Entwickelt für macOS 13 und neuer").font(.system(size: 10)).foregroundStyle(ForestStyle.muted)
            }.forestCard()
        }.foregroundStyle(ForestStyle.ink)
    }

    private var safariSettings: some View {
        VStack(alignment: .leading, spacing: 18) {
            Label("Safari-Schutz mit Privat-Relay", systemImage: "safari")
                .font(.system(size: 17, weight: .semibold, design: .rounded))
            Toggle(isOn: Binding(get: { model.safariProtectionRequested }, set: model.setSafariProtectionRequested)) {
                Text("Bestätigten Safari-Schutz für neue Sitzungen voraussetzen")
                    .font(.system(size: 13, weight: .medium))
            }.toggleStyle(.switch).disabled(!model.canEdit)
            Text("Die Erweiterung prüft URLs direkt in Safari, bevor DNS oder Privat-Relay verwendet werden. Sie liest keine Seiteninhalte. Die Freigabe erfolgt durch den Hintergrundagenten.")
                .font(.system(size: 12)).foregroundStyle(ForestStyle.muted).lineSpacing(4)
            HStack(spacing: 24) {
                Label(safari.enabledInSafari ? "Erweiterung aktiviert" : "Erweiterung nicht aktiviert",
                    systemImage: safari.enabledInSafari ? "checkmark.circle.fill" : "circle")
                Label(safari.agentReady ? "Hintergrundagent bereit" : "Hintergrundagent nicht bereit",
                    systemImage: safari.agentReady ? "checkmark.circle.fill" : "circle")
            }.font(.system(size: 11)).foregroundStyle(safari.isReady ? ForestStyle.green : ForestStyle.muted)
            if let message = safari.setupMessage {
                Text(message).font(.system(size: 12)).foregroundStyle(ForestStyle.gold).lineSpacing(4).textSelection(.enabled)
            }
            HStack {
                Button { model.prepareSafari() } label: {
                    HStack {
                        if safari.isBusy { ProgressView().controlSize(.small) }
                        Text(safari.isBusy ? "Wird eingerichtet …" : "Hintergrundagent einrichten")
                    }
                }.buttonStyle(.borderedProminent).disabled(safari.isBusy || !model.canEdit)
                Button("Anmeldeobjekte öffnen") { safari.openBackgroundSettings() }.buttonStyle(.bordered)
                Button("Status prüfen") { model.refreshSafariStatus() }.buttonStyle(.bordered)
            }
            detail("Einmalig auf deinem Mac", "Signiere App und Erweiterung mit demselben Apple-Team und derselben App Group. Starte die gebaute App möglichst aus Programme. Aktiviere anschließend „ForE Safari-Schutz“ in Safari → Einstellungen → Erweiterungen und erlaube ForE unter Systemeinstellungen → Allgemein → Anmeldeobjekte. Die Xcode-Schritte stehen in Documentation/Safari-Setup.md.")
            detail("Wenn eine Freigabe ausbleibt", "Falls macOS den Agenten beendet, du ihn deaktivierst oder Safari die Aktualisierung ablehnt, schalte „ForE Safari-Schutz“ in Safari → Einstellungen → Erweiterungen aus. Damit lässt sich eine gespeicherte Safari-Sperre sofort umgehen. Andere Safari-Inhaltsblocker werden von ForE nicht geändert.")
        }.forestCard()
    }

    private func detail(_ title: String, _ text: String) -> some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(title).font(.system(size: 12, weight: .semibold))
            Text(text).font(.system(size: 12)).foregroundStyle(ForestStyle.muted).lineSpacing(5)
        }
    }
}
