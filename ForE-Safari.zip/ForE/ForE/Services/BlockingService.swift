import Foundation

struct BlockSession: Codable, Identifiable {
    let id: UUID
    let domains: [String]
    let startedAt: Double
    let endsAt: Double
}

struct BlockReceipt: Codable {
    let id: UUID
    let domains: [String]
    let startedAt: Double
    let endedAt: Double
    let plannedEnd: Double
    let completed: Bool
}

struct BlockState: Codable {
    var active: BlockSession?
    var lastFinished: BlockReceipt?
}

enum BlockingError: LocalizedError {
    case helperMissing
    case authorizationCancelled
    case operationFailed(String)

    var errorDescription: String? {
        switch self {
        case .helperMissing:
            return "Der Sperrhelfer fehlt im App-Bundle. Bitte das Schema ForE in Xcode vollständig bauen."
        case .authorizationCancelled:
            return "Die Administratorfreigabe wurde abgebrochen. Der Sperrstatus wird erneut eingelesen."
        case .operationFailed(let detail):
            return "Die Systemsperre konnte nicht geändert werden. \(detail)"
        }
    }
}

/// No elevated process is launched until the user explicitly starts or stops a session.
enum BlockingService {
    static let stateURL = URL(fileURLWithPath: "/Library/Application Support/ForE/block-state.json")

    static func readState() throws -> BlockState {
        do {
            return try JSONDecoder().decode(BlockState.self, from: Data(contentsOf: stateURL))
        } catch let error as CocoaError where error.code == .fileReadNoSuchFile {
            return BlockState()
        }
    }

    static func start(domains: [String], minutes: Int) async throws {
        guard (1...240).contains(minutes) else {
            throw BlockingError.operationFailed("Bitte eine Dauer zwischen 1 und 240 Minuten wählen.")
        }
        struct Request: Encodable {
            let id: UUID
            let domains: [String]
            let durationSeconds: Double
        }
        let url = FileManager.default.temporaryDirectory.appendingPathComponent("fore-\(UUID().uuidString).json")
        defer { try? FileManager.default.removeItem(at: url) }
        let request = Request(id: UUID(), domains: domains, durationSeconds: Double(minutes * 60))
        try JSONEncoder().encode(request).write(to: url, options: .atomic)
        try FileManager.default.setAttributes([.posixPermissions: 0o600], ofItemAtPath: url.path)
        try await runAuthorized(arguments: ["start", url.path])
    }

    static func stop(id: UUID) async throws {
        // The installed, root-owned helper remains available if the app was moved.
        let installed = "/Library/PrivilegedHelperTools/de.fore.blocker"
        try await runAuthorized(arguments: ["stop", id.uuidString], installedPath: installed)
    }

    private static func runAuthorized(arguments: [String], installedPath: String? = nil) async throws {
        guard let executable = installedPath ?? Bundle.main.url(forResource: "ForEBlocker", withExtension: nil)?.path,
              FileManager.default.isExecutableFile(atPath: executable) else {
            throw BlockingError.helperMissing
        }
        let command = ([executable] + arguments).map(shellQuote).joined(separator: " ")
        let script = "do shell script \(appleScriptQuote(command)) with administrator privileges with prompt \(appleScriptQuote("ForE möchte deine ausgewählten Websites zeitlich begrenzt sperren oder wieder freigeben."))"

        try await withCheckedThrowingContinuation { (continuation: CheckedContinuation<Void, Error>) in
            DispatchQueue.global(qos: .userInitiated).async {
                let process = Process()
                process.executableURL = URL(fileURLWithPath: "/usr/bin/osascript")
                process.arguments = ["-e", script]
                let errorPipe = Pipe()
                process.standardError = errorPipe
                process.standardOutput = FileHandle.nullDevice
                do {
                    try process.run()
                    // Drain before waiting, so a full stderr pipe cannot deadlock.
                    let errorData = errorPipe.fileHandleForReading.readDataToEndOfFile()
                    process.waitUntilExit()
                    guard process.terminationStatus == 0 else {
                        let message = String(decoding: errorData, as: UTF8.self)
                            .trimmingCharacters(in: .whitespacesAndNewlines)
                        if message.contains("(-128)") {
                            throw BlockingError.authorizationCancelled
                        }
                        throw BlockingError.operationFailed(String(message.prefix(1600)))
                    }
                    continuation.resume()
                } catch {
                    continuation.resume(throwing: error)
                }
            }
        }
    }

    private static func shellQuote(_ value: String) -> String {
        "'" + value.replacingOccurrences(of: "'", with: "'\\''") + "'"
    }

    private static func appleScriptQuote(_ value: String) -> String {
        "\"" + value.replacingOccurrences(of: "\\", with: "\\\\")
            .replacingOccurrences(of: "\"", with: "\\\"") + "\""
    }
}
