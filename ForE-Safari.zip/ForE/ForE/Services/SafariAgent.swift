import Foundation
import SafariServices
import ForECore

/// A user LaunchAgent invokes the containing app with --safari-agent. No App,
/// NSApplication or SwiftUI scene is initialized in this mode. launchd restarts
/// the agent independently of the UI; its live process is never a snapshot asset.
enum SafariAgent {
    static func run() {
        do {
            let worker = try SafariAgentWorker()
            worker.start()
            withExtendedLifetime(worker) { RunLoop.main.run() }
        } catch {
            FileHandle.standardError.write(Data(("ForE Safari: \(error.localizedDescription)\n").utf8))
        }
    }
}

private final class SafariAgentWorker {
    private let container: URL
    private var timer: Timer?
    private var applied: SafariRuleSet?
    private var reloadInFlight = false
    private var reloadStartedUptime: TimeInterval = 0
    private var lastError: String?

    init() throws {
        container = try SafariSharedStorage.containerURL()
    }

    func start() {
        tick()
        let timer = Timer(timeInterval: 3, repeats: true) { [weak self] _ in self?.tick() }
        RunLoop.main.add(timer, forMode: .common)
        self.timer = timer
    }

    private func desiredRules(now: Date) -> (SafariRuleSet, String?) {
        do {
            let state = try BlockingService.readState()
            guard let active = state.active, active.endsAt > now.timeIntervalSince1970 else {
                return (SafariRuleSet(), nil)
            }
            guard active.startedAt.isFinite, active.endsAt.isFinite,
                  active.endsAt > active.startedAt,
                  !active.domains.isEmpty else {
                throw BlockingError.operationFailed("Der gespeicherte Sitzungsstatus ist ungültig.")
            }
            let rules = SafariRuleSet(domains: active.domains,
                                      activeUntil: Date(timeIntervalSince1970: active.endsAt),
                                      sessionID: active.id)
            // Validate before publishing. A malformed root status must fail open,
            // never replace the last good snapshot with unbuildable active rules.
            _ = try rules.jsonData(now: now)
            return (rules, nil)
        } catch {
            return (SafariRuleSet(), "Der Sitzungsstatus ist unlesbar; Safari-Regeln werden freigegeben. \(error.localizedDescription)")
        }
    }

    private func tick() {
        let now = Date()
        let (desired, sourceError) = desiredRules(now: now)
        if reloadInFlight {
            if ProcessInfo.processInfo.systemUptime - reloadStartedUptime > 30 {
                lastError = "Safari antwortet nicht auf die Regelaktualisierung. Der Hintergrunddienst wird neu gestartet."
                writeHeartbeat(now: now)
                // KeepAlive relaunches this agent. Without a callback, merely
                // keeping an in-flight flag forever would prevent expiry reloads.
                exit(EXIT_FAILURE)
            }
            if let sourceError { lastError = sourceError }
            writeHeartbeat(now: now)
            return
        }
        if applied == desired {
            lastError = sourceError
            writeHeartbeat(now: now)
            return
        }
        do {
            try SafariSharedStorage.write(desired, filename: SafariSharedStorage.rulesFilename, in: container)
            // Once compilation is requested the old acknowledgment cannot prove
            // Safari's current state. A successful no-op fallback with a missing
            // receipt must not let a later state change skip its own reload.
            applied = nil
            lastError = sourceError
            reloadInFlight = true
            reloadStartedUptime = ProcessInfo.processInfo.systemUptime
            let reloadStartedAt = Date()
            SFContentBlockerManager.reloadContentBlocker(withIdentifier: SafariSharedStorage.extensionIdentifier) { [weak self] error in
                DispatchQueue.main.async {
                    guard let self else { return }
                    self.reloadInFlight = false
                    if let error {
                        self.lastError = "Safari konnte die Regeln nicht übernehmen: \(error.localizedDescription)"
                    } else {
                        do {
                            let receiptURL = self.container.appendingPathComponent("safari-extension-receipt.json")
                            let receipt = try JSONDecoder().decode(SafariRuleReceipt.self, from: Data(contentsOf: receiptURL))
                            guard receipt.readError == nil, receipt.snapshot == desired,
                                  receipt.generatedAt >= reloadStartedAt.addingTimeInterval(-1) else {
                                throw SafariProtectionError.agentFailed("Die Safari-Erweiterung hat den gemeinsamen Regelsatz nicht bestätigt. Prüfe die App Group beider Targets.")
                            }
                            if let expiry = desired.activeUntil, expiry <= Date() {
                                // Compilation finished after the deadline. Never
                                // acknowledge that stale active session as ready.
                                self.lastError = "Die Fokuszeit ist abgelaufen; Safari wird freigegeben."
                                self.writeHeartbeat(now: Date())
                                self.tick()
                                return
                            }
                            // Both Safari and the extension must confirm the
                            // exact snapshot, not merely accept a no-op fallback.
                            self.applied = desired
                            self.lastError = sourceError
                        } catch {
                            self.lastError = "Die Safari-Regeln konnten nicht bestätigt werden: \(error.localizedDescription)"
                        }
                    }
                    self.writeHeartbeat(now: Date())
                }
            }
        } catch {
            lastError = "Der gemeinsame Safari-Container kann nicht geschrieben werden: \(error.localizedDescription)"
        }
        writeHeartbeat(now: now)
    }

    private func writeHeartbeat(now: Date) {
        // Before the initial reload succeeds there is deliberately no healthy
        // heartbeat, even though the process itself is alive.
        let error = lastError ?? (applied == nil ? SafariAgentStatus.initializingMessage : nil)
        let status = SafariAgentStatus(updatedAt: now, appliedSessionID: applied?.sessionID,
                                       appliedActive: applied?.sessionID != nil, lastError: error)
        do {
            try SafariSharedStorage.write(status, filename: SafariSharedStorage.statusFilename, in: container)
        } catch {
            FileHandle.standardError.write(Data(("ForE Safari-Status: \(error.localizedDescription)\n").utf8))
        }
    }
}
