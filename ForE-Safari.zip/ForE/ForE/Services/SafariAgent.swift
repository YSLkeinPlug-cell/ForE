import Foundation
import SafariServices
import ForECore
import os

/// A user LaunchAgent invokes the containing app with --safari-agent. No App,
/// NSApplication or SwiftUI scene is initialized in this mode. launchd restarts
/// the agent independently of the UI; its live process is never a snapshot asset.
enum SafariAgent {
    static func run() {
        let logger = Logger(subsystem: Bundle.main.bundleIdentifier ?? "de.fore.app", category: "SafariAgent")
        logger.notice("Safari-Hintergrundagent gestartet.")
        let worker = SafariAgentWorker()
        worker.start()
        withExtendedLifetime(worker) { dispatchMain() }
    }
}

private final class SafariAgentWorker {
    private var container: URL?
    private let scheduler = SafariAgentScheduler()
    private let logger = Logger(subsystem: Bundle.main.bundleIdentifier ?? "de.fore.app", category: "SafariAgent")
    private var reloadState = SafariReloadState()
    private var lastError: String?
    private var retryAfterUptime: TimeInterval = 0

    func start() {
        scheduler.start(interval: SafariReloadTiming.pollInterval, initialize: { [weak self] in
            guard let self else { return }
            do {
                self.container = try SafariSharedStorage.containerURL()
                // First light precedes all Safari framework calls. The timer
                // stays runnable even if Safari's synchronous entry blocks.
                self.writeHeartbeat(now: Date())
                self.logger.notice("Gemeinsamer Container erreichbar; Status-Timer wird gestartet.")
            } catch {
                self.logger.error("Safari-Agent konnte nicht initialisiert werden: \(error.localizedDescription, privacy: .public)")
                FileHandle.standardError.write(Data(("ForE Safari: \(error.localizedDescription)\n").utf8))
            }
        }, tick: { [weak self] in self?.tick() })
    }

    private func desiredRules(now: Date) -> (SafariRuleSet, String?) {
        do {
            let state = try BlockingService.readState()
            guard let active = state.active, active.endsAt > now.timeIntervalSince1970 else {
                return (SafariRuleSet(), nil)
            }
            guard active.startedAt.isFinite, active.endsAt.isFinite,
                  active.endsAt > active.startedAt,
                  !active.domains.isEmpty else {
                throw BlockingError.operationFailed("Der gespeicherte Sitzungsstatus ist ungültig.")
            }
            let rules = SafariRuleSet(domains: active.domains,
                                      activeUntil: Date(timeIntervalSince1970: active.endsAt),
                                      sessionID: active.id)
            // Validate before publishing. A malformed root status must fail open,
            // never replace the last good snapshot with unbuildable active rules.
            _ = try rules.jsonData(now: now)
            return (rules, nil)
        } catch {
            return (SafariRuleSet(), "Der Sitzungsstatus ist unlesbar; Safari-Regeln werden freigegeben. \(error.localizedDescription)")
        }
    }

    private func tick() {
        guard let container else { return }
        let now = Date()
        let (desired, sourceError) = desiredRules(now: now)
        if reloadState.expire(uptime: ProcessInfo.processInfo.systemUptime) {
            lastError = reloadTimeoutMessage()
            retryAfterUptime = ProcessInfo.processInfo.systemUptime + SafariReloadTiming.callbackTimeout
            writeHeartbeat(now: now)
            return
        }
        if reloadState.pending != nil {
            if let sourceError { lastError = sourceError }
            writeHeartbeat(now: now)
            return
        }
        if reloadState.applied == desired {
            lastError = sourceError
            writeHeartbeat(now: now)
            return
        }
        // Keep reporting the actual error instead of entering a restart loop.
        // Retry with backoff so a transient Safari failure cannot prevent the
        // eventual release of already compiled rules while the UI is closed.
        if reloadState.failed == desired, ProcessInfo.processInfo.systemUptime >= retryAfterUptime {
            reloadState.retryFailed()
        }
        guard reloadState.shouldReload(desired) else {
            writeHeartbeat(now: now)
            return
        }
        do {
            try SafariSharedStorage.write(desired, filename: SafariSharedStorage.rulesFilename, in: container)
            // Once compilation is requested the old acknowledgment cannot prove
            // Safari's current state. A successful no-op fallback with a missing
            // receipt must not let a later state change skip its own reload.
            lastError = sourceError
            guard let attempt = reloadState.begin(desired, now: Date(), uptime: ProcessInfo.processInfo.systemUptime) else { return }
            writeHeartbeat(now: Date())
            scheduler.performRequest { [weak self] in
                SFContentBlockerManager.reloadContentBlocker(withIdentifier: SafariSharedStorage.extensionIdentifier) { [weak self] error in
                    self?.scheduler.receiveResult { [weak self] in
                        guard let self else { return }
                        guard self.reloadState.pending?.id == attempt.id else {
                            // The API cannot cancel a timed-out reload. Its late
                            // completion may have changed Safari's compiled list;
                            // obtain a new confirmation of the current rules.
                            self.reloadState.invalidateApplied()
                            self.lastError = SafariAgentStatus.initializingMessage
                            self.writeHeartbeat(now: Date())
                            self.tick()
                            return
                        }
                        if self.reloadState.expire(uptime: ProcessInfo.processInfo.systemUptime) {
                            self.lastError = self.reloadTimeoutMessage()
                            self.retryAfterUptime = ProcessInfo.processInfo.systemUptime + SafariReloadTiming.callbackTimeout
                            self.writeHeartbeat(now: Date())
                            return
                        }
                        if let error {
                            self.reloadState.complete(id: attempt.id, succeeded: false)
                            self.retryAfterUptime = ProcessInfo.processInfo.systemUptime + SafariReloadTiming.callbackTimeout
                            self.lastError = "Safari konnte die Regeln nicht übernehmen: \(error.localizedDescription)"
                        } else {
                            do {
                                let receiptURL = container.appendingPathComponent("safari-extension-receipt.json")
                                let receipt = try JSONDecoder().decode(SafariRuleReceipt.self, from: Data(contentsOf: receiptURL))
                                guard receipt.confirms(attempt) else {
                                    throw SafariProtectionError.agentFailed("Die Safari-Erweiterung hat den gemeinsamen Regelsatz nicht bestätigt. Prüfe die App Group beider Targets.")
                                }
                                if let expiry = desired.activeUntil, expiry <= Date() {
                                    // Compilation finished after the deadline. Never
                                    // acknowledge that stale active session as ready.
                                    self.reloadState.complete(id: attempt.id, succeeded: false)
                                    self.lastError = "Die Fokuszeit ist abgelaufen; Safari wird freigegeben."
                                    self.writeHeartbeat(now: Date())
                                    self.tick()
                                    return
                                }
                                // Both Safari and the extension must confirm the
                                // exact snapshot, not merely accept a no-op fallback.
                                self.reloadState.complete(id: attempt.id, succeeded: true)
                                self.lastError = sourceError
                            } catch {
                                self.reloadState.complete(id: attempt.id, succeeded: false)
                                self.retryAfterUptime = ProcessInfo.processInfo.systemUptime + SafariReloadTiming.callbackTimeout
                                self.lastError = "Die Safari-Regeln konnten nicht bestätigt werden: \(error.localizedDescription)"
                            }
                        }
                        self.writeHeartbeat(now: Date())
                    }
                }
            }
        } catch {
            lastError = "Der gemeinsame Safari-Container kann nicht geschrieben werden: \(error.localizedDescription)"
        }
        writeHeartbeat(now: now)
    }

    private func reloadTimeoutMessage() -> String {
        "Safari hat die Regelaktualisierung innerhalb von 30 Sekunden nicht abgeschlossen. "
            + "Beende Safari vollständig und öffne es erneut. Prüfe ForE unter Safari → Einstellungen → Erweiterungen "
            + "und wähle anschließend in ForE „Hintergrundagent einrichten“, um den Dienst neu zu starten."
    }

    private func writeHeartbeat(now: Date) {
        guard let container else { return }
        // Before the initial reload succeeds there is deliberately no healthy
        // heartbeat, even though the process itself is alive.
        let error = lastError ?? (reloadState.applied == nil ? SafariAgentStatus.initializingMessage : nil)
        let status = SafariAgentStatus(updatedAt: now, appliedSessionID: reloadState.applied?.sessionID,
                                       appliedActive: reloadState.applied?.sessionID != nil, lastError: error)
        do {
            try SafariSharedStorage.write(status, filename: SafariSharedStorage.statusFilename, in: container)
        } catch {
            FileHandle.standardError.write(Data(("ForE Safari-Status: \(error.localizedDescription)\n").utf8))
        }
    }
}
