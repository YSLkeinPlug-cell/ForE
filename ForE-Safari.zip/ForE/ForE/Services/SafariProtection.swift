import Foundation
import Combine
import SafariServices
import ServiceManagement
import ForECore

struct SafariAgentStatus: Codable {
    static let initializingMessage = "Safari-Regeln werden noch initialisiert."
    let updatedAt: Date
    let appliedSessionID: UUID?
    let appliedActive: Bool
    let lastError: String?

    func isFresh(now: Date = Date()) -> Bool {
        let age = now.timeIntervalSince(updatedAt)
        return age >= -5 && age < 12
    }
}

enum SafariProtectionError: LocalizedError {
    case appGroupMissing
    case containerUnavailable
    case extensionDisabled
    case backgroundApprovalRequired
    case serviceNotFound
    case serviceBundleInvalid(String)
    case serviceRegistrationFailed(String)
    case extensionStatusTimedOut
    case agentUnavailable
    case agentStartupTimedOut
    case agentFailed(String)
    case timedOut

    var errorDescription: String? {
        switch self {
        case .appGroupMissing:
            return "Für Safari fehlt eine gültige macOS-App-Group. Wähle in Xcode dein Development Team und dieselbe App Group für ForE und die Safari-Erweiterung."
        case .containerUnavailable:
            return "Der gemeinsame Safari-Container ist nicht erreichbar. Prüfe die App-Group-Berechtigungen und die Signierung beider Targets in Xcode."
        case .extensionDisabled:
            return "Aktiviere ForE in Safari unter Einstellungen → Erweiterungen. Erlaube den Inhaltsblocker außerdem für die zu sperrenden Websites."
        case .backgroundApprovalRequired:
            return "Erlaube ForE unter Systemeinstellungen → Allgemein → Anmeldeobjekte im Hintergrund. Der Safari-Dienst muss auch bei geschlossener App Regeln wieder freigeben können."
        case .serviceNotFound:
            return "macOS findet den Safari-Hintergrunddienst nicht. Wähle „Hintergrundagent einrichten“, um ihn aus dieser App neu zu registrieren."
        case .serviceBundleInvalid(let detail):
            return "Der Safari-Hintergrunddienst fehlt im App-Paket oder ist beschädigt. Baue das Schema ForE vollständig neu und ersetze die installierte App. \(detail)"
        case .serviceRegistrationFailed(let detail):
            return "Der Safari-Hintergrunddienst konnte nicht registriert werden. \(detail)"
        case .extensionStatusTimedOut:
            return "Safari antwortet nicht auf die Statusabfrage. Öffne Safari, prüfe ForE unter Einstellungen → Erweiterungen und versuche es erneut."
        case .agentUnavailable:
            return "Der Safari-Hintergrunddienst ist noch nicht bereit. Richte die Safari-Sperre ein und prüfe die Hintergrundfreigabe."
        case .agentStartupTimedOut:
            return "macOS hat den Safari-Dienst registriert, aber er liefert keinen aktuellen Status. Beende Xcode und öffne die neu gebaute ForE.app aus Programme. Wähle dort „Hintergrundagent einrichten“. Bleibt der Fehler bestehen, prüfe in der macOS-App Konsole die Meldungen der Kategorie SafariAgent."
        case .agentFailed(let detail):
            return "Der Safari-Hintergrunddienst meldet: \(detail)"
        case .timedOut:
            return "Safari hat die neuen Sperrregeln nicht rechtzeitig bestätigt. Prüfe Erweiterung und Hintergrunddienst und versuche es erneut."
        }
    }
}

/// Both processes use the same signed App Group. The Safari extension remains
/// sandboxed; it never needs a broad filesystem exception for /Library.
enum SafariSharedStorage {
    static let rulesFilename = "safari-rules.json"
    static let statusFilename = "safari-agent-status.json"

    static var extensionIdentifier: String {
        Bundle.main.object(forInfoDictionaryKey: "ForESafariExtensionIdentifier") as? String
            ?? "de.fore.app.SafariBlocker"
    }

    static func containerURL() throws -> URL {
        let group = (Bundle.main.object(forInfoDictionaryKey: "ForEAppGroupIdentifier") as? String ?? "")
            .trimmingCharacters(in: .whitespacesAndNewlines)
        let prefix = group.split(separator: ".", omittingEmptySubsequences: false).first.map(String.init) ?? ""
        // A macOS 13 group identifier starts with the actual developer Team ID.
        // Reject unresolved build settings and the empty-team '.de.fore...' case.
        guard !group.isEmpty, !group.contains("$("), !group.hasPrefix("."),
              prefix.utf8.count == 10,
              prefix.utf8.allSatisfy({ (65...90).contains($0) || (48...57).contains($0) }) else {
            throw SafariProtectionError.appGroupMissing
        }
        guard let url = FileManager.default.containerURL(forSecurityApplicationGroupIdentifier: group) else {
            throw SafariProtectionError.containerUnavailable
        }
        return url
    }

    static func readStatus(in container: URL) throws -> SafariAgentStatus? {
        let url = container.appendingPathComponent(statusFilename)
        do {
            return try JSONDecoder().decode(SafariAgentStatus.self, from: Data(contentsOf: url))
        } catch let error as CocoaError where error.code == .fileReadNoSuchFile {
            return nil
        }
    }

    static func resolveContainer() async throws -> URL {
        try await Task.detached(priority: .utility) { try containerURL() }.value
    }

    static func readStatusAsync(in container: URL) async throws -> SafariAgentStatus? {
        try await Task.detached(priority: .utility) { try readStatus(in: container) }.value
    }

    static func write<T: Encodable>(_ value: T, filename: String, in container: URL) throws {
        let data = try JSONEncoder().encode(value)
        try data.write(to: container.appendingPathComponent(filename), options: .atomic)
    }
}

/// The Safari callback cannot be cancelled. Both its completion and the timeout
/// may arrive on arbitrary queues; exactly one is allowed to resume the caller.
private final class SafariStateCompletion: @unchecked Sendable {
    private let lock = NSLock()
    private var continuation: CheckedContinuation<Bool, Error>?

    init(_ continuation: CheckedContinuation<Bool, Error>) {
        self.continuation = continuation
    }

    func finish(_ result: Result<Bool, Error>) {
        lock.lock()
        let pending = continuation
        continuation = nil
        lock.unlock()
        pending?.resume(with: result)
    }
}

@MainActor
final class SafariProtection: ObservableObject {
    @Published private(set) var enabledInSafari = false
    @Published private(set) var agentReady = false
    @Published private(set) var setupMessage: String?
    @Published private(set) var isBusy = false
    @Published private(set) var agentStatus: SafariAgentStatus?
    @Published private(set) var registrationStatus: SMAppService.Status = .notRegistered
    private var refreshTask: Task<Void, Never>?
    private let serviceController = SafariServiceController()
    var isReady: Bool { enabledInSafari && agentReady && registrationStatus == .enabled }

    func refresh() async {
        if let refreshTask {
            await refreshTask.value
            return
        }
        let task = Task { await performRefresh() }
        refreshTask = task
        await task.value
        refreshTask = nil
    }

    private func performRefresh() async {
        do {
            let container = try await SafariSharedStorage.resolveContainer()
            registrationStatus = await serviceController.status()
            enabledInSafari = try await extensionIsEnabled()
            agentStatus = try await SafariSharedStorage.readStatusAsync(in: container)
            agentReady = registrationStatus == .enabled
                && agentStatus?.isFresh() == true && agentStatus?.lastError == nil
            if !enabledInSafari {
                setupMessage = SafariProtectionError.extensionDisabled.localizedDescription
            } else if registrationStatus == .requiresApproval {
                setupMessage = SafariProtectionError.backgroundApprovalRequired.localizedDescription
            } else if registrationStatus == .notFound {
                setupMessage = SafariProtectionError.serviceNotFound.localizedDescription
            } else if let error = agentStatus?.lastError {
                setupMessage = SafariProtectionError.agentFailed(error).localizedDescription
            } else if !agentReady {
                setupMessage = SafariProtectionError.agentUnavailable.localizedDescription
            } else {
                setupMessage = nil
            }
        } catch {
            agentReady = false
            setupMessage = error.localizedDescription
        }
    }

    /// Explicit one-time setup action. Registration never happens merely because
    /// the app opens or the user starts an unrelated hosts-only session.
    func prepare() async throws {
        guard !isBusy else { throw SafariProtectionError.agentUnavailable }
        isBusy = true
        defer { isBusy = false }
        do {
            let container = try await SafariSharedStorage.resolveContainer()
            // Check Safari before restarting the service. Setup is an explicit
            // retry, including when an older instance is still registered.
            enabledInSafari = try await extensionIsEnabled()
            guard enabledInSafari else { throw SafariProtectionError.extensionDisabled }
            agentReady = false
            agentStatus = nil
            try await serviceController.prepare(in: container)
            registrationStatus = await serviceController.status()
            guard registrationStatus == .enabled else {
                if registrationStatus == .requiresApproval {
                    throw SafariProtectionError.backgroundApprovalRequired
                }
                if registrationStatus == .notFound { throw SafariProtectionError.serviceNotFound }
                throw SafariProtectionError.agentUnavailable
            }
            let active = try await Task.detached(priority: .utility) { try BlockingService.readState().active }.value
            let expectedID = active.flatMap { $0.endsAt > Date().timeIntervalSince1970 ? $0.id : nil }
            try await waitUntilApplied(sessionID: expectedID)
            await refresh()
        } catch {
            setupMessage = error.localizedDescription
            throw error
        }
    }

    /// Session preflight is read-only; background registration is the user's
    /// separate setup action. Require both Safari enablement and a live agent.
    func prepareForSession() async throws {
        await refresh()
        guard enabledInSafari else { throw SafariProtectionError.extensionDisabled }
        guard registrationStatus == .enabled else {
            if registrationStatus == .requiresApproval {
                throw SafariProtectionError.backgroundApprovalRequired
            }
            if registrationStatus == .notFound { throw SafariProtectionError.serviceNotFound }
            throw SafariProtectionError.agentUnavailable
        }
        guard agentReady else {
            if let detail = agentStatus?.lastError { throw SafariProtectionError.agentFailed(detail) }
            throw SafariProtectionError.agentUnavailable
        }
    }

    /// Wait for a fresh acknowledgment of the intended state. A heartbeat alone
    /// is insufficient: Safari must have accepted this session's compiled rules.
    func waitUntilApplied(sessionID: UUID?, timeout: TimeInterval = SafariReloadTiming.setupTimeout) async throws {
        let container = try await SafariSharedStorage.resolveContainer()
        let deadline = ProcessInfo.processInfo.systemUptime + max(timeout, 0)
        var nextRegistrationCheck: TimeInterval = 0
        repeat {
            try Task.checkCancellation()
            if ProcessInfo.processInfo.systemUptime >= nextRegistrationCheck {
                registrationStatus = await serviceController.status()
                nextRegistrationCheck = ProcessInfo.processInfo.systemUptime + SafariReloadTiming.pollInterval
            }
            guard registrationStatus == .enabled else {
                agentReady = false
                if registrationStatus == .notFound { throw SafariProtectionError.serviceNotFound }
                throw SafariProtectionError.agentUnavailable
            }
            let status = try await SafariSharedStorage.readStatusAsync(in: container)
            agentStatus = status
            if let status, status.isFresh() {
                if let detail = status.lastError, detail != SafariAgentStatus.initializingMessage {
                    agentReady = false
                    throw SafariProtectionError.agentFailed(detail)
                }
                if status.lastError == nil, status.appliedSessionID == sessionID,
                   status.appliedActive == (sessionID != nil) {
                    agentReady = registrationStatus == .enabled
                    return
                }
            }
            try await Task.sleep(nanoseconds: 250_000_000)
        } while ProcessInfo.processInfo.systemUptime < deadline
        agentReady = false
        if agentStatus?.isFresh() != true { throw SafariProtectionError.agentStartupTimedOut }
        throw SafariProtectionError.timedOut
    }

    func openBackgroundSettings() {
        SMAppService.openSystemSettingsLoginItems()
    }

    private func extensionIsEnabled() async throws -> Bool {
        try await withCheckedThrowingContinuation { (continuation: CheckedContinuation<Bool, Error>) in
            let completion = SafariStateCompletion(continuation)
            DispatchQueue.global(qos: .utility).asyncAfter(deadline: .now() + 8) {
                completion.finish(.failure(SafariProtectionError.extensionStatusTimedOut))
            }
            DispatchQueue.global(qos: .utility).async {
                SFContentBlockerManager.getStateOfContentBlocker(withIdentifier: SafariSharedStorage.extensionIdentifier) { state, error in
                    if let error { completion.finish(.failure(error)) }
                    else { completion.finish(.success(state?.isEnabled == true)) }
                }
            }
        }
    }
}

/// Service Management can perform synchronous bundle and launchd lookups.
/// Keep those operations on this actor's executor, away from the UI actor.
/// Merely reading status never registers, restarts, or approves a service.
private actor SafariServiceController {
    private static let agentPlistName = "de.fore.safari-agent.plist"
    private var isPreparing = false

    private var service: SMAppService {
        SMAppService.agent(plistName: Self.agentPlistName)
    }

    func status() -> SMAppService.Status {
        service.status
    }

    /// Only the user's explicit setup action calls this method. After a restart,
    /// the old status is removed only once Service Management has completed the
    /// old process's unregistration, before the replacement can publish status.
    func prepare(in container: URL) async throws {
        guard !isPreparing else { throw SafariProtectionError.agentUnavailable }
        isPreparing = true
        defer { isPreparing = false }

        try validateAgentBundle()
        let agent = service
        let initialStatus = agent.status
        if initialStatus == .requiresApproval {
            throw SafariProtectionError.backgroundApprovalRequired
        }

        let restarting = initialStatus == .enabled
        if restarting {
            do { try await unregisterService(agent) }
            catch { throw registrationFailure(error, operation: "Hintergrundagent neu starten") }
        }

        // A stopped or never-registered instance can leave a final error file.
        // Do not carry that error into the new process's readiness handshake.
        if restarting || initialStatus == .notRegistered || initialStatus == .notFound {
            do {
                try FileManager.default.removeItem(
                    at: container.appendingPathComponent(SafariSharedStorage.statusFilename))
            } catch let error as CocoaError where error.code == .fileNoSuchFile || error.code == .fileReadNoSuchFile {
                // No status is expected on a first installation.
            }
        }

        try Task.checkCancellation()
        try await registerServiceIfNeeded(agent, force: restarting)
        try await waitUntilRegistered(agent)
    }

    /// .notFound describes Service Management's lookup, not whether ForE.app
    /// exists. A first installation may need register() from this state.
    private func registerServiceIfNeeded(_ agent: SMAppService, force: Bool) async throws {
        let initialStatus = agent.status
        guard force || initialStatus == .notRegistered || initialStatus == .notFound else { return }

        do {
            try agent.register()
        } catch {
            if requiresApproval(error, service: agent) {
                throw SafariProtectionError.backgroundApprovalRequired
            }
            if agent.status == .enabled { return }
            guard initialStatus == .notFound else {
                throw registrationFailure(error, operation: "Registrierung")
            }

            // Try registration before removing a stale record: unregistering a
            // never-registered service can itself fail. Only one retry is made.
            let firstError = error
            do {
                try await unregisterService(agent)
            } catch {
                let failure = error as NSError
                guard failure.domain == "SMAppServiceErrorDomain",
                      failure.code == kSMErrorJobNotFound else {
                    throw registrationFailure(error, operation: "Alte Registrierung entfernen; erster Versuch: \(describe(firstError))")
                }
            }
            try Task.checkCancellation()
            do {
                try agent.register()
            } catch {
                if requiresApproval(error, service: agent) {
                    throw SafariProtectionError.backgroundApprovalRequired
                }
                if agent.status == .enabled { return }
                throw registrationFailure(error, operation: "Erneute Registrierung")
            }
        }
    }

    /// register() may succeed before the public status reflects the change.
    /// Allow a short bounded transition without ever bypassing user approval.
    private func waitUntilRegistered(_ agent: SMAppService) async throws {
        let deadline = ProcessInfo.processInfo.systemUptime + 5
        repeat {
            try Task.checkCancellation()
            let current = agent.status
            if current == .enabled { return }
            if current == .requiresApproval {
                throw SafariProtectionError.backgroundApprovalRequired
            }
            if current != .notRegistered && current != .notFound {
                throw SafariProtectionError.agentUnavailable
            }
            try await Task.sleep(nanoseconds: 100_000_000)
        } while ProcessInfo.processInfo.systemUptime < deadline

        let current = agent.status
        if current == .enabled { return }
        if current == .requiresApproval { throw SafariProtectionError.backgroundApprovalRequired }
        if current == .notFound { throw SafariProtectionError.serviceNotFound }
        throw SafariProtectionError.agentUnavailable
    }

    private func unregisterService(_ agent: SMAppService) async throws {
        try await withCheckedThrowingContinuation { (continuation: CheckedContinuation<Void, Error>) in
            agent.unregister { error in
                if let error { continuation.resume(throwing: error) }
                else { continuation.resume() }
            }
        }
    }

    private func requiresApproval(_ error: Error, service: SMAppService) -> Bool {
        let failure = error as NSError
        return service.status == .requiresApproval
            || (failure.domain == "SMAppServiceErrorDomain" && failure.code == kSMErrorLaunchDeniedByUser)
    }

    private func validateAgentBundle() throws {
        let bundle = Bundle.main.bundleURL
        let plistURL = bundle.appendingPathComponent("Contents/Library/LaunchAgents/\(Self.agentPlistName)")
        guard let data = try? Data(contentsOf: plistURL),
              let plist = (try? PropertyListSerialization.propertyList(from: data, format: nil)) as? [String: Any],
              plist["Label"] as? String == "de.fore.safari-agent",
              plist["BundleProgram"] as? String == "Contents/MacOS/ForE",
              let arguments = plist["ProgramArguments"] as? [String],
              Array(arguments.dropFirst()) == ["--safari-agent"] else {
            throw SafariProtectionError.serviceBundleInvalid("Dienstdatei: \(plistURL.path)")
        }
        let executable = bundle.appendingPathComponent("Contents/MacOS/ForE")
        guard FileManager.default.isExecutableFile(atPath: executable.path) else {
            throw SafariProtectionError.serviceBundleInvalid("Programmdatei: \(executable.path)")
        }
    }

    private func describe(_ error: Error) -> String {
        let failure = error as NSError
        return "\(failure.domain) (\(failure.code)): \(failure.localizedDescription)"
    }

    private func registrationFailure(_ error: Error, operation: String) -> SafariProtectionError {
        .serviceRegistrationFailed("\(operation): \(describe(error)) App: \(Bundle.main.bundleURL.path)")
    }
}
