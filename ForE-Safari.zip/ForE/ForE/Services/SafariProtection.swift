import Foundation
import Combine
import SafariServices
import ServiceManagement
import ForECore

struct SafariAgentStatus: Codable {
    static let initializingMessage = "Safari-Regeln werden noch initialisiert."
    let updatedAt: Date
    let appliedSessionID: UUID?
    let appliedActive: Bool
    let lastError: String?

    func isFresh(now: Date = Date()) -> Bool {
        let age = now.timeIntervalSince(updatedAt)
        return age >= -5 && age < 12
    }
}

enum SafariProtectionError: LocalizedError {
    case appGroupMissing
    case containerUnavailable
    case extensionDisabled
    case backgroundApprovalRequired
    case serviceNotFound
    case serviceBundleInvalid(String)
    case serviceRegistrationFailed(String)
    case extensionStatusTimedOut
    case agentUnavailable
    case agentFailed(String)
    case timedOut

    var errorDescription: String? {
        switch self {
        case .appGroupMissing:
            return "Für Safari fehlt eine gültige macOS-App-Group. Wähle in Xcode dein Development Team und dieselbe App Group für ForE und die Safari-Erweiterung."
        case .containerUnavailable:
            return "Der gemeinsame Safari-Container ist nicht erreichbar. Prüfe die App-Group-Berechtigungen und die Signierung beider Targets in Xcode."
        case .extensionDisabled:
            return "Aktiviere ForE in Safari unter Einstellungen → Erweiterungen. Erlaube den Inhaltsblocker außerdem für die zu sperrenden Websites."
        case .backgroundApprovalRequired:
            return "Erlaube ForE unter Systemeinstellungen → Allgemein → Anmeldeobjekte im Hintergrund. Der Safari-Dienst muss auch bei geschlossener App Regeln wieder freigeben können."
        case .serviceNotFound:
            return "macOS findet den Safari-Hintergrunddienst nicht. Wähle „Hintergrundagent einrichten“, um ihn aus dieser App neu zu registrieren."
        case .serviceBundleInvalid(let detail):
            return "Der Safari-Hintergrunddienst fehlt im App-Paket oder ist beschädigt. Baue das Schema ForE vollständig neu und ersetze die installierte App. \(detail)"
        case .serviceRegistrationFailed(let detail):
            return "Der Safari-Hintergrunddienst konnte nicht registriert werden. \(detail)"
        case .extensionStatusTimedOut:
            return "Safari antwortet nicht auf die Statusabfrage. Öffne Safari, prüfe ForE unter Einstellungen → Erweiterungen und versuche es erneut."
        case .agentUnavailable:
            return "Der Safari-Hintergrunddienst ist noch nicht bereit. Richte die Safari-Sperre ein und prüfe die Hintergrundfreigabe."
        case .agentFailed(let detail):
            return "Der Safari-Hintergrunddienst meldet: \(detail)"
        case .timedOut:
            return "Safari hat die neuen Sperrregeln nicht rechtzeitig bestätigt. Prüfe Erweiterung und Hintergrunddienst und versuche es erneut."
        }
    }
}

/// Both processes use the same signed App Group. The Safari extension remains
/// sandboxed; it never needs a broad filesystem exception for /Library.
enum SafariSharedStorage {
    static let rulesFilename = "safari-rules.json"
    static let statusFilename = "safari-agent-status.json"

    static var extensionIdentifier: String {
        Bundle.main.object(forInfoDictionaryKey: "ForESafariExtensionIdentifier") as? String
            ?? "de.fore.app.SafariBlocker"
    }

    static func containerURL() throws -> URL {
        let group = (Bundle.main.object(forInfoDictionaryKey: "ForEAppGroupIdentifier") as? String ?? "")
            .trimmingCharacters(in: .whitespacesAndNewlines)
        let prefix = group.split(separator: ".", omittingEmptySubsequences: false).first.map(String.init) ?? ""
        // A macOS 13 group identifier starts with the actual developer Team ID.
        // Reject unresolved build settings and the empty-team '.de.fore...' case.
        guard !group.isEmpty, !group.contains("$("), !group.hasPrefix("."),
              prefix.utf8.count == 10,
              prefix.utf8.allSatisfy({ (65...90).contains($0) || (48...57).contains($0) }) else {
            throw SafariProtectionError.appGroupMissing
        }
        guard let url = FileManager.default.containerURL(forSecurityApplicationGroupIdentifier: group) else {
            throw SafariProtectionError.containerUnavailable
        }
        return url
    }

    static func readStatus(in container: URL) throws -> SafariAgentStatus? {
        let url = container.appendingPathComponent(statusFilename)
        do {
            return try JSONDecoder().decode(SafariAgentStatus.self, from: Data(contentsOf: url))
        } catch let error as CocoaError where error.code == .fileReadNoSuchFile {
            return nil
        }
    }

    static func write<T: Encodable>(_ value: T, filename: String, in container: URL) throws {
        let data = try JSONEncoder().encode(value)
        try data.write(to: container.appendingPathComponent(filename), options: .atomic)
    }
}

/// The Safari callback cannot be cancelled. Both its completion and the timeout
/// may arrive on arbitrary queues; exactly one is allowed to resume the caller.
private final class SafariStateCompletion: @unchecked Sendable {
    private let lock = NSLock()
    private var continuation: CheckedContinuation<Bool, Error>?

    init(_ continuation: CheckedContinuation<Bool, Error>) {
        self.continuation = continuation
    }

    func finish(_ result: Result<Bool, Error>) {
        lock.lock()
        let pending = continuation
        continuation = nil
        lock.unlock()
        pending?.resume(with: result)
    }
}

@MainActor
final class SafariProtection: ObservableObject {
    private static let agentPlistName = "de.fore.safari-agent.plist"
    @Published private(set) var enabledInSafari = false
    @Published private(set) var agentReady = false
    @Published private(set) var setupMessage: String?
    @Published private(set) var isBusy = false
    @Published private(set) var agentStatus: SafariAgentStatus?
    private var refreshTask: Task<Void, Never>?

    private var service: SMAppService {
        SMAppService.agent(plistName: Self.agentPlistName)
    }

    var registrationStatus: SMAppService.Status { service.status }
    var isReady: Bool { enabledInSafari && agentReady && registrationStatus == .enabled }

    func refresh() async {
        if let refreshTask {
            await refreshTask.value
            return
        }
        let task = Task { await performRefresh() }
        refreshTask = task
        await task.value
        refreshTask = nil
    }

    private func performRefresh() async {
        do {
            let container = try SafariSharedStorage.containerURL()
            enabledInSafari = try await extensionIsEnabled()
            agentStatus = try SafariSharedStorage.readStatus(in: container)
            agentReady = registrationStatus == .enabled
                && agentStatus?.isFresh() == true && agentStatus?.lastError == nil
            if !enabledInSafari {
                setupMessage = SafariProtectionError.extensionDisabled.localizedDescription
            } else if registrationStatus == .requiresApproval {
                setupMessage = SafariProtectionError.backgroundApprovalRequired.localizedDescription
            } else if registrationStatus == .notFound {
                setupMessage = SafariProtectionError.serviceNotFound.localizedDescription
            } else if let error = agentStatus?.lastError {
                setupMessage = SafariProtectionError.agentFailed(error).localizedDescription
            } else if !agentReady {
                setupMessage = SafariProtectionError.agentUnavailable.localizedDescription
            } else {
                setupMessage = nil
            }
        } catch {
            agentReady = false
            setupMessage = error.localizedDescription
        }
    }

    /// Explicit one-time setup action. Registration never happens merely because
    /// the app opens or the user starts an unrelated hosts-only session.
    func prepare() async throws {
        guard !isBusy else { throw SafariProtectionError.agentUnavailable }
        isBusy = true
        defer { isBusy = false }
        do {
            _ = try SafariSharedStorage.containerURL()
            try await registerServiceIfNeeded()
            guard registrationStatus == .enabled else {
                if registrationStatus == .requiresApproval {
                    throw SafariProtectionError.backgroundApprovalRequired
                }
                if registrationStatus == .notFound { throw SafariProtectionError.serviceNotFound }
                throw SafariProtectionError.agentUnavailable
            }
            await refresh()
            guard enabledInSafari else { throw SafariProtectionError.extensionDisabled }
            let active = try BlockingService.readState().active
            let expectedID = active.flatMap { $0.endsAt > Date().timeIntervalSince1970 ? $0.id : nil }
            try await waitUntilApplied(sessionID: expectedID)
            await refresh()
        } catch {
            setupMessage = error.localizedDescription
            throw error
        }
    }

    /// A .notFound status describes Service Management's lookup, not whether
    /// ForE.app exists. A first installation may need register() from this state.
    /// Only the explicit setup action may repair a stale registration.
    private func registerServiceIfNeeded() async throws {
        try validateAgentBundle()
        let agent = service
        let initialStatus = agent.status
        guard initialStatus == .notRegistered || initialStatus == .notFound else { return }

        do {
            try agent.register()
        } catch {
            if requiresApproval(error, service: agent) {
                throw SafariProtectionError.backgroundApprovalRequired
            }
            if agent.status == .enabled { return }
            guard initialStatus == .notFound else {
                throw registrationFailure(error, operation: "Registrierung")
            }

            // Try normal registration first: unregistering a never-registered
            // service can itself fail. If registration failed from .notFound,
            // remove this service's stale record before one bounded retry.
            let firstError = error
            do {
                try await withCheckedThrowingContinuation { (continuation: CheckedContinuation<Void, Error>) in
                    agent.unregister { error in
                        if let error { continuation.resume(throwing: error) }
                        else { continuation.resume() }
                    }
                }
            } catch {
                let failure = error as NSError
                // Older SDKs do not expose the named error-domain constant.
                // Compare NSError's domain string without linking that symbol.
                guard failure.domain == "SMAppServiceErrorDomain",
                      failure.code == kSMErrorJobNotFound else {
                    throw registrationFailure(error, operation: "Alte Registrierung entfernen; erster Versuch: \(describe(firstError))")
                }
            }
            try Task.checkCancellation()
            do {
                try agent.register()
            } catch {
                if requiresApproval(error, service: agent) {
                    throw SafariProtectionError.backgroundApprovalRequired
                }
                if agent.status == .enabled { return }
                throw registrationFailure(error, operation: "Erneute Registrierung")
            }
        }
    }

    private func requiresApproval(_ error: Error, service: SMAppService) -> Bool {
        let failure = error as NSError
        return service.status == .requiresApproval
            || (failure.domain == "SMAppServiceErrorDomain" && failure.code == kSMErrorLaunchDeniedByUser)
    }

    private func validateAgentBundle() throws {
        let bundle = Bundle.main.bundleURL
        let plistURL = bundle.appendingPathComponent("Contents/Library/LaunchAgents/\(Self.agentPlistName)")
        guard let data = try? Data(contentsOf: plistURL),
              let plist = (try? PropertyListSerialization.propertyList(from: data, format: nil)) as? [String: Any],
              plist["Label"] as? String == "de.fore.safari-agent",
              plist["BundleProgram"] as? String == "Contents/MacOS/ForE",
              let arguments = plist["ProgramArguments"] as? [String],
              Array(arguments.dropFirst()) == ["--safari-agent"] else {
            throw SafariProtectionError.serviceBundleInvalid("Dienstdatei: \(plistURL.path)")
        }
        let executable = bundle.appendingPathComponent("Contents/MacOS/ForE")
        guard FileManager.default.isExecutableFile(atPath: executable.path) else {
            throw SafariProtectionError.serviceBundleInvalid("Programmdatei: \(executable.path)")
        }
    }

    private func describe(_ error: Error) -> String {
        let failure = error as NSError
        return "\(failure.domain) (\(failure.code)): \(failure.localizedDescription)"
    }

    private func registrationFailure(_ error: Error, operation: String) -> SafariProtectionError {
        .serviceRegistrationFailed("\(operation): \(describe(error)) App: \(Bundle.main.bundleURL.path)")
    }

    /// Session preflight is read-only; background registration is the user's
    /// separate setup action. Require both Safari enablement and a live agent.
    func prepareForSession() async throws {
        await refresh()
        guard enabledInSafari else { throw SafariProtectionError.extensionDisabled }
        guard registrationStatus == .enabled else {
            if registrationStatus == .requiresApproval {
                throw SafariProtectionError.backgroundApprovalRequired
            }
            if registrationStatus == .notFound { throw SafariProtectionError.serviceNotFound }
            throw SafariProtectionError.agentUnavailable
        }
        guard agentReady else {
            if let detail = agentStatus?.lastError { throw SafariProtectionError.agentFailed(detail) }
            throw SafariProtectionError.agentUnavailable
        }
    }

    /// Wait for a fresh acknowledgment of the intended state. A heartbeat alone
    /// is insufficient: Safari must have accepted this session's compiled rules.
    func waitUntilApplied(sessionID: UUID?, timeout: TimeInterval = 15) async throws {
        let container = try SafariSharedStorage.containerURL()
        let deadline = ProcessInfo.processInfo.systemUptime + max(timeout, 0)
        repeat {
            try Task.checkCancellation()
            guard registrationStatus == .enabled else {
                agentReady = false
                if registrationStatus == .notFound { throw SafariProtectionError.serviceNotFound }
                throw SafariProtectionError.agentUnavailable
            }
            let status = try SafariSharedStorage.readStatus(in: container)
            agentStatus = status
            if let status, status.isFresh() {
                if let detail = status.lastError, detail != SafariAgentStatus.initializingMessage {
                    agentReady = false
                    throw SafariProtectionError.agentFailed(detail)
                }
                if status.lastError == nil, status.appliedSessionID == sessionID,
                   status.appliedActive == (sessionID != nil) {
                    agentReady = registrationStatus == .enabled
                    return
                }
            }
            try await Task.sleep(nanoseconds: 250_000_000)
        } while ProcessInfo.processInfo.systemUptime < deadline
        agentReady = false
        throw SafariProtectionError.timedOut
    }

    func openBackgroundSettings() {
        SMAppService.openSystemSettingsLoginItems()
    }

    private func extensionIsEnabled() async throws -> Bool {
        try await withCheckedThrowingContinuation { (continuation: CheckedContinuation<Bool, Error>) in
            let completion = SafariStateCompletion(continuation)
            DispatchQueue.global(qos: .utility).asyncAfter(deadline: .now() + 8) {
                completion.finish(.failure(SafariProtectionError.extensionStatusTimedOut))
            }
            SFContentBlockerManager.getStateOfContentBlocker(withIdentifier: SafariSharedStorage.extensionIdentifier) { state, error in
                if let error { completion.finish(.failure(error)) }
                else { completion.finish(.success(state?.isEnabled == true)) }
            }
        }
    }
}
