# Safari-Schutz für iCloud Privat-Relay

Die neue Erweiterung filtert HTTP-/HTTPS-URLs direkt in Safari. Dadurch bleibt die Sperre der ausgewählten Domains unabhängig von der Namensauflösung und adressiert den Privat-Relay-Fall der Hosts-Sperre. Haupt-App, Erweiterung und Benutzer-Hintergrundagent unterstützen macOS 13.0 und neuer.

## Voraussetzungen in Xcode

1. `ForE.xcodeproj` in Xcode 15+ öffnen. Es gibt jetzt zusätzlich das Target **ForESafariBlocker**. Das Schema **ForE** baut und bettet die Erweiterung automatisch in `ForE.app/Contents/PlugIns` ein.
2. Für **ForE** und **ForESafariBlocker** dasselbe echte Apple **Development Team** und passende Signierung wählen. Die Ausgangseinstellung `CODE_SIGN_IDENTITY = -` ist lokale Ad-hoc-Signierung. Für die Safari-Installation diese unter *Signing & Capabilities* bzw. *Build Settings → Code Signing Identity* durch **Apple Development** mit deinem Team ersetzen. Für Distribution ein passendes Distributionsprofil verwenden. Der Hosts-Helper hat keine App Group.
3. Für beide Targets unter *Signing & Capabilities* **App Groups** konfigurieren. Auf macOS 13 einen für dein Team zulässigen, identischen Gruppenbezeichner verwenden, beispielsweise `ABCDE12345.de.fore.shared`. Die Capability muss durch deine Apple-Mitgliedschaft bzw. Signierungsprofile unterstützt und freigegeben sein. Ein beliebiger erfundener Teambezeichner oder nur eine Ad-hoc-Signatur genügt nicht.
4. In den **Projekt-Build-Settings** `DEVELOPMENT_TEAM` auf dein echtes Team setzen, damit beide Targets es erben. `FORE_APP_GROUP_IDENTIFIER` ist standardmäßig `$(DEVELOPMENT_TEAM).de.fore.shared`. Wenn deine tatsächlich registrierte macOS-Gruppe anders heißt, dort den passenden Bezeichner eintragen. Beide Info.plists und beide Entitlements beziehen denselben Build-Setting-Wert. Der Laufzeitcheck erwartet einen macOS-Teampräfix aus zehn Großbuchstaben/Ziffern; keine iOS-Gruppe ohne passenden macOS-Teampräfix eintragen.
5. App und Erweiterung vollständig neu bauen. Unter den signierten Entitlements muss `com.apple.security.application-groups` in beiden Binärdateien exakt denselben gültigen Gruppenbezeichner enthalten. Keine Sandbox-Ausnahmen oder selbstgebauten `/Library`-Zugriffsfreigaben in die Erweiterung aufnehmen.

Falls Apple den Standard-Bundle-Bezeichner `de.fore.app` deinem Team nicht zuordnen kann, in den Projekt-Build-Settings **`FORE_BUNDLE_IDENTIFIER`** auf einen eigenen eindeutigen Bezeichner setzen. App-ID, Erweiterungs-ID und die SafariServices-Abfrage werden daraus gemeinsam abgeleitet; `PRODUCT_BUNDLE_IDENTIFIER` nicht nur in einem Target unabhängig ändern. Der technische LaunchAgent-Label `de.fore.safari-agent` bleibt unverändert.

Falls dein Team die App Group nicht bereitstellen kann, ist dieser Einrichtungsschritt ein echter Blocker für den Safari-Schutz. Die UI zeigt das an; es wird nicht stillschweigend eine funktionierende Safari-Sperre behauptet. Safari kann außerdem nicht passend signierte lokale Erweiterungen ablehnen. Safaris Entwickleroption zum Erlauben unsignierter Erweiterungen ersetzt keine fehlende App-Group-Berechtigung.

## Einmalige Aktivierung auf deinem Mac

1. Die gebaute `ForE.app` möglichst nach **Programme** kopieren und von dort starten. Den registrierten App-Pfad danach nicht löschen oder verschieben. Ein Agent, der auf eine gelöschte DerivedData-App verweist, kann keine Regeln freigeben.
2. Safari öffnen. Unter **Safari → Einstellungen → Erweiterungen** **ForE Safari-Schutz** aktivieren. Für die gewünschten Websites müssen Safari-Inhaltsblocker ebenfalls eingeschaltet sein. Safari kann für einzelne Websites oder private Fenster abweichende Einstellungen verwenden; diese getrennt prüfen.
3. In ForE unter **Einstellungen → Safari-Schutz mit Privat-Relay** **Hintergrundagent einrichten** wählen. Dies registriert den mitgelieferten Benutzer-LaunchAgent über `SMAppService.agent`.
4. Falls macOS eine Freigabe verlangt: Unter **Systemeinstellungen → Allgemein → Anmeldeobjekte** ForE im Hintergrund erlauben. Zurück in ForE **Status prüfen** bzw. **Hintergrundagent einrichten** wählen.
5. Erst wenn **Erweiterung aktiviert** und **Hintergrundagent bereit** angezeigt werden, eine Sitzung starten. „Bestätigten Safari-Schutz … voraussetzen“ ist standardmäßig eingeschaltet.

Das Ausschalten dieser Voraussetzung deaktiviert nur die Startprüfung. Ein bereits eingerichteter Agent folgt weiterhin der systemweiten Sitzung, solange Erweiterung und Agent aktiviert bleiben. Um den Safari-Schutz vollständig auszuschalten, die Erweiterung in Safari deaktivieren.

## Wie Beginn und Ablauf funktionieren

- Der root-eigene Hosts-Helper bleibt für die bisherige Systemsperre zuständig.
- Ein unabhängiger **Benutzer-LaunchAgent** ruft dieselbe App-Binärdatei mit `--safari-agent` auf. Dieser Prozess startet keine SwiftUI-Fenster. Der Job liegt im Bundle unter `Contents/Library/LaunchAgents/de.fore.safari-agent.plist` und verwendet `BundleProgram = Contents/MacOS/ForE`.
- Alle drei Sekunden prüft der Agent den root-eigenen Sitzungsstatus. Er schreibt Domainliste, Sitzungs-ID und Frist atomar in die gemeinsame App Group und ruft `SFContentBlockerManager.reloadContentBlocker` auf.
- Die sandboxed Erweiterung liest nur die gemeinsame App Group und liefert WebKit-kompatibles JSON. Sie benötigt keine Netzwerkfreigabe und liest keine Seiteninhalte. Ein Nachweis hält fest, welche Konfiguration sie tatsächlich gelesen hat.
- Erst nach erfolgreicher Safari-Kompilierung und passendem Erweiterungsnachweis bestätigt der Agent die aktive Sitzung. Die App prüft diese Bestätigung nach dem Hosts-Start. Fehlt sie, wird eine vorzeitige Systemfreigabe angefragt und der Fehler angezeigt; dafür kann macOS erneut Administratorrechte verlangen.
- Bei Ablauf, Abbruch oder fehlendem/ungültigem Systemstatus erzeugt der Agent eine inaktive Regelliste. Die Liste enthält genau eine Regel mit `url-filter: ".*"` und der nicht blockierenden Aktion `ignore-previous-rules`. WebKit akzeptiert kein leeres Regelarray und kann die frühere `^$`-Sperrregel als allgemeinen Treffer behandeln. Die neue Aktion betrifft ausschließlich ForEs eigene Regelliste. Fehlgeschlagene Aktualisierungen werden erneut versucht.
- Kompilierte Regeln haben **keinen eingebauten Timer**. Die Prüfung der Ablaufzeit im Erweiterungscode ersetzt deshalb den Agenten nicht. Der `KeepAlive`-Job muss auch bei geschlossener App aktiv bleiben. Nach Ab-/Anmeldung, Neustart oder Aufwachen wird die Frist erneut geprüft. Ein ausbleibender Safari-API-Callback wird als Fehler gemeldet; der Agent bleibt aktiv und wiederholt die Aktualisierung nach einer Pause.

Die Hosts-Zeitstatistik behält ihre bisherige Bedeutung. Sie ist kein Nachweis, dass in jedem Moment jeder Browser blockiert war. Wird die Erweiterung oder der Agent während einer Sitzung manuell deaktiviert, kann ForE dies nicht verhindern.

## Nach einem Update oder Umzug

### Nach rund 40 Sekunden: Hintergrunddienst nicht bereit

Der erste Status wurde bisher erst nach dem ersten Safari-Aufruf geschrieben; auch der Timer startete erst danach. Blockierte bereits der synchrone Einstieg in SafariServices, konnte der Agent deshalb weder seinen Start noch seinen Timeout melden. Die neue Version schreibt zuerst einen Initialisierungsstatus und startet den Timer. Safari-Aufrufe laufen auf einer getrennten Queue, Antworten und Statusänderungen auf einer seriellen Zustandsqueue. Ein blockierter Safari-Aufruf verhindert dadurch keine Statusmeldungen mehr. Der Hauptthread der App führt keine synchronen Service-Management-Abfragen aus; die Oberfläche liest einen zwischengespeicherten Registrierungsstatus.

Die Meldung `This method should not be called on the main thread` nennt ohne Stacktrace nicht den verursachenden Aufruf. Ebenso ist `CGSWindowShmemCreateWithPort failed` allein kein Nachweis der Fehlerursache. Die Korrektur behebt den gefundenen Startablauf und trennt nicht reagierende Safari-Aufrufe vom Status-Timer.

Das Target **ForE** setzt **Enable Debug Dylib Support** ausdrücklich auf **No**, weil dieselbe Binärdatei auch von launchd gestartet wird. Apple verwendet diese Einstellung ebenfalls für das launchd-Programm im [SMAppService-Beispiel](https://developer.apple.com/forums/thread/802443). App und Erweiterung tragen jetzt Build-Version **3**, einschließlich des [Safari-Freigabe-Fixes](Safari-Focus-Fix.md). Das ist eine Kompatibilitätseinstellung und keine nachgewiesene Diagnose des jeweiligen Macs.

Nach dem Update das Schema vollständig bereinigen und neu bauen, Xcode stoppen, die gesamte gebaute App nach Programme kopieren und genau diese Kopie öffnen. Anschließend den Hintergrundagenten erneut einrichten. Weder eine erforderliche Benutzerfreigabe noch die Regelbestätigung werden übersprungen.

Bleibt ein aktueller Agentstatus aus, zeigt ForE nun eine eigene Startfehlermeldung. Öffne dann die macOS-App **Konsole**, starte das Streaming und filtere nach der Kategorie **SafariAgent**. Dort meldet der separate Hintergrundprozess seinen Eintrittspunkt, den Containerzugriff und Initialisierungsfehler. Die Debugger-Konsole der Haupt-App zeigt diese Meldungen nicht zuverlässig. Für weitere Diagnose die betreffenden Textzeilen einschließlich des ersten Fehlers verwenden.

### Einrichtung endet mit einer Zeitüberschreitung

Die Einrichtung wartet jetzt bis zu 41 Sekunden. Zuvor brach die App bereits nach 15 Sekunden ab, obwohl der Agent Safari bis zu 30 Sekunden Zeit für die Regelaktualisierung gab. Ein erfolgreicher erster Reload nach etwa 20 Sekunden darf deshalb nicht mehr als Fehler erscheinen.

**Hintergrundagent einrichten** startet auch einen bereits registrierten Agenten kontrolliert neu: ForE wartet seine Abmeldung ab, entfernt seinen alten Status und registriert den Dienst erneut. Damit wird nach einem Update die aktuelle Programmversion verwendet; die letzte Fehlermeldung eines alten Prozesses kann die neue Einrichtung nicht sofort abbrechen. Eine erforderliche macOS-Hintergrundfreigabe bleibt erforderlich. Die automatische Statusprüfung startet den Dienst nicht neu.

Bleibt der Safari-Callback aus, meldet der Agent den konkreten Fehler nach 30 Sekunden und bleibt erreichbar. Er beendet sich nicht mehr in einer Neustartschleife. Ein verspäteter Callback darf keinen neueren Regelsatz bestätigen. Nach einem Fehler erfolgen weitere Versuche mit 30 Sekunden Pause; ein geänderter Sitzungsstatus, insbesondere die Freigabe nach Ablauf, wartet nicht diese Pause ab. Ein erfolgreicher Safari-Reload und der passende aktuelle Erweiterungsnachweis bleiben Voraussetzung für die Bereitschaft.

Nach dem Bauen und Ersetzen der App Safari vollständig beenden und erneut öffnen, die ForE-Erweiterung prüfen und in ForE **Hintergrundagent einrichten** wählen. Bleibt Safari ohne Antwort, kann eine beschädigte oder falsch signierte Erweiterung vorliegen. Die Korrektur der Warte- und Wiederholungslogik beweist nicht, dass Safari auf jedem Mac erfolgreich startet.

Auf dem Mac prüfen: Einrichtung mit einem langsamen ersten Reload; wiederholte Einrichtung nach einem Fehler; fehlende Hintergrundfreigabe; fehlender Safari-Callback; kurze Sitzung und anschließende Freigabe bei geschlossener App. Der GitHub-Workflow prüft das entpackte Archiv mit Swift-Tests und unsigned Debug-/Release-Builds. Persönliche Signierung, Dienstregistrierung und die tatsächliche Safari-Funktion benötigen den lokalen Mac-Test.

### Erweiterung startet nicht: fehlendes AppKit

Ein macOS-Content-Blocker benötigt die AppKit-Laufzeit. In dieser Version importiert `ContentBlockerRequestHandler.swift` deshalb `Cocoa`; das Target **ForESafariBlocker** verknüpft zusätzlich explizit das Systemframework **AppKit.framework**. Eine reine Foundation-Erweiterung konnte unter macOS 13 beim PlugInKit-Start die Meldung `misconfigured plugin; external subsystem [NSSharingService_Subsystem] not present; possible missing linkage` auslösen. Der eigene Request-Handler wurde dabei nicht erreicht; Agent und Haupt-App warteten auf die Regelaktualisierung.

Ein vorhandenes Projekt lässt sich ohne erneuten Download korrigieren:

1. Im Target **ForESafariBlocker → Build Phases → Link Binary With Libraries** über **+** `AppKit.framework` als **Required** hinzufügen. Das Systemframework wird nicht in die App kopiert; falls Xcode eine Einbettungsoption anzeigt, **Do Not Embed** wählen.
2. In `SafariBlocker/ContentBlockerRequestHandler.swift` die erste Zeile von `import Foundation` zu `import Cocoa` ändern. `import ForECore` bleibt bestehen.
3. Die App-Group-Berechtigungen beider Targets beibehalten, das vollständige Schema bereinigen und neu bauen. Safari vollständig beenden und wieder öffnen. Den bereits laufenden ForE-Agenten aus der neu gebauten App neu starten, bevor erneut geprüft wird.
4. Erst ein erfolgreich abgeschlossener Safari-Reload, ein neuer `safari-extension-receipt.json`-Nachweis in der gemeinsamen App Group und der passende frische Agentstatus belegen die erfolgreiche Einrichtung. Auch die Freigabe nach Sitzungsende bei geschlossener Haupt-App prüfen.

Zur technischen Kontrolle auf dem Mac zeigt `otool -L` für die gebaute Erweiterungsbinärdatei unter `ForE.app/Contents/PlugIns/ForESafariBlocker.appex/Contents/MacOS/ForESafariBlocker` die AppKit-Verknüpfung. Eine Logmeldung allein ist kein Ersatz für den anschließenden Funktionstest.

Den Agent nicht aus einem später gelöschten Build-Ordner laufen lassen. Beende eine Sitzung und prüfe die Freigabe, bevor du die App ersetzt. Falls nach einer neuen Signierung bzw. einem Umzug der Dienst nicht mehr startet, den alten Hintergrundeintrag in den macOS-Anmeldeobjekten prüfen und die Einrichtung aus der neuen App erneut durchführen. Eine noch registrierte alte Kopie darf nicht parallel dieselbe App Group beschreiben.

### Meldung „Die registrierte ForE-App wurde nicht gefunden“

Diese Meldung der vorherigen Version war zu pauschal: `SMAppService.Status.notFound` bedeutet, dass macOS den Dienst nicht finden konnte. Sie beweist nicht, dass die App außerhalb von Programme liegt. Die alte Einrichtung hat in diesem Zustand überhaupt keinen Registrierungsversuch unternommen.

Die korrigierte Einrichtung prüft zuerst die tatsächlich laufende App auf `Contents/Library/LaunchAgents/de.fore.safari-agent.plist` und das zugehörige Programm. Anschließend versucht sie auch bei `.notFound` eine Registrierung. Falls dieser Versuch scheitert und keine Benutzerfreigabe aussteht, entfernt sie gezielt den alten ForE-Diensteintrag, wartet den Abschluss ab und versucht die Registrierung einmal erneut. Die explizite Einrichtung startet bereits aktivierte Dienste kontrolliert neu; auf Benutzerfreigabe wartende Dienste werden nicht erneut registriert. Fehler enthalten nun die Operation, Fehlerdomain, Fehlernummer und den laufenden App-Pfad. Die Prüfung auf einen lebenden Agenten und bestätigte Safari-Regeln bleibt erforderlich.

Nach Installation dieses Quellcode-Fixes:

1. Eine aktive Sitzung beenden und die Freigabe prüfen. ForE schließen und Xcode stoppen.
2. In Xcode das korrigierte Projekt öffnen, die bisherigen eigenen Team-/Signierungs-/App-Group-Einstellungen übernehmen und **Product → Clean Build Folder** ausführen. Anschließend das Schema **ForE** vollständig bauen.
3. Unter **Products → ForE.app → Show in Finder** genau die neu gebaute App nach `/Applications` (Finder: Programme) kopieren und die alte App ersetzen. Nicht nur den Quellcode oder die `.xcodeproj` kopieren. Nach dem Kopieren keine neue Xcode-Kopie starten.
4. `/Applications/ForE.app` öffnen, die Safari-Erweiterung prüfen und **Hintergrundagent einrichten** wählen. Falls erforderlich, ForE unter macOS **Allgemein → Anmeldeobjekte** bzw. **Anmeldeobjekte & Erweiterungen** im Hintergrund erlauben. Anschließend **Status prüfen** wählen.

Die eingebettete Dienstdatei lässt sich ohne Systemänderung im Terminal prüfen:

```sh
plutil -lint "/Applications/ForE.app/Contents/Library/LaunchAgents/de.fore.safari-agent.plist"
test -x "/Applications/ForE.app/Contents/MacOS/ForE" && echo "ForE-Programm vorhanden"
```

Fehlt die Dienstdatei, hilft das Verschieben derselben unvollständigen App nicht: Dann muss das vollständige Schema neu gebaut werden. Keine Plist nachträglich in die signierte App kopieren, da das die Signatur beschädigt. Für diese Reparatur ist kein globales `sfltool resetbtm` erforderlich.

**Falls Xcode `Cannot find 'SMAppServiceErrorDomain' in scope` meldet:** Die aktuelle Fassung vergleicht an beiden Stellen `failure.domain` mit dem String `"SMAppServiceErrorDomain"`. Die vorherige Fassung hat stattdessen das in älteren SDKs fehlende Konstantensymbol ohne Anführungszeichen verwendet. In einem bestehenden Projekt beide Vergleiche entsprechend ändern und erneut bauen. Dafür weder das Mindestziel macOS 13 erhöhen noch Benutzerfreigaben umgehen. Der Vergleich bleibt auf dieselbe Fehlerdomain und dieselben Fehlercodes beschränkt.

Grundlagen: [Apple: Statuswerte](https://developer.apple.com/documentation/servicemanagement/smappservice/status-swift.enum), [Apple: Registrierung](https://developer.apple.com/documentation/servicemanagement/smappservice/register%28%29). Das gezielte Entfernen vor einer erneuten Registrierung bei veralteten Einträgen wird auch in den [Karabiner-Entwicklungsnotizen](https://github.com/pqrs-org/Karabiner-Elements/blob/main/DEVELOPMENT.md#macos-service-management) beschrieben; die dortigen Beobachtungen betreffen Daemons und beweisen nicht die konkrete Ursache auf jedem Mac.

## Manuelle Freigabe und Deinstallation

**Falls Safari nach Sitzungsende blockiert bleibt:** In **Safari → Einstellungen → Erweiterungen** **ForE Safari-Schutz** ausschalten und die Website neu laden. Dadurch werden dessen gespeicherte Regeln nicht mehr angewendet. Andere Inhaltsblocker werden von ForE nicht verändert. Der Hosts-Abschnitt läuft davon unabhängig durch den Root-Helper aus.

Vor dem Löschen oder Verschieben der App alle Sitzungen beenden, die Freigabe prüfen und die Safari-Erweiterung deaktivieren. Den Benutzer-Job kann man im Terminal entladen:

```sh
launchctl bootout "gui/$(id -u)/de.fore.safari-agent"
```

Den zugehörigen Hintergrundeintrag zusätzlich in den macOS-Anmeldeobjekten deaktivieren. Das bloße Schließen der App beendet den Agenten absichtlich nicht. Die Anleitung zum Entfernen des separaten Hosts-Helpers steht in der README.

## Prüfung mit aktiviertem Privat-Relay

1. Passend signierte App auf **macOS 13** installieren und beide Statusanzeigen auf „bereit“ prüfen.
2. Privat-Relay eingeschaltet lassen. Eine bisher erreichbare Testdomain wählen, Safari-Tabs schließen, eine einminütige Sitzung starten und die Domain frisch aufrufen. Eine neue Anfrage muss scheitern. Andere Domains müssen erreichbar bleiben.
3. App mit **⌘Q** schließen. Nach Ablauf muss Safari neue Anfragen wieder zulassen; ohne erneute App-Öffnung testen.
4. Vorzeitigen Abbruch, Ruhezustand über das Ende hinaus und Neustart während einer Sitzung testen.
5. Erweiterung deaktivieren, Agent im Hintergrund nicht erlauben und eine falsche App Group testen: Bei gewünschtem Safari-Schutz darf keine neue Sitzung unbemerkt als erfolgreich geschützt starten.
6. Einen externen Reload-Fehler bzw. nicht erreichbaren Agenten simulieren. Fehleranzeige und manuelle Freigabe über die Safari-Erweiterung prüfen.
7. Die korrigierte Registrierung auf einem Mac getrennt prüfen: erste Einrichtung ohne alten Eintrag; erneute Einrichtung aus einer verschobenen/ersetzten App bei `.notFound`; kontrollierter Neustart bei `.enabled` und unveränderte Freigabeanforderung bei `.requiresApproval`; fehlende eingebettete Dienstdatei. Nur die explizite Einrichtung darf eine Registrierung verändern. Nach einer Reparatur müssen weiterhin ein frischer Agentstatus und eine bestätigte Regelaktualisierung eintreffen. Fehler beim Entfernen oder Registrieren dürfen nicht als Erfolg erscheinen.

**Hier nicht als ausgeführt ausweisen:** Die Cloud-Umgebung ist Linux. Tests prüfen dort die Foundation-Regelerzeugung. Drei zusätzliche XCTest-Tests kompilieren aktive und inaktive Regeln auf einem Mac mit `WKContentRuleListStore` und prüfen echte WKWebView-Navigation vor und nach einer aktiven Sperre gegen einen lokalen HTTP-Testserver; Safari-Erweiterung, Privat-Relay, Signierung, App-Group-Berechtigung und Hintergrundregistrierung benötigen darüber hinaus diese manuellen Mac-Tests.
