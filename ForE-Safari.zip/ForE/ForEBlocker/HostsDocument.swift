import Foundation

/// Pure editing of ForE's own hosts section. Filesystem access, privilege checks,
/// request validation and durable writes belong to the privileged helper.
public enum HostsDocument {
    private static let begin = "# BEGIN FORE BLOCK"
    private static let end = "# END FORE BLOCK"

    private enum DocumentError: LocalizedError {
        case malformedMarkers
        case invalidDomain

        var errorDescription: String? {
            switch self {
            case .malformedMarkers:
                return "Der ForE-Abschnitt in /etc/hosts ist beschädigt oder nicht eindeutig. Bitte die markierten Zeilen prüfen."
            case .invalidDomain:
                return "Der Website-Name enthält ungültige Zeichen."
            }
        }
    }

    /// Removes exactly one complete marked section, preserving all other bytes.
    /// Missing, duplicate, nested, reversed or inline markers are rejected.
    public static func removingBlock(from text: String) throws -> String {
        let document = text as NSString
        let begins = ranges(of: begin, in: document)
        let ends = ranges(of: end, in: document)
        guard begins.count == ends.count, begins.count <= 1 else {
            throw DocumentError.malformedMarkers
        }
        guard let first = begins.first, let last = ends.first else { return text }
        guard first.location < last.location,
              isLineStart(first.location, in: document),
              isLineStart(last.location, in: document) else {
            throw DocumentError.malformedMarkers
        }
        // NSString indices deliberately support CRLF as two UTF-16 units. Swift
        // Character indices treat CRLF as one character, which can misidentify
        // line boundaries and accidentally reject otherwise valid hosts files.
        _ = try afterLine(NSMaxRange(first), in: document)
        let upper = try afterLine(NSMaxRange(last), in: document)
        return document.replacingCharacters(in: NSRange(location: first.location,
                                                        length: upper - first.location), with: "")
    }

    /// Applies an idempotent exact-host block. Caller supplies normalized DNS
    /// names. Bare domains also receive a www alias, never wildcard subdomains.
    public static func applying(domains: [String], to text: String) throws -> String {
        var clean = try removingBlock(from: text)
        var names = Set<String>()
        for domain in domains {
            // This local check prevents line/marker injection even if another
            // caller forgets the helper's stricter hostname normalization.
            guard !domain.isEmpty, domain.utf8.allSatisfy({ byte in
                (97...122).contains(byte) || (48...57).contains(byte) || byte == 45 || byte == 46
            }) else { throw DocumentError.invalidDomain }
            names.insert(domain)
            if !domain.hasPrefix("www."), domain.utf8.count <= 249 {
                names.insert("www." + domain)
            }
        }
        if !clean.isEmpty && clean.utf8.last != 10 { clean += "\n" }
        let entries = names.sorted().flatMap { ["0.0.0.0 \($0)", ":: \($0)"] }
        return clean + ([begin, "# Managed by ForE. Automatically removed after the focus session."]
                        + entries + [end]).joined(separator: "\n") + "\n"
    }

    private static func ranges(of marker: String, in text: NSString) -> [NSRange] {
        var result: [NSRange] = []
        var start = 0
        while start < text.length {
            let range = text.range(of: marker, options: [], range: NSRange(location: start, length: text.length - start))
            if range.location == NSNotFound { break }
            result.append(range)
            start = NSMaxRange(range)
        }
        return result
    }

    private static func isLineStart(_ index: Int, in text: NSString) -> Bool {
        index == 0 || text.character(at: index - 1) == 10
    }

    private static func afterLine(_ index: Int, in text: NSString) throws -> Int {
        if index == text.length { return index }
        if text.character(at: index) == 10 { return index + 1 }
        if text.character(at: index) == 13, index + 1 < text.length,
           text.character(at: index + 1) == 10 { return index + 2 }
        throw DocumentError.malformedMarkers
    }
}
