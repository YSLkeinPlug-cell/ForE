import Foundation
import Darwin
#if os(macOS)
import MachO
#endif

// This tool is invoked with an explicit administrator authorization by ForE.
// It never accepts a command, executable path, hosts path, or installation path
// from the caller. Its launchd job outlives the UI and releases expired blocks.

private struct StartRequest: Codable {
    let id: UUID
    let domains: [String]
    let durationSeconds: Double
}

private struct ActiveSession: Codable {
    let id: UUID
    let domains: [String]
    let startedAt: Double
    let endsAt: Double
}

private struct Receipt: Codable {
    let id: UUID
    let domains: [String]
    let startedAt: Double
    let endedAt: Double
    let plannedEnd: Double
    let completed: Bool
}

private struct BlockState: Codable {
    var active: ActiveSession?
    var lastFinished: Receipt?
}

// A durable release journal prevents an interrupted manual stop from reblocking
// the machine on the next watchdog tick. It is deliberately separate from the
// public wire format, which the unprivileged UI reads.
private struct ReleaseIntent: Codable {
    let session: ActiveSession
    let receipt: Receipt
}

private enum HelperError: LocalizedError {
    case message(String)
    var errorDescription: String? {
        switch self { case .message(let text): return text }
    }
}

private enum Paths {
    static let support = "/Library/Application Support/ForE"
    static let state = support + "/block-state.json"
    static let releaseIntent = support + "/release-intent.json"
    static let lock = support + "/block.lock"
    static let installedHelper = "/Library/PrivilegedHelperTools/de.fore.blocker"
    static let launchPlist = "/Library/LaunchDaemons/de.fore.blocker.plist"
    static let label = "de.fore.blocker"
    // /etc is a standard macOS symlink. Use its canonical system destination.
    static let hosts = "/private/etc/hosts"
}

private let manager = FileManager.default
private let encoder: JSONEncoder = {
    let encoder = JSONEncoder()
    encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
    return encoder
}()

private func fail(_ text: String) -> HelperError { .message(text) }

private func systemError(_ action: String) -> HelperError {
    fail("\(action): \(String(cString: strerror(errno)))")
}

private func metadata(_ path: String) throws -> stat? {
    var info = stat()
    if lstat(path, &info) == 0 { return info }
    if errno == ENOENT { return nil }
    throw systemError("Datei kann nicht geprüft werden: \(path)")
}

private func isRegular(_ info: stat) -> Bool {
    info.st_mode & mode_t(S_IFMT) == mode_t(S_IFREG)
}

private func requireProtectedDirectory(_ path: String, create: Bool = false) throws {
    if try metadata(path) == nil, create {
        guard mkdir(path, 0o755) == 0 || errno == EEXIST else {
            throw systemError("Verzeichnis kann nicht angelegt werden: \(path)")
        }
    }
    guard let info = try metadata(path),
          info.st_mode & mode_t(S_IFMT) == mode_t(S_IFDIR),
          info.st_uid == 0, info.st_mode & 0o022 == 0 else {
        throw fail("Unsicheres Systemverzeichnis: \(path). Es muss root gehören und darf nicht allgemein beschreibbar sein.")
    }
}

private func prepareStorage() throws {
    try requireProtectedDirectory("/Library")
    try requireProtectedDirectory("/Library/Application Support")
    try requireProtectedDirectory(Paths.support, create: true)
}

private func checkedData(_ path: String, maximum: Int = 1_048_576, protected: Bool = true) throws -> Data {
    let descriptor = open(path, O_RDONLY | O_NOFOLLOW | O_CLOEXEC | O_NONBLOCK)
    guard descriptor >= 0 else { throw systemError("Datei kann nicht gelesen werden: \(path)") }
    defer { close(descriptor) }
    var info = stat()
    guard fstat(descriptor, &info) == 0 else { throw systemError("Datei kann nicht geprüft werden") }
    guard isRegular(info), info.st_size >= 0, info.st_size <= maximum else {
        throw fail("Ungültige Datei oder Dateigröße: \(path)")
    }
    if protected && (info.st_uid != 0 || info.st_mode & 0o022 != 0) {
        throw fail("Unsichere Dateiberechtigungen: \(path)")
    }
    var data = Data()
    var buffer = [UInt8](repeating: 0, count: 16_384)
    while true {
        let count = read(descriptor, &buffer, buffer.count)
        if count < 0 {
            if errno == EINTR { continue }
            throw systemError("Datei kann nicht gelesen werden")
        }
        if count == 0 { break }
        data.append(contentsOf: buffer.prefix(count))
        guard data.count <= maximum else { throw fail("Datei ist zu groß: \(path)") }
    }
    return data
}

// Write a sibling file, fsync it, and rename atomically. Root-owned directories
// and O_EXCL/O_NOFOLLOW prevent following caller-controlled symbolic links.
private func atomicWrite(_ data: Data, to path: String, mode: mode_t = 0o644,
                         owner: uid_t = 0, group: gid_t = 0) throws {
    if let info = try metadata(path) {
        guard isRegular(info), info.st_uid == 0, info.st_mode & 0o022 == 0 else {
            throw fail("Unsicheres Schreibziel: \(path)")
        }
    }
    let temporary = path + ".fore-" + UUID().uuidString
    let descriptor = open(temporary, O_WRONLY | O_CREAT | O_EXCL | O_NOFOLLOW | O_CLOEXEC, 0o600)
    guard descriptor >= 0 else { throw systemError("Temporäre Datei kann nicht erstellt werden") }
    var closed = false
    defer {
        if !closed { close(descriptor) }
        unlink(temporary)
    }
    try data.withUnsafeBytes { bytes in
        guard let base = bytes.baseAddress else { return }
        var offset = 0
        while offset < bytes.count {
            let count = write(descriptor, base.advanced(by: offset), bytes.count - offset)
            if count < 0 {
                if errno == EINTR { continue }
                throw systemError("Datei kann nicht geschrieben werden")
            }
            guard count > 0 else { throw fail("Datei konnte nicht vollständig geschrieben werden.") }
            offset += count
        }
    }
    guard fchown(descriptor, owner, group) == 0, fchmod(descriptor, mode) == 0,
          fsync(descriptor) == 0 else { throw systemError("Datei kann nicht gesichert werden") }
    guard close(descriptor) == 0 else { closed = true; throw systemError("Datei kann nicht geschlossen werden") }
    closed = true
    guard rename(temporary, path) == 0 else { throw systemError("Datei kann nicht ersetzt werden: \(path)") }
    let parent = (path as NSString).deletingLastPathComponent
    let directory = open(parent, O_RDONLY | O_CLOEXEC)
    if directory >= 0 { _ = fsync(directory); close(directory) }
}

private func removeProtectedFile(_ path: String) throws {
    guard let info = try metadata(path) else { return }
    guard isRegular(info), info.st_uid == 0, info.st_mode & 0o022 == 0 else {
        throw fail("Unsichere Datei: \(path)")
    }
    guard unlink(path) == 0 else { throw systemError("Datei kann nicht entfernt werden: \(path)") }
}

private func withLock<T>(_ action: () throws -> T) throws -> T {
    try prepareStorage()
    let descriptor = open(Paths.lock, O_RDWR | O_CREAT | O_NOFOLLOW | O_CLOEXEC, 0o600)
    guard descriptor >= 0 else { throw systemError("Sperrdatei kann nicht geöffnet werden") }
    defer { close(descriptor) }
    var info = stat()
    guard fstat(descriptor, &info) == 0, isRegular(info), info.st_uid == 0,
          info.st_mode & 0o077 == 0 else { throw fail("Unsichere Sperrdatei.") }
    guard flock(descriptor, LOCK_EX) == 0 else { throw systemError("Sperrdatei kann nicht gesperrt werden") }
    defer { flock(descriptor, LOCK_UN) }
    return try action()
}

private func readState() throws -> BlockState {
    guard try metadata(Paths.state) != nil else { return BlockState() }
    let state = try JSONDecoder().decode(BlockState.self, from: checkedData(Paths.state))
    if let active = state.active {
        try validateSession(active)
    }
    return state
}

private func saveState(_ state: BlockState) throws {
    try atomicWrite(encoder.encode(state), to: Paths.state)
}

private func normalizedDomains(_ domains: [String]) throws -> [String] {
    guard !domains.isEmpty, domains.count <= 200 else { throw fail("Bitte 1 bis 200 Websites auswählen.") }
    var result = Set<String>()
    let reserved = Set(["local", "localhost", "localdomain", "lan", "home", "internal", "invalid", "test", "example", "onion", "arpa"])
    for raw in domains {
        let domain = raw.lowercased()
        guard domain == raw.trimmingCharacters(in: .whitespacesAndNewlines).lowercased(),
              domain.utf8.count <= 253, domain.utf8.allSatisfy({ $0 < 128 }),
              domain != "broadcasthost",
              !reserved.contains(domain.split(separator: ".").last.map(String.init) ?? "") else {
            throw fail("Ungültiger Website-Name: \(raw)")
        }
        let labels = domain.split(separator: ".", omittingEmptySubsequences: false)
        guard labels.count >= 2,
              labels.allSatisfy({ label in
                  !label.isEmpty && label.utf8.count <= 63 && label.first != "-" && label.last != "-"
                  && label.utf8.allSatisfy { (97...122).contains($0) || (48...57).contains($0) || $0 == 45 }
              }),
              let last = labels.last, last.utf8.contains(where: { (97...122).contains($0) }) else {
            throw fail("Bitte einen Domainnamen ohne Pfad, Port oder IP-Adresse verwenden: \(raw)")
        }
        result.insert(domain)
    }
    return result.sorted()
}

private func validateSession(_ session: ActiveSession) throws {
    _ = try normalizedDomains(session.domains)
    guard session.startedAt.isFinite, session.endsAt.isFinite,
          session.endsAt > session.startedAt,
          session.endsAt - session.startedAt <= 14_401 else { throw fail("Ungültiger Sitzungsstatus.") }
}

@discardableResult
private func updateHosts(domains: [String]?) throws -> Bool {
    guard let info = try metadata(Paths.hosts), isRegular(info), info.st_uid == 0,
          info.st_mode & 0o022 == 0 else { throw fail("/etc/hosts ist keine sichere reguläre Systemdatei.") }
    let original = try checkedData(Paths.hosts, maximum: 8_388_608)
    guard let text = String(data: original, encoding: .utf8) else { throw fail("/etc/hosts enthält kein gültiges UTF-8.") }
    let desired: String
    if let domains {
        desired = try HostsDocument.applying(domains: domains, to: text)
    } else {
        desired = try HostsDocument.removingBlock(from: text)
    }
    let replacement = Data(desired.utf8)
    if replacement == original { return false }
    // Detect edits made while we prepared the replacement. External writers do
    // not participate in our lock; this reduces accidental overwrites.
    guard try checkedData(Paths.hosts, maximum: 8_388_608) == original else {
        throw fail("/etc/hosts wurde gleichzeitig geändert. Bitte erneut versuchen.")
    }
    try atomicWrite(replacement, to: Paths.hosts, mode: info.st_mode & 0o777,
                    owner: info.st_uid, group: info.st_gid)
    guard try checkedData(Paths.hosts, maximum: 8_388_608) == replacement else {
        throw fail("Die Website-Sperre konnte nicht überprüft werden.")
    }
    return true
}

@discardableResult
private func run(_ executable: String, _ arguments: [String], required: Bool = true) throws -> Int32 {
    let process = Process()
    process.executableURL = URL(fileURLWithPath: executable)
    process.arguments = arguments
    // Do not inherit proxy credentials, user-controlled tool paths, or DYLD
    // variables when running fixed system executables with administrator rights.
    process.environment = ["PATH": "/usr/bin:/bin:/usr/sbin:/sbin", "LANG": "en_US.UTF-8"]
    process.standardOutput = FileHandle.nullDevice
    process.standardError = FileHandle.nullDevice
    try process.run()
    process.waitUntilExit()
    if required && process.terminationStatus != 0 {
        throw fail("\((executable as NSString).lastPathComponent) fehlgeschlagen (\(process.terminationStatus)).")
    }
    return process.terminationStatus
}

private func flushDNS() {
    _ = try? run("/usr/bin/dscacheutil", ["-flushcache"], required: false)
    _ = try? run("/usr/bin/killall", ["-HUP", "mDNSResponder"], required: false)
}

private func currentExecutablePath() throws -> String {
    #if os(macOS)
    // Bundle.main can describe the enclosing .app when this CLI is stored in
    // Contents/Resources. Ask dyld for this process's executable instead, so the
    // watchdog always installs the helper and never the application's UI.
    var size: UInt32 = 0
    _ = _NSGetExecutablePath(nil, &size)
    guard size > 0, size <= 1_048_576 else { throw fail("Der Werkzeugpfad kann nicht ermittelt werden.") }
    var buffer = [CChar](repeating: 0, count: Int(size))
    guard _NSGetExecutablePath(&buffer, &size) == 0 else {
        throw fail("Der Werkzeugpfad kann nicht ermittelt werden.")
    }
    return URL(fileURLWithPath: String(cString: buffer)).resolvingSymlinksInPath().path
    #else
    throw fail("Das Sperrwerkzeug benötigt macOS.")
    #endif
}

private func installWatchdog() throws {
    try requireProtectedDirectory("/Library/PrivilegedHelperTools", create: true)
    try requireProtectedDirectory("/Library/LaunchDaemons")
    // Resolve the current executable, not an arbitrary caller-supplied path.
    let source = try currentExecutablePath()
    if source != Paths.installedHelper {
        let bytes = try checkedData(source, maximum: 52_428_800, protected: false)
        guard bytes.count > 32 else { throw fail("Das Sperrwerkzeug ist unvollständig.") }
        try atomicWrite(bytes, to: Paths.installedHelper, mode: 0o755)
    }
    let plist: [String: Any] = [
        "Label": Paths.label,
        "ProgramArguments": [Paths.installedHelper, "watchdog"],
        "RunAtLoad": true,
        "StartInterval": 10,
        "ProcessType": "Background",
        "StandardOutPath": "/dev/null",
        "StandardErrorPath": "/dev/null"
    ]
    let data = try PropertyListSerialization.data(fromPropertyList: plist, format: .xml, options: 0)
    try atomicWrite(data, to: Paths.launchPlist)
    try run("/bin/launchctl", ["enable", "system/" + Paths.label])
    if try run("/bin/launchctl", ["print", "system/" + Paths.label], required: false) != 0 {
        try run("/bin/launchctl", ["bootstrap", "system", Paths.launchPlist])
    }
    guard try run("/bin/launchctl", ["print", "system/" + Paths.label], required: false) == 0 else {
        throw fail("Die automatische Entsperrung konnte nicht registriert werden.")
    }
}

private func resumeRelease(_ intent: ReleaseIntent, state: inout BlockState) throws {
    try validateSession(intent.session)
    guard state.active == nil || state.active?.id == intent.session.id else {
        throw fail("Die Wiederherstellung gehört zu einer anderen Sitzung.")
    }
    if try updateHosts(domains: nil) { flushDNS() }
    state.active = nil
    state.lastFinished = intent.receipt
    try saveState(state)
    try removeProtectedFile(Paths.releaseIntent)
}

private func recoverRelease(state: inout BlockState) throws {
    guard try metadata(Paths.releaseIntent) != nil else { return }
    let intent = try JSONDecoder().decode(ReleaseIntent.self, from: checkedData(Paths.releaseIntent))
    try resumeRelease(intent, state: &state)
}

private func release(_ session: ActiveSession, state: inout BlockState, now: Double) throws {
    let complete = now >= session.endsAt
    let receipt = Receipt(id: session.id, domains: session.domains, startedAt: session.startedAt,
                          endedAt: min(max(now, session.startedAt), session.endsAt),
                          plannedEnd: session.endsAt, completed: complete)
    let intent = ReleaseIntent(session: session, receipt: receipt)
    try atomicWrite(encoder.encode(intent), to: Paths.releaseIntent)
    try resumeRelease(intent, state: &state)
}

private func reconcile(state: inout BlockState) throws {
    try recoverRelease(state: &state)
    if let active = state.active {
        let now = Date().timeIntervalSince1970
        if now >= active.endsAt {
            try release(active, state: &state, now: now)
        } else if try updateHosts(domains: active.domains) {
            flushDNS()
        }
    } else if try updateHosts(domains: nil) {
        // Recover a crash between applying hosts entries and persisting start.
        // Such an uncommitted session is never credited as focus time.
        flushDNS()
    }
}

private func start(_ requestPath: String) throws -> BlockState {
    let data = try checkedData(requestPath, maximum: 65_536, protected: false)
    let request = try JSONDecoder().decode(StartRequest.self, from: data)
    let domains = try normalizedDomains(request.domains)
    guard request.durationSeconds.isFinite, (60...14_400).contains(request.durationSeconds) else {
        throw fail("Eine Fokussitzung muss zwischen 1 Minute und 4 Stunden dauern.")
    }
    var state = try readState()
    try recoverRelease(state: &state)
    // Always verify the recovery mechanism before applying a new block.
    try installWatchdog()
    try reconcile(state: &state)
    if let active = state.active {
        guard active.id == request.id else { throw fail("Es läuft bereits eine andere Fokussitzung.") }
        return state // An authorization retry must not extend the deadline.
    }
    guard state.lastFinished?.id != request.id else { return state }
    do {
        if try updateHosts(domains: domains) { flushDNS() }
        let appliedAt = Date().timeIntervalSince1970
        let active = ActiveSession(id: request.id, domains: domains, startedAt: appliedAt,
                                   endsAt: appliedAt + request.durationSeconds)
        state.active = active
        try saveState(state)
    } catch {
        // Keep expiry durable if rollback fails. The watchdog owns this state,
        // so its next tick can retry cleanup instead of leaving permanent hosts
        // entries after a disk/write failure.
        let initialError = error
        do {
            if try updateHosts(domains: nil) { flushDNS() }
        } catch {
            let now = Date().timeIntervalSince1970
            state.active = ActiveSession(id: request.id, domains: domains,
                                         startedAt: now, endsAt: now + 1)
            try? saveState(state)
            throw fail("Start fehlgeschlagen; automatische Entsperrung wird erneut versucht. \(initialError.localizedDescription) / \(error.localizedDescription)")
        }
        throw initialError
    }
    return state
}

private func execute() throws {
    guard geteuid() == 0 else { throw fail("Dieses Werkzeug benötigt eine ausdrückliche Administratorfreigabe.") }
    let args = Array(CommandLine.arguments.dropFirst())
    guard let command = args.first else { throw fail("Verwendung: ForEBlocker start <JSON> | stop <UUID> | watchdog | status") }
    let state: BlockState = try withLock {
        switch command {
        case "start":
            guard args.count == 2 else { throw fail("Der Startauftrag fehlt.") }
            return try start(args[1])
        case "stop":
            guard args.count == 2, let id = UUID(uuidString: args[1]) else { throw fail("Ungültige Sitzungs-ID.") }
            var state = try readState()
            try recoverRelease(state: &state)
            if let active = state.active {
                guard active.id == id else { throw fail("Eine andere Sitzung ist aktiv. Bitte den Status aktualisieren.") }
                try release(active, state: &state, now: Date().timeIntervalSince1970)
            } else {
                try reconcile(state: &state)
            }
            return state
        case "watchdog":
            guard args.count == 1 else { throw fail("Ungültiger Aufruf.") }
            let loadedState: BlockState
            do {
                loadedState = try readState()
            } catch {
                // Fail open if state becomes unreadable/corrupt. Without a
                // trustworthy deadline, keeping the hosts block could strand
                // the user indefinitely. Do not fabricate a focus receipt.
                if try updateHosts(domains: nil) { flushDNS() }
                throw fail("Der Sitzungsstatus ist unlesbar; die Sperre wurde sicherheitshalber entfernt. \(error.localizedDescription)")
            }
            var state = loadedState
            do {
                try reconcile(state: &state)
            } catch {
                // An unreadable release journal or another recovery error must
                // not turn a timed focus block into an indefinite one. Keep
                // the previous receipt, clear active time without awarding it.
                let recoveryError = error
                if try updateHosts(domains: nil) { flushDNS() }
                state.active = nil
                try saveState(state)
                try removeProtectedFile(Paths.releaseIntent)
                throw fail("Wiederherstellung fehlgeschlagen; die Sperre wurde entfernt. \(recoveryError.localizedDescription)")
            }
            return state
        case "status":
            guard args.count == 1 else { throw fail("Ungültiger Aufruf.") }
            return try readState()
        default:
            throw fail("Unbekannter Befehl.")
        }
    }
    FileHandle.standardOutput.write(try encoder.encode(state))
    FileHandle.standardOutput.write(Data("\n".utf8))
}

do {
    try execute()
} catch {
    FileHandle.standardError.write(Data(("ForE: " + error.localizedDescription + "\n").utf8))
    exit(EXIT_FAILURE)
}
