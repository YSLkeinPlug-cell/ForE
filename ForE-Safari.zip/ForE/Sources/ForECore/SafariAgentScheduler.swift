import Foundation
import Dispatch

/// Keeps heartbeats and reload bookkeeping independent of synchronous system
/// API entry points. Only the state queue runs initialization, ticks and results.
public final class SafariAgentScheduler: @unchecked Sendable {
    private let stateQueue = DispatchQueue(label: "de.fore.safari-agent.state", qos: .utility)
    private let requestQueue = DispatchQueue(label: "de.fore.safari-agent.requests", qos: .utility)
    private var timer: DispatchSourceTimer?

    public init() {}

    public func start(interval: TimeInterval, initialize: @escaping () -> Void, tick: @escaping () -> Void) {
        precondition(interval.isFinite && interval > 0, "The agent polling interval must be positive and finite.")
        stateQueue.async {
            guard self.timer == nil else { return }
            initialize()
            let source = DispatchSource.makeTimerSource(queue: self.stateQueue)
            source.schedule(deadline: .now() + interval, repeating: interval)
            source.setEventHandler(handler: tick)
            self.timer = source
            source.resume()
            // The timer is live before any first-tick system request starts.
            tick()
        }
    }

    public func performRequest(_ work: @escaping () -> Void) {
        requestQueue.async { work() }
    }

    public func receiveResult(_ work: @escaping () -> Void) {
        stateQueue.async { work() }
    }

    public func stop() {
        stateQueue.async {
            self.timer?.setEventHandler {}
            self.timer?.cancel()
            self.timer = nil
        }
    }

    deinit {
        timer?.setEventHandler {}
        timer?.cancel()
    }
}
