import Foundation

/// Records which snapshot the sandboxed extension actually read. The user agent
/// verifies this after Safari reports successful rule compilation, so a missing
/// App Group permission cannot silently appear as successful protection.
public struct SafariRuleReceipt: Codable {
    public var snapshot: SafariRuleSet
    public var generatedAt: Date
    public var readError: String?

    public init(snapshot: SafariRuleSet, generatedAt: Date = Date(), readError: String? = nil) {
        self.snapshot = snapshot
        self.generatedAt = generatedAt
        self.readError = readError
    }

    public func confirms(_ attempt: SafariReloadAttempt) -> Bool {
        readError == nil && snapshot == attempt.snapshot
            && generatedAt >= attempt.startedAt.addingTimeInterval(-1)
    }
}

/// The UI must allow the agent to observe and report its callback deadline.
public enum SafariReloadTiming {
    public static let pollInterval: TimeInterval = 3
    public static let callbackTimeout: TimeInterval = 30
    public static let setupTimeout = callbackTimeout + 2 * pollInterval + 5
}

public struct SafariReloadAttempt {
    public let id: UUID
    public let snapshot: SafariRuleSet
    public let startedAt: Date
    public let startedUptime: TimeInterval
}

/// Serializes reloads and rejects callbacks belonging to an abandoned request.
/// Failed snapshots wait for an explicit retry or a state change, rather than
/// repeatedly restarting the process and losing the useful error.
public struct SafariReloadState {
    public private(set) var pending: SafariReloadAttempt?
    public private(set) var applied: SafariRuleSet?
    public private(set) var failed: SafariRuleSet?

    public init() {}

    public func shouldReload(_ snapshot: SafariRuleSet) -> Bool {
        pending == nil && applied != snapshot && failed != snapshot
    }

    public mutating func begin(_ snapshot: SafariRuleSet, now: Date, uptime: TimeInterval) -> SafariReloadAttempt? {
        guard shouldReload(snapshot) else { return nil }
        let attempt = SafariReloadAttempt(id: UUID(), snapshot: snapshot, startedAt: now, startedUptime: uptime)
        applied = nil
        failed = nil
        pending = attempt
        return attempt
    }

    @discardableResult
    public mutating func expire(uptime: TimeInterval) -> Bool {
        guard let attempt = pending,
              uptime - attempt.startedUptime >= SafariReloadTiming.callbackTimeout else { return false }
        failed = attempt.snapshot
        pending = nil
        return true
    }

    @discardableResult
    public mutating func complete(id: UUID, succeeded: Bool) -> Bool {
        guard let attempt = pending, attempt.id == id else { return false }
        applied = succeeded ? attempt.snapshot : nil
        failed = succeeded ? nil : attempt.snapshot
        pending = nil
        return true
    }

    public mutating func retryFailed() {
        failed = nil
    }

    /// A timed-out Safari request is uncancellable and may still change the
    /// compiled list. Reapply the current rules after its late callback.
    public mutating func invalidateApplied() {
        applied = nil
        failed = nil
    }
}
