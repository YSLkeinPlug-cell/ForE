import Foundation

/// Records which snapshot the sandboxed extension actually read. The user agent
/// verifies this after Safari reports successful rule compilation, so a missing
/// App Group permission cannot silently appear as successful protection.
public struct SafariRuleReceipt: Codable {
    public var snapshot: SafariRuleSet
    public var generatedAt: Date
    public var readError: String?

    public init(snapshot: SafariRuleSet, generatedAt: Date = Date(), readError: String? = nil) {
        self.snapshot = snapshot
        self.generatedAt = generatedAt
        self.readError = readError
    }
}
