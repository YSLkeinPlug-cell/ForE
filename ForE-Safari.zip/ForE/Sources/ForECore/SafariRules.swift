import Foundation

/// The portable configuration shared with the Safari content blocker.
/// A missing or elapsed deadline represents an inactive block.
public struct SafariRuleSet: Codable, Equatable {
    public var domains: [String]
    public var activeUntil: Date?
    public var sessionID: UUID?

    public init(domains: [String] = [], activeUntil: Date? = nil, sessionID: UUID? = nil) {
        self.domains = domains
        self.activeUntil = activeUntil
        self.sessionID = sessionID
    }

    public func jsonData(now: Date = Date()) throws -> Data {
        try SafariRules.jsonData(domains: domains, activeUntil: activeUntil, now: now)
    }
}

public enum SafariRulesError: Error, LocalizedError {
    case tooManyDomains

    public var errorDescription: String? {
        "Für die Safari-Sperre sind höchstens 200 Domains erlaubt."
    }
}

/// Generates WebKit Content Blocker JSON, without WebKit or filesystem access.
/// Expiry is evaluated when called; the host app must reload Safari's compiled
/// rule list on start, stop and expiry. A compiled rule list cannot read the clock.
public enum SafariRules {
    public static func jsonData(domains: [String], activeUntil: Date?, now: Date = Date()) throws -> Data {
        let rules: [Rule]
        if let deadline = activeUntil, deadline > now, !domains.isEmpty {
            guard domains.count <= 200 else { throw SafariRulesError.tooManyDomains }
            let normalized = try Set(domains.map { try DomainNormalizer.normalize(input: $0) }).sorted()
            rules = normalized.flatMap { domain in
                // DomainNormalizer permits only ASCII DNS labels. A character
                // class makes dots literal without relying on JSON backslashes.
                let escaped = domain.replacingOccurrences(of: ".", with: "[.]")
                // User information belongs before the host. Including it avoids
                // a bypass via https://name:password@selected.example/ while
                // keeping https://selected.example@unselected.example/ allowed.
                let prefix = "^https?://([^/?#@]*@)?(www[.])?" + escaped + "[.]?(:[0-9]+)?"
                // WebKit's URLFilterParser rejects alternation (including |$).
                // Separate rules cover host-only URLs and host/path boundaries.
                return [Rule(filter: prefix + "[/?#]"), Rule(filter: prefix + "$")]
            }
        } else {
            // WebKit rejects an empty rule array (JSONContainsNoRules), and
            // treats zero-character filters such as ^$ as universal matches.
            // Use an explicitly nonblocking action instead of a block rule
            // that relies on regex behavior. This affects only this rule list.
            // Disable even when stale domains are malformed.
            rules = [Rule(filter: ".*", action: .ignorePreviousRules)]
        }
        let encoder = JSONEncoder()
        encoder.outputFormatting = [.sortedKeys]
        return try encoder.encode(rules)
    }

    private struct Rule: Encodable {
        let trigger: Trigger
        let action: Action

        init(filter: String, action: ActionType = .block) {
            trigger = Trigger(urlFilter: filter)
            self.action = Action(type: action)
        }
    }

    private struct Trigger: Encodable {
        let urlFilter: String
        let caseSensitive = false

        enum CodingKeys: String, CodingKey {
            case urlFilter = "url-filter"
            case caseSensitive = "url-filter-is-case-sensitive"
        }
    }

    private struct Action: Encodable {
        let type: ActionType
    }

    private enum ActionType: String, Encodable {
        case block
        case ignorePreviousRules = "ignore-previous-rules"
    }
}
