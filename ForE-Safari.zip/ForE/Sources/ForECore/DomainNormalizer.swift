import Foundation

public enum DomainValidationError: Error, LocalizedError, Equatable {
    case invalid
    case unsupportedScheme
    case localAddress

    public var errorDescription: String? {
        switch self {
        case .invalid:
            return "Bitte gib eine gültige Domain ein, zum Beispiel youtube.com. Ports, Zugangsdaten und Sonderzeichen sind nicht erlaubt."
        case .unsupportedScheme:
            return "Bitte verwende eine Domain oder eine HTTP-/HTTPS-Adresse."
        case .localAddress:
            return "Lokale Adressen und IP-Adressen können nicht gesperrt werden."
        }
    }
}

public enum DomainNormalizer {
    /// Accepts a domain or pasted web URL. The hosts-based blocker only handles
    /// exact DNS names, so paths are discarded and wildcards are rejected.
    public static func normalize(input: String) throws -> String {
        let trimmed = input.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty,
              trimmed.unicodeScalars.allSatisfy({ $0.value > 32 && $0.value < 127 }),
              !trimmed.contains("\\") else { throw DomainValidationError.invalid }

        let source: String
        if trimmed.contains("://") {
            source = trimmed
        } else {
            source = "https://" + trimmed
        }
        guard let components = URLComponents(string: source),
              let scheme = components.scheme?.lowercased(),
              scheme == "https" || scheme == "http" else {
            throw DomainValidationError.unsupportedScheme
        }
        // Even a default explicit port is rejected: it cannot be represented in hosts.
        let authority = source.components(separatedBy: "://").dropFirst().joined(separator: "://")
            .prefix(while: { $0 != "/" && $0 != "?" && $0 != "#" })
        guard components.user == nil, components.password == nil,
              components.port == nil, components.host != nil,
              !authority.contains(where: { "@:%[]".contains($0) }) else {
            throw DomainValidationError.invalid
        }
        // URLComponents.host decodes punycode on some Foundation versions.
        // Keep the validated ASCII DNS spelling used by /etc/hosts instead.
        var host = authority.lowercased()
        if host.hasSuffix(".") { host.removeLast() }
        if host.hasPrefix("www.") { host.removeFirst(4) }

        let labels = host.split(separator: ".", omittingEmptySubsequences: false)
        guard host.utf8.count <= 253, labels.count >= 2,
              labels.allSatisfy({ label in
                  !label.isEmpty && label.utf8.count <= 63 &&
                  label.first != "-" && label.last != "-" &&
                  label.utf8.allSatisfy { (97...122).contains($0) || (48...57).contains($0) || $0 == 45 }
              }) else { throw DomainValidationError.invalid }
        let reserved = ["local", "localhost", "localdomain", "lan", "home", "internal", "invalid", "test", "example", "onion", "arpa"]
        guard let lastLabel = labels.last,
              !reserved.contains(String(lastLabel)),
              !labels.allSatisfy({ $0.allSatisfy(\.isNumber) }),
              lastLabel.contains(where: { $0.isLetter }) else {
            throw DomainValidationError.localAddress
        }
        return host
    }
}
