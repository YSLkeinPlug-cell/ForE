// swift-tools-version: 5.9
import PackageDescription

let package = Package(
    name: "ForECore",
    platforms: [.macOS(.v13)],
    products: [
        .library(name: "ForECore", targets: ["ForECore"]),
        .library(name: "ForEBlocking", targets: ["ForEBlocking"])
    ],
    targets: [
        .target(name: "ForECore"),
        .testTarget(name: "ForECoreTests", dependencies: ["ForECore"]),
        .target(name: "ForEBlocking", path: "ForEBlocker", exclude: ["main.swift"], sources: ["HostsDocument.swift"]),
        .testTarget(name: "ForEBlockingTests", dependencies: ["ForEBlocking"], path: "Tests/ForEBlockingTests")
    ]
)
