# Architektur

## UI und Zustandsfluss

Die SwiftUI-App verwendet `AppModel` als `@MainActor`-Zustand. Die vier Ansichten teilen denselben Zustand; auch die Menüleiste verwendet ihn. Ein Timer liest einmal pro Sekunde die Uhrzeit und den unprivilegiert lesbaren Systemstatus. Restzeit basiert auf dem gespeicherten Enddatum, nicht auf heruntergezählten Timer-Ticks. Ruhezustand oder ein suspendierter UI-Prozess verlängern die Sitzung dadurch nicht.

`ForECore` enthält ausschließlich Foundation-Modelle. Die Statistik schneidet Sitzungsintervalle an lokalen Tagesgrenzen, berücksichtigt Sommerzeit und beginnt Wochen am Montag. Zeit wird anhand des bestätigten Sitzungsnachweises gezählt, nicht beim Klick auf „Start“. Vorzeitig beendete Sitzungen tragen ihre Dauer bei; nur erfolgreiche Sitzungen erzeugen einen Baum. Laufende Sitzungen werden erst nach dem Ende aufgenommen. Die Daten werden atomar als versioniertes JSON im Benutzerprofil gespeichert. Eine nicht lesbare Historie wird nicht automatisch ersetzt.

## Berechtigungsgrenze

Die App läuft ohne App Sandbox, damit sie nach expliziter Systemfreigabe einen lokalen Administratorhelfer starten kann. Sie schreibt selbst weder `/etc/hosts` noch Dateien unter `/Library`. `BlockingService` erzeugt einen begrenzten JSON-Startauftrag in einer temporären Datei, quotiert alle Shell- und AppleScript-Argumente und startet `/usr/bin/osascript` außerhalb des Main Threads. macOS zeigt seine eigene Administratorfreigabe. Passwörter werden nicht von der App erfasst oder gespeichert.

Das Xcode-Tool-Target `ForEBlocker` wird zusammen mit der App gebaut und als ausführbare Ressource eingebettet. Der Helper prüft Root-Rechte, feste Befehlsformen, UUIDs, ASCII-DNS-Namen, Listenlänge und Zeitgrenzen erneut. Er nimmt keine Shell-Kommandos oder frei wählbaren System-Zielpfade entgegen. Beim ersten erfolgreichen Start installiert er eine root-eigene Kopie und einen launchd-Job mit festen Argumenten. Die Installation erfolgt vor dem Setzen der Sperre.

Das ist eine bewusst einfache Architektur für eine lokal gebaute App. Ein öffentlich vertriebenes Produkt sollte einen signierten, versionierten Helper mit einer gesonderten Installation über Apples ServiceManagement, Peer-Code-Signaturprüfung und passendem Update-/Deinstallationsfluss verwenden. Die lokale Administratorfreigabe erlaubt hier die Installation genau des im selbst gebauten App-Bundle enthaltenen Programms.

## Sperrlebenszyklus

1. Benutzer startet eine Sitzung; eine abgebrochene Freigabe erzeugt keinen Verlaufseintrag.
2. Helper sperrt seine Operationen per Dateilock, validiert den Auftrag und registriert den Watchdog.
3. Hosts-Dokument wird neu eingelesen. Ausschließlich der eigene Abschnitt wird ersetzt. Die eigentliche Datei wird über temporäre Geschwisterdatei und Rename aktualisiert; Dateirechte bleiben erhalten. Gleichzeitige Änderungen werden vor dem Schreiben erneut geprüft. Fremde Writer, die keinen ForE-Lock verwenden, lassen sich damit nicht vollständig synchronisieren.
4. Erst nach erfolgreichem Schreiben wird der Sitzungsbeginn mit Enddatum persistiert. Schlägt das fehl, wird die Sperre zurückgenommen. Nach einem Prozessabbruch zwischen Hosts-Schreiben und Status-Schreiben entfernt der Watchdog einen verwaisten ForE-Abschnitt ohne Zeitgutschrift.
5. Bei Ablauf oder explizitem Stop wird zunächst ein Freigabe-Journal geschrieben. Nach Entfernen der Hosts-Einträge speichert der Helper den Sitzungsnachweis. Das Journal erlaubt die Wiederholung eines unterbrochenen Stops, ohne eine aufgehobene Sperre erneut zu setzen.
6. Die App übernimmt den letzten Nachweis einmalig anhand der Sitzungs-UUID. Die Vollendung des Timers ohne bestätigte Freigabe genügt nicht als Erfolg.

Der Watchdog ist ein kurzer launchd-Aufruf mit `RunAtLoad` und `StartInterval = 10`. Er läuft nicht dauerhaft im Hintergrund. Enddatum und Status liegen auf der Festplatte; nach einem Neustart bzw. Aufwachen kann er aufräumen. Fehler im Zustand führen möglichst zur Freigabe ohne erfundene Zeitgutschrift. Ein defekter markierter Hosts-Abschnitt wird nicht blind über andere Einträge hinweg gelöscht und kann manuelle Reparatur benötigen.

Systempfade müssen root-eigene, nicht allgemein beschreibbare Verzeichnisse sein; reguläre Dateien, Größen, Symlinks und FIFO-Aufträge werden geprüft. Netzwerk- oder Kontozugänge sind für den Betrieb nicht nötig. Domains im root-eigenen, aber lesbaren Status sind keine geheimen Daten. Die App hält keinen frei aufrufbaren, dauerhaften Root-RPC-Server offen.

## Grenzen

- Hosts-Mapping ist keine Browser- oder Paketinspektion; DoH, VPN, Caches und offene Verbindungen begrenzen die Wirkung.
- Die Uhrzeit des Betriebssystems wird als Zeitquelle verwendet. Die App schützt nicht vor absichtlichen Uhränderungen oder Root-Manipulation.
- Eine Instanz der Systemsperre gilt für den gesamten Mac. Mehrere angemeldete Benutzer teilen den Systemstatus, aber nicht ihr persönliches JSON-Archiv.
- Fokuszeit bedeutet Zeit mit gesetzter Sperre, nicht überwachte Aktivität. Auch Schlaf- und Offlinezeit zählen innerhalb der Frist.
- Aktuell bleibt nur der letzte Sitzungsnachweis beim Systemhelfer erhalten. Ein Benutzer sollte die App nach einer Sitzung wieder öffnen, bevor ein anderer Mac-Benutzer die nächste Sitzung beginnt.
