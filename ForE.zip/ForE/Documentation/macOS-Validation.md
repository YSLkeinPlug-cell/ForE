# Prüfung auf einem Mac

Diese Schritte ergänzen die automatisierten Foundation-Tests. Sie sind hier **nicht als bestanden dokumentiert**: Die Cloud-Entwicklung lief unter Linux, ohne Xcode, macOS-SDK oder echten Systemhelfer.

## Build und Oberfläche

1. `ForE.xcodeproj` in Xcode 15+ öffnen, Schema **ForE**, Ziel **My Mac**.
2. **⌘U**: Core- und Hosts-Texttests müssen tatsächlich ausgeführt werden und bestehen.
3. **⌘R**: Fokus, Websites, Mein Wald und Einstellungen öffnen. Fenster bis zur Mindestgröße verkleinern, scrollen, Eingabe mit Tastatur und VoiceOver prüfen. Menüleistenanzeige öffnen.
4. Release bauen: `xcodebuild -project ForE.xcodeproj -scheme ForE -configuration Release -destination 'generic/platform=macOS' build`. Build Settings müssen `MACOSX_DEPLOYMENT_TARGET = 13.0` und Release-Architekturen `arm64 x86_64` zeigen.
5. Die fertige App tatsächlich auf macOS 13 testen, möglichst auf Intel und Apple Silicon. Ein Deployment Target allein beweist keine Laufzeitkompatibilität.

## Eine echte Sitzung

1. Eine entbehrliche, erreichbare Domain wählen; Ausgangszustand im Browser prüfen. Offene Verbindungen schließen, eigenes Browser-DNS/DoH und VPN für diesen Test deaktivieren. Fremde Hosts-Einträge vor und nach dem Test vergleichen.
2. Eine Minute einstellen. **Fokus starten**, Administratorfreigabe zuerst abbrechen. Kein aktiver Timer, keine neue Zeit und kein Baum dürfen entstehen.
3. Erneut starten und bestätigen. Der Timer darf erst nach tatsächlichem Setzen der Sperre beginnen. `/etc/hosts` muss einen einzigen ForE-Abschnitt für IPv4 und IPv6 enthalten. Eine neue Browser-Verbindung zur Domain muss scheitern; andere Websites bleiben erreichbar.
4. Ablauf abwarten: Anzeige kann kurz „Der Systemhelfer gibt … frei“ zeigen. Innerhalb des launchd-Prüfintervalls muss der Abschnitt verschwinden. Browser ggf. neu öffnen. Genau ein Sitzungsnachweis, ca. eine Minute Fokuszeit und genau ein neuer Baum müssen gespeichert sein.
5. App neu starten: Kein doppelter Baum oder Verlaufseintrag. Tages-/Wochen-/Gesamtsummen vergleichen.

## Abbruch und Prozessende

1. Zweiminütige Sitzung starten, nach ca. 30 Sekunden **Sitzung beenden** wählen. Die Freigabe abbrechen: Sperre und ursprüngliches Enddatum müssen bestehen bleiben.
2. Erneut beenden und bestätigen: Hosts-Abschnitt entfernt, nur tatsächliche Zeit gutgeschrieben, kein Baum.
3. Neue einminütige Sitzung starten und App mit **⌘Q** beenden. Nach Ablauf Hosts-Datei prüfen, App wieder öffnen: Freigabe und genau ein abgeschlossener Nachweis.
4. Auf einem Test-Mac zusätzlich App-Prozess beenden, Ruhezustand über den Ablauf hinaus und Neustart während einer Sitzung prüfen. Die Frist darf sich nicht verlängern. Nach Wiederaufnahme muss der Watchdog aufräumen.
5. Während einer Sitzung ForE erneut öffnen: Laufende Sitzung mit ursprünglichem Ende wiederhergestellt; keine parallele Sitzung möglich. Neue Website-Liste bzw. Dauer nicht nachträglich auf die aktive Sitzung anwenden.

## Fehler und Wiederherstellung

- Ungültige Domains, URL-Credentials, Ports, IPs, Zeilenumbrüche und lokale Systemnamen dürfen nicht in der Hosts-Datei landen.
- Einen fremden Hosts-Eintrag außerhalb der ForE-Marker ergänzen: Er muss nach Freigabe unverändert erhalten bleiben.
- Historie sichern; mit ungültigem JSON im Benutzerverlauf starten: Fehlermeldung und neue Sitzungen deaktiviert, Datei nicht überschrieben. Danach gesicherte Datei wiederherstellen.
- Root-Status und Hosts-Datei nur auf einem entbehrlichen Testsystem gezielt beschädigen. Die Anleitung zur manuellen Freigabe in der README bereithalten. Ein nicht eindeutig markierter Abschnitt darf nicht fremde Zeilen löschen.
- Systemhelfer erst nach Freigabe deinstallieren und prüfen, dass keine ForE-Zeilen in `/etc/hosts` verbleiben.

Bei Browsern mit DoH/VPN separat dokumentieren, ob und wie die Sperre greift. Diese Fälle dürfen nicht als garantierte Blockierung ausgewiesen werden.
