# ForE 🌱

Eine native, deutschsprachige Fokus-App für **macOS 13.0 und neuer**, geschrieben in **Swift und SwiftUI**. Wähle ablenkende Websites, starte eine zeitlich begrenzte Sitzung und lass deinen Fokuswald wachsen.

## Auf deinem Mac starten

1. Das gesamte Repository auf deinen Mac kopieren bzw. klonen.
2. **`ForE.xcodeproj`** in **Xcode 15 oder neuer** öffnen. Nicht nur `Package.swift` öffnen: Das Package enthält die testbaren Bibliotheken, nicht die App.
3. Oben das Schema **ForE** und **My Mac** auswählen.
4. **⌘R** drücken. Der mitgelieferte Helper wird automatisch mitgebaut und in die App kopiert. Es sind keine externen Pakete, Generatoren oder API-Schlüssel nötig.
5. Unter **Websites** deine Liste anpassen, unter **Fokus** die Dauer wählen und **Fokus starten** anklicken. Erst jetzt fragt macOS nach einem Administratorzugang.

Das Projekt ist für lokale Ad-hoc-Signierung („Sign to Run Locally“) konfiguriert. Ein bezahltes Entwicklerkonto ist für den eigenen Mac nicht nötig. Bei abweichenden lokalen Xcode-Einstellungen unter *Signing & Capabilities* dieses Signierungsprofil oder dein eigenes Team wählen. Für eine Weitergabe außerhalb des eigenen Macs sind Developer-ID-Signierung und Notarisierung zusätzlich nötig.

**Betriebssystem und Entwicklungswerkzeug:** Die fertige App hat als Deployment Target macOS **13.0**, für Apple Silicon und Intel. Xcode selbst benötigt je nach Version ein neueres macOS; Xcode 15.0 beispielsweise macOS 13.5 oder neuer. Die App verwendet keine erst mit macOS 14 eingeführten Oberflächen-APIs.

## Was enthalten ist

- Fokus-Timer von **1 bis 240 Minuten**, Menüleistenanzeige und automatisch wachsender Baum.
- Bearbeitbare, lokal gespeicherte Website-Liste mit URL-Normalisierung und strenger Domainvalidierung.
- Zeitlich begrenzte, systemweite Hosts-Sperre mit expliziter Administratorfreigabe.
- Automatische Freigabe durch einen **launchd-Systemhelfer**, auch wenn die App geschlossen wurde. Die Frist wird etwa alle zehn Sekunden geprüft; nach Ruhezustand oder Neustart wird die Freigabe nachgeholt.
- Tages-, Wochen- und Gesamtzeit, Tagesziel, Sitzungsverlauf, Fokusserie, XP und Level.
- **Ein Baum pro vollständig beendeter Sitzung**. Vorzeitig beendete Sitzungen zählen mit ihrer tatsächlichen Dauer zur Fokuszeit, aber ohne Baum. 1 Fokusminute = 1 XP; alle 120 XP gibt es ein neues Level.
- Native Swift Charts, Retina-App-Icon und eine ruhige, helle Oberfläche mit Waldgrün.
- Keine Konten, Cloud-Dienste, Telemetrie oder kostenpflichtigen Abhängigkeiten.

## Was die Sperre genau macht

ForE ergänzt `/etc/hosts` um einen eigenen, markierten Abschnitt. Für jede Domain werden IPv4- und IPv6-Einträge für die Domain selbst und ihre `www`-Variante gesetzt. Fremde Hosts-Einträge werden beibehalten. Beim Sitzungsende wird nur der ForE-Abschnitt entfernt.

**Das ist eine Konzentrationshilfe, kein manipulationssicherer Netzwerkfilter.** Es wird nicht das gesamte Internet getrennt. Unterdomains wie `m.youtube.com` oder `old.reddit.com` müssen separat eingetragen werden. Browser mit eigenem DNS/DoH, VPNs, Proxies, DNS-Caches und bereits bestehende Verbindungen können die Wirkung einschränken. Schließe offene Website-Tabs vor dem Start; deaktiviere gegebenenfalls sicheres DNS und prüfe die gewünschte Website in deinem Browser. Ein Administrator kann eine Sperre jederzeit umgehen. ForE blockiert nur eingegebene Domains, keine beliebig gewählten App-Prozesse.

Die Sperre gilt **systemweit für alle Benutzer dieses Macs**. Nach Ablauf kann die tatsächliche Freigabe im Wachzustand einige Sekunden später erfolgen. Die gutgeschriebene Zeit wird auf die geplante Dauer begrenzt. Schlaf- und Offlinezeit zählen mit, weil die Hosts-Sperre bestehen bleibt. Zeiten werden erst nach bestätigter Freigabe in den Verlauf übernommen; die App kann keine tatsächliche Konzentration oder Browsernutzung erkennen.

Für einen Browser-unabhängigen, schwieriger umgehbaren Produktivfilter wäre eine gesonderte Network-Extension-Architektur mit passenden Apple-Entitlements und eigener Distribution nötig.

## Projektstruktur

```text
ForE.xcodeproj/              Fertiges Xcode-Projekt und gemeinsames ForE-Schema
ForE/
  App/                      SwiftUI-App, Zustandsverwaltung und lokale Speicherung
  Services/                 Unprivilegierte Brücke zum Systemhelfer
  Views/                    Fokus, Websites, Mein Wald, Einstellungen, Designsystem
  Resources/                Info.plist, Entitlements und App-Icon
ForEBlocker/
  main.swift                Privilegierter CLI-Helper und launchd-Watchdog
  HostsDocument.swift       Reine, separat getestete Hosts-Textbearbeitung
Sources/ForECore/           Domainprüfung, Datenmodelle und Kalenderstatistik
Tests/                     XCTest-Tests für Kernlogik und Hosts-Bearbeitung
Package.swift              Lokale Swift-Packages ohne externe Abhängigkeiten
Documentation/             Architektur und macOS-Prüfschritte
```

## Bauen und testen

Auf einem Mac mit ausgewähltem Xcode:

```sh
xcodebuild -project ForE.xcodeproj -scheme ForE \
  -configuration Debug -destination 'platform=macOS' build

xcodebuild -project ForE.xcodeproj -scheme ForE \
  -destination 'platform=macOS' test

# Nur plattformunabhängige Bibliotheken (auch unter Linux mit Swift 5.9+):
swift test
```

Alternativ in Xcode **⌘U** verwenden. Die automatisierten Tests verändern keine Systemdateien und benötigen keine Administratorrechte. Der App-Start allein installiert ebenfalls keinen Systemhelfer.

Der mitgelieferte GitHub-Actions-Workflow baut die App und führt die Logiktests auf einem macOS-Runner aus, sobald die Änderungen gepusht werden. Er wurde in dieser Sitzung nicht ausgeführt. Auch ein erfolgreicher CI-Build ersetzt nicht die manuellen Sperrtests auf deinem Mac.

**Validierungsgrenze:** Die Entwicklung in dieser Cloud fand unter Linux statt. Die Foundation-Logik und Hosts-Textbearbeitung wurden mit Swift getestet; Swift-Dateien und Xcode-Projektstruktur wurden geprüft. Ein vollständiger Xcode-/SwiftUI-Build, die Administratorfreigabe und tatsächliche DNS-/launchd-Wirkung müssen auf einem Mac geprüft werden. Die genaue Liste steht in [macOS-Validierung](Documentation/macOS-Validation.md).

## Lokale Daten und Wiederherstellung

Dein Verlauf und deine Einstellungen liegen in:

```text
~/Library/Application Support/ForE/history.json
```

Der Systemhelfer verwendet:

```text
/Library/PrivilegedHelperTools/de.fore.blocker
/Library/LaunchDaemons/de.fore.blocker.plist
/Library/Application Support/ForE/block-state.json
```

Der Systemstatus enthält aktive Domains und den letzten Sitzungsnachweis. Er ist für lokale Benutzer lesbar; Administratorrechte sind zum Ändern nötig. Der persönliche Verlauf wird beim App-Start bzw. nach Sitzungsende aus dem Nachweis ergänzt. Es gibt systemweit jeweils nur eine aktive Sitzung. Bei mehreren Mac-Benutzern werden die persönlichen Verläufe nicht synchronisiert; der Systemstatus ist kein Mehrbenutzer-Archiv.

Wenn du früher aufhören möchtest, öffne ForE und wähle **Sitzung beenden**. Bei geschlossener oder abgestürzter App wartet der Systemhelfer weiter auf die Frist. Falls du die App verschoben hast, kann der bereits installierte Helper weiterhin entsperren.

Bei einem beschädigten Verlauf überschreibt ForE deine Datei nicht und deaktiviert neue Sitzungen. Sichere und repariere die Datei bzw. verschiebe sie bewusst an einen anderen Ort, bevor du neu startest. Eine bestehende Systemsperre läuft unabhängig davon aus.

## Systemhelfer entfernen

Zuerst eine laufende Sitzung in der App beenden und die Übernahme in den Verlauf abwarten. Danach die App schließen und im Terminal ausführen:

```sh
sudo launchctl bootout system /Library/LaunchDaemons/de.fore.blocker.plist
sudo rm -f /Library/LaunchDaemons/de.fore.blocker.plist
sudo rm -f /Library/PrivilegedHelperTools/de.fore.blocker
```

`bootout` kann melden, dass der Dienst nicht geladen ist. Die Systemstatusdateien und der persönliche Verlauf dürfen als lokale Daten erhalten bleiben. Den Helper **nicht während einer laufenden Sitzung entfernen**, weil dadurch die automatische Freigabe entfällt. Die App allein zu löschen deinstalliert den Systemhelfer nicht.

Im Notfall: Die aktive Sitzungs-ID steht in `block-state.json`. Mit einem Administratorzugang lässt sich die Freigabe auch direkt anstoßen:

```sh
sudo /Library/PrivilegedHelperTools/de.fore.blocker stop 'SITZUNGS-UUID'
```

Falls auch das wegen beschädigter Systemdateien fehlschlägt, mit `sudo nano /etc/hosts` ausschließlich den Abschnitt von `# BEGIN FORE BLOCK` bis einschließlich `# END FORE BLOCK` entfernen, danach `sudo dscacheutil -flushcache` und `sudo killall -HUP mDNSResponder` ausführen. Bei noch aktivem Watchdog kann ein nicht abgelaufener, gültiger Status die Sperre erneut setzen; für eine solche manuelle Reparatur zuerst den Dienst wie oben entladen. Niemals die ganze Hosts-Datei löschen oder durch eine alte Kopie ersetzen.
