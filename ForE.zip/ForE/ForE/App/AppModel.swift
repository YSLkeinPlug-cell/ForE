import AppKit
import Combine
import ForECore
import Foundation

enum AppPage: String, CaseIterable {
    case focus = "Fokus"
    case websites = "Websites"
    case progress = "Mein Wald"
    case settings = "Einstellungen"

    var icon: String {
        switch self {
        case .focus: return "timer"
        case .websites: return "globe.europe.africa"
        case .progress: return "leaf"
        case .settings: return "slider.horizontal.3"
        }
    }
}

struct AppNotice: Identifiable {
    let id = UUID()
    let title: String
    let message: String
}

@MainActor
final class AppModel: ObservableObject {
    @Published var page = AppPage.focus
    @Published private(set) var data = StoredData()
    @Published private(set) var activeSession: BlockSession?
    @Published private(set) var isBusy = false
    @Published private(set) var statusReadable = false
    @Published private(set) var now = Date()
    @Published var notice: AppNotice?
    @Published var soundEnabled = UserDefaults.standard.object(forKey: "completionSound") as? Bool ?? true {
        didSet { UserDefaults.standard.set(soundEnabled, forKey: "completionSound") }
    }

    private var timer: AnyCancellable?
    private let storageURL: URL
    private var storageAvailable = true
    private var reportedStatusError = false

    init() {
        let support = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask).first!
        storageURL = support.appendingPathComponent("ForE", isDirectory: true).appendingPathComponent("history.json")
        do {
            let decoder = JSONDecoder()
            decoder.dateDecodingStrategy = .iso8601
            data = try decoder.decode(StoredData.self, from: Data(contentsOf: storageURL))
            data.preferredMinutes = min(240, max(1, data.preferredMinutes))
            data.dailyGoalMinutes = min(480, max(15, data.dailyGoalMinutes))
        } catch let error as CocoaError where error.code == .fileReadNoSuchFile {
            // First launch has no history document yet.
        } catch {
            // Never replace an unreadable history with empty data.
            storageAvailable = false
            notice = AppNotice(title: "Verlauf konnte nicht geladen werden",
                message: "Deine Datei bleibt unverändert: \(storageURL.path). Bitte sichere bzw. repariere sie und starte ForE erneut. Neue Sitzungen sind bis dahin deaktiviert. \(error.localizedDescription)")
        }
        refreshState()
        timer = Timer.publish(every: 1, on: .main, in: .common).autoconnect().sink { [weak self] _ in
            self?.now = Date()
            self?.refreshState()
        }
    }

    var statistics: FocusStatistics { FocusStatistics(sessions: data.sessions, now: now) }
    var canStart: Bool { !isBusy && activeSession == nil && !data.domains.isEmpty && statusReadable && storageAvailable }
    var canEdit: Bool { activeSession == nil && !isBusy && storageAvailable }
    var remainingSeconds: TimeInterval { max(0, (activeSession?.endsAt ?? now.timeIntervalSince1970) - now.timeIntervalSince1970) }
    var remainingText: String {
        let value = Int(ceil(remainingSeconds))
        return String(format: "%02d:%02d", value / 60, value % 60)
    }
    var sessionProgress: Double {
        guard let session = activeSession else { return 0 }
        return min(1, max(0, 1 - remainingSeconds / max(1, session.endsAt - session.startedAt)))
    }

    func setMinutes(_ value: Int) {
        guard canEdit else { return }
        data.preferredMinutes = min(240, max(1, value))
        save()
    }

    func setGoal(_ value: Int) {
        guard storageAvailable else { return }
        data.dailyGoalMinutes = min(480, max(15, value))
        save()
    }

    func addDomain(_ input: String) throws {
        guard canEdit else { return }
        let domain = try DomainNormalizer.normalize(input: input)
        guard !data.domains.contains(domain) else { return }
        guard data.domains.count < 100 else {
            throw BlockingError.operationFailed("Du kannst bis zu 100 Domains hinzufügen.")
        }
        data.domains.append(domain)
        save()
    }

    func removeDomain(_ domain: String) {
        guard canEdit else { return }
        data.domains.removeAll { $0 == domain }
        save()
    }

    func startSession() {
        guard canStart else { return }
        isBusy = true
        Task {
            do {
                try await BlockingService.start(domains: data.domains, minutes: data.preferredMinutes)
            } catch {
                notice = AppNotice(title: "Fokus konnte nicht gestartet werden", message: error.localizedDescription)
            }
            refreshState()
            isBusy = false
        }
    }

    func stopSession() {
        guard let session = activeSession, !isBusy else { return }
        isBusy = true
        Task {
            do {
                try await BlockingService.stop(id: session.id)
            } catch {
                notice = AppNotice(title: "Websites noch nicht freigegeben", message: error.localizedDescription)
            }
            refreshState()
            isBusy = false
        }
    }

    func revealHistory() {
        NSWorkspace.shared.selectFile(storageURL.path, inFileViewerRootedAtPath: storageURL.deletingLastPathComponent().path)
    }

    private func refreshState() {
        do {
            let state = try BlockingService.readState()
            statusReadable = true
            reportedStatusError = false
            activeSession = state.active
            if storageAvailable, let receipt = state.lastFinished,
               !data.sessions.contains(where: { $0.id == receipt.id }) {
                data.sessions.append(FocusSession(id: receipt.id, domains: receipt.domains,
                    startedAt: Date(timeIntervalSince1970: receipt.startedAt),
                    endedAt: Date(timeIntervalSince1970: receipt.endedAt),
                    plannedEnd: Date(timeIntervalSince1970: receipt.plannedEnd), completed: receipt.completed))
                if save(), receipt.completed, now.timeIntervalSince1970 - receipt.endedAt < 30 {
                    if soundEnabled { NSSound(named: "Glass")?.play() }
                    notice = AppNotice(title: "Ein neuer Baum für deinen Wald 🌱",
                        message: "Deine Fokuszeit ist vorbei. Die Websites sind wieder freigegeben und deine Zeit wurde gespeichert.")
                }
            }
        } catch {
            statusReadable = false
            if !reportedStatusError {
                reportedStatusError = true
                notice = AppNotice(title: "Sperrstatus nicht lesbar", message: "Es wird keine neue Sitzung gestartet, solange der Systemstatus unklar ist. Eine bestehende Sperre läuft durch den Systemhelfer aus. \(error.localizedDescription)")
            }
        }
    }

    @discardableResult
    private func save() -> Bool {
        guard storageAvailable else { return false }
        do {
            try FileManager.default.createDirectory(at: storageURL.deletingLastPathComponent(), withIntermediateDirectories: true)
            let encoder = JSONEncoder()
            encoder.dateEncodingStrategy = .iso8601
            encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
            try encoder.encode(data).write(to: storageURL, options: .atomic)
            return true
        } catch {
            storageAvailable = false
            notice = AppNotice(title: "Verlauf konnte nicht gespeichert werden",
                message: "Bitte prüfe den freien Speicher und die Schreibrechte. Deine Systemsperre läuft unabhängig davon aus. Der letzte Sitzungsnachweis bleibt beim Systemhelfer gespeichert und wird beim nächsten App-Start erneut eingelesen. \(error.localizedDescription)")
            return false
        }
    }
}
