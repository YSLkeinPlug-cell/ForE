import SwiftUI

struct SettingsView: View {
    @EnvironmentObject private var model: AppModel

    var body: some View {
        VStack(alignment: .leading, spacing: 26) {
            PageHeading(eyebrow: "Fokus nach deinen Regeln.", title: "Ein guter Rahmen für dich.",
                subtitle: "Kleine Einstellungen. Ein bisschen mehr Ruhe im Alltag.")
            VStack(alignment: .leading, spacing: 22) {
                Text("Deine Routine").font(.system(size: 17, weight: .semibold, design: .rounded))
                HStack {
                    VStack(alignment: .leading, spacing: 5) {
                        Text("Tägliches Fokusziel").font(.system(size: 13, weight: .medium))
                        Text("Eine Orientierung für dich – ohne Druck.").font(.system(size: 11)).foregroundStyle(ForestStyle.muted)
                    }
                    Spacer()
                    Text("\(model.data.dailyGoalMinutes) Min.").font(.system(size: 13, weight: .medium)).monospacedDigit()
                    Stepper("Tagesziel", value: Binding(get: { model.data.dailyGoalMinutes }, set: model.setGoal),
                        in: 15...480, step: 15).labelsHidden().accessibilityLabel("Tagesziel in Minuten")
                }
                Divider()
                Toggle(isOn: $model.soundEnabled) {
                    VStack(alignment: .leading, spacing: 5) {
                        Text("Ein leiser Abschluss").font(.system(size: 13, weight: .medium))
                        Text("Spiele einen Ton, wenn die Sitzung bei geöffneter App endet.")
                            .font(.system(size: 11)).foregroundStyle(ForestStyle.muted)
                    }
                }.toggleStyle(.switch)
            }.forestCard()

            VStack(alignment: .leading, spacing: 18) {
                Label("So funktioniert die Systemsperre", systemImage: "lock.shield")
                    .font(.system(size: 17, weight: .semibold, design: .rounded))
                detail("Mit deiner Erlaubnis", "Beim Start und beim vorzeitigen Beenden fragt macOS nach einem Administratorzugang. Es wird nur der markierte ForE-Abschnitt in /etc/hosts geändert.")
                detail("Die App darf geschlossen werden", "Ein Systemhelfer prüft die Frist etwa alle zehn Sekunden und hebt die Sperre auch nach einem Neustart wieder auf. Im Ruhezustand läuft die Zeit weiter; nach dem Aufwachen wird die Freigabe nachgeholt.")
                detail("Für diesen Mac", "Die Sperre gilt systemweit und damit auch für andere angemeldete Benutzer. Die Website-Liste gilt jeweils für die nächste Sitzung. ForE ist kein manipulationssicherer Filter und sperrt nicht den gesamten Internetzugang.")
            }.forestCard()

            VStack(alignment: .leading, spacing: 18) {
                Label("Deine Daten bleiben bei dir", systemImage: "externaldrive")
                    .font(.system(size: 17, weight: .semibold, design: .rounded))
                Text("Kein Konto. Keine Cloud. Keine Analyse-Tracker. Website-Liste und Fokusverlauf liegen lokal unter ~/Library/Application Support/ForE. Der Systemhelfer speichert den aktuellen Status und den letzten Sitzungsnachweis unter /Library/Application Support/ForE; die Domainnamen darin sind für lokale Benutzer lesbar.")
                    .font(.system(size: 12)).foregroundStyle(ForestStyle.muted).lineSpacing(5)
                Button { model.revealHistory() } label: { Label("Lokale Verlaufsdatei im Finder zeigen", systemImage: "folder") }
                    .buttonStyle(.bordered)
                Text("ForE 1.0 · Entwickelt für macOS 13 und neuer").font(.system(size: 10)).foregroundStyle(ForestStyle.muted)
            }.forestCard()
        }.foregroundStyle(ForestStyle.ink)
    }

    private func detail(_ title: String, _ text: String) -> some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(title).font(.system(size: 12, weight: .semibold))
            Text(text).font(.system(size: 12)).foregroundStyle(ForestStyle.muted).lineSpacing(5)
        }
    }
}
